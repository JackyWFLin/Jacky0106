#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from statistics import mean, stdev
import math


# In[2]:


class CCD_Measure():
    
    def __init__(self, file_path, group):
        self.file_path = file_path
        self.group = group
        self.x_raw = []
        self.y_raw = []
        self.x = []
        self.y = []
        self.result = []
        self.meas_value = []
        
        
    def moving_average(self, a, n=3):

        ret = np.cumsum(a, dtype=float)

        ret[n:] = ret[n:] - ret[:-n]

        return a[0:n - 1] + list(ret[n - 1:] / n)

    def read_file(self, path):
        f = open(path, 'r', encoding="utf-8")
        r = f.read()
        f.close()
        #r = [float(i)/1000 for i in r.split('\n')[:-1]]
        r = r.split('\n')
        rs = []
        for v in r:
            try:
                rs.append(float(v))
            except:
                pass

        r = rs
        df = pd.DataFrame(r, columns=['v'])
        return df

    def get_radius_data(self, raw_value):
        degree = math.pi * 2 / len(raw_value)
        x = []
        y = []
        i = 0
        for i, value in enumerate(raw_value):
            x.append(value * math.cos(degree * i))
            y.append(value * math.sin(degree * i))
        return x, y

    def filter_notch(self, df):

        #cal diff
        t1 = df['v'].to_list()
        t2 = t1[1::]
        t2.append(t1[-1])
        r = [0]
        r.extend(list(abs(np.array(t2) - np.array(t1)))[:-1])
        df['diff'] = self.moving_average(r, 5)

        # find notch
        diff = df['diff'].to_list()
        v = df['v'].to_list()
        d = [i for i in range(len(diff)) if diff[i] > 0.01]
        d1 = d
        d2 = d[1::]
        d2.append(t1[-1])
        dd = list(abs(np.array(d2) - np.array(d1)))[:-1]
        d_split = []
        start = d[0]
        end = d[0]
        for i, x in enumerate(dd):
            if (x > 100):
                d_split.append([start, end])
                start = d[i + 1]
            end = d[i + 1]
        d_split.append([start, end])
        print(d_split)

        #filter notch

        for d in d_split:
            n11 = d[0] - 20
            n12 = d[1] + 20
            if n11 < 0:
                n11 = 0
            if n12 >= len(v):
                n12 = len(v) - 1

            half_c = int(len(v) / 2)

            n21 = (n11 + half_c) % len(v)
            n22 = (n12 + half_c) % len(v)

            print(n11, n12, n21, n22)
            v[n11:n12] = [-999] * (n12 - n11)
            v[n21:n22] = [-999] * (n12 - n11)

        v = [i for i in v if i != -999]

        print("Noise count:", len(df['v'].to_list()) - len(v))

        return v

    def draw_circle(self, x_raw, y_raw, x, y):
        f = plt.figure( facecolor='white', figsize=(10, 10))  #figsize=(7, 5.4), dpi=72,
        plt.axis('equal')

        plt.xlabel('x')
        plt.ylabel('y')   
        # plot data
        plt.plot(x_raw, y_raw, 'g-' , label="Raw", lw=1)
        plt.plot(x, y, 'r-.', label='Filter Notch', mew=1)
        plt.grid()
        plt.title('Raw Data Circle')
        plt.legend(loc='best',labelspacing=0.1 )
        #plt.savefig('/'self.file_path.split('/')[0:-1] + '/circle.jpg')
        #plt.figure(figsize=(10, 10))
        #plt.plot(x, y)
        #plt.show()

    def draw_chart(self, a):
        plt.plot(a)
        plt.xlabel('idx')
        plt.ylabel('value')
        plt.title('Measure value')
        #plt.show()

    def get_meas_result(self, meas_value, group):
        meas_group_all = []
        half = int(len(meas_value) / 2)
        for i in range(0, half):
            meas_group_all.append((meas_value[i] + meas_value[i + half]) / 2)

        if (group == 0):
            return meas_group_all

        meas_group = []
        group_d = math.floor(len(meas_group_all) / group)
        for i in range(0, len(meas_group_all), group_d):
            if (len(meas_group) < group - 1):
                meas_group.append(mean(meas_group_all[i:i + group_d]))
            else:
                meas_group.append(mean(meas_group_all[i::]))
                break

        return meas_group

    def measure(self):
        
        #read file
        df = self.read_file(self.file_path)
        x_raw, y_raw = self.get_radius_data(df['v'].to_list())
        self.x_raw = x_raw
        self.y_raw = y_raw
        raw_value = self.filter_notch(df)

        self.x, self.y = self.get_radius_data(raw_value)
        self.draw_circle(x_raw, y_raw, self.x, self.y)

        self.meas_value = self.get_meas_result(raw_value, self.group)
        self.draw_chart(self.meas_value)

        # 'MIN', 'MAX', 'RANGE', 'STD', 'AVG'
        self.result = [
            min(self.meas_value),
            max(self.meas_value),
            max(self.meas_value) - min(self.meas_value),
            stdev(self.meas_value),
            mean(self.meas_value)
        ]


# In[ ]:

