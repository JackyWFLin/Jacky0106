﻿
namespace MeasureWaferRecipe
{
    partial class RecipeForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecipeForm));
            this.tbp_Edge = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.btn_LoadImage_Edge = new System.Windows.Forms.Button();
            this.btn_SaveRecipe_Edge = new System.Windows.Forms.Button();
            this.btn_LoadRecipe_Edge = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.btn_MasureTest_Edge = new System.Windows.Forms.Button();
            this.tbc_EdgeType = new System.Windows.Forms.TabControl();
            this.tbp_TypeB = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nud_bu2Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_bv2Ratio = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nud_bu1Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_bv1Ratio = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nud_AngleStart1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_AngleTop1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nud_AngleStart2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nud_AngleTop2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.ptb_View = new System.Windows.Forms.PictureBox();
            this.tbl_MeasureResult = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.nud_A1Upper = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.txb_A1 = new System.Windows.Forms.TextBox();
            this.txb_A2 = new System.Windows.Forms.TextBox();
            this.txb_B1 = new System.Windows.Forms.TextBox();
            this.txb_B2 = new System.Windows.Forms.TextBox();
            this.txb_R1 = new System.Windows.Forms.TextBox();
            this.R2 = new System.Windows.Forms.TextBox();
            this.t = new System.Windows.Forms.TextBox();
            this.txb_Ang1 = new System.Windows.Forms.TextBox();
            this.txb_Ang2 = new System.Windows.Forms.TextBox();
            this.txb_BC = new System.Windows.Forms.TextBox();
            this.txb_C2 = new System.Windows.Forms.TextBox();
            this.txb_C1 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.nud_A1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_A2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_A2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_B1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_B2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_B2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_B1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_R1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_R2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_tUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_tLower = new System.Windows.Forms.NumericUpDown();
            this.nud_R2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_R1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_BCUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_BCLower = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_Ang2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_C1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_C2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_C1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_C2Lower = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbp_Notch = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label50 = new System.Windows.Forms.Label();
            this.nud_NotchGrayMax = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.nud_b2Ang = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.nud_u1Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_u2Ratio = new System.Windows.Forms.NumericUpDown();
            this.nud_VrWidth1 = new System.Windows.Forms.NumericUpDown();
            this.nud_PinRadius = new System.Windows.Forms.NumericUpDown();
            this.nud_VR12Angle = new System.Windows.Forms.NumericUpDown();
            this.nud_b1Ang = new System.Windows.Forms.NumericUpDown();
            this.nud_VrWidth2 = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label46 = new System.Windows.Forms.Label();
            this.btn_LoadImage_Notch = new System.Windows.Forms.Button();
            this.btn_SaveRecipe_Notch = new System.Windows.Forms.Button();
            this.btn_LoadRecipe_Notch = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.btn_MasureTest_Notch = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label60 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.nud_VhUpper = new System.Windows.Forms.NumericUpDown();
            this.txb_Vh = new System.Windows.Forms.TextBox();
            this.txb_Vw = new System.Windows.Forms.TextBox();
            this.txb_Vr = new System.Windows.Forms.TextBox();
            this.txb_AngV = new System.Windows.Forms.TextBox();
            this.txb_P1 = new System.Windows.Forms.TextBox();
            this.txb_P2 = new System.Windows.Forms.TextBox();
            this.txb_VR1 = new System.Windows.Forms.TextBox();
            this.txb_VR2 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.nud_VhLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR1Upper = new System.Windows.Forms.NumericUpDown();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.nud_VwUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_VwLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VrUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_VrLower = new System.Windows.Forms.NumericUpDown();
            this.nud_AngVUpper = new System.Windows.Forms.NumericUpDown();
            this.nud_P1Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_P1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_P2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_P2Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_AngVLower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR1Lower = new System.Windows.Forms.NumericUpDown();
            this.nud_VR2Upper = new System.Windows.Forms.NumericUpDown();
            this.nud_VR2Lower = new System.Windows.Forms.NumericUpDown();
            this.tbp_Edge.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tbc_EdgeType.SuspendLayout();
            this.tbp_TypeB.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_View)).BeginInit();
            this.tbl_MeasureResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Lower)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tbp_Notch.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchGrayMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b2Ang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u1Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u2Ratio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PinRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR12Angle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b1Ang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVUpper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVLower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Lower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Upper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Lower)).BeginInit();
            this.SuspendLayout();
            // 
            // tbp_Edge
            // 
            this.tbp_Edge.Controls.Add(this.tableLayoutPanel1);
            this.tbp_Edge.Location = new System.Drawing.Point(4, 25);
            this.tbp_Edge.Name = "tbp_Edge";
            this.tbp_Edge.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_Edge.Size = new System.Drawing.Size(1113, 793);
            this.tbp_Edge.TabIndex = 0;
            this.tbp_Edge.Text = "Edge";
            this.tbp_Edge.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1107, 787);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel4);
            this.panel1.Controls.Add(this.tbc_EdgeType);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(437, 781);
            this.panel1.TabIndex = 2;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_LoadImage_Edge, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.btn_SaveRecipe_Edge, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.btn_LoadRecipe_Edge, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label39, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label37, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label38, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_MasureTest_Edge, 4, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel4.TabIndex = 6;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label36.Location = new System.Drawing.Point(3, 3);
            this.label36.Margin = new System.Windows.Forms.Padding(3);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(51, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "開啟圖片";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadImage_Edge
            // 
            this.btn_LoadImage_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Edge.BackgroundImage")));
            this.btn_LoadImage_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Edge.Location = new System.Drawing.Point(3, 22);
            this.btn_LoadImage_Edge.Name = "btn_LoadImage_Edge";
            this.btn_LoadImage_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Edge.TabIndex = 2;
            this.btn_LoadImage_Edge.UseVisualStyleBackColor = true;
            // 
            // btn_SaveRecipe_Edge
            // 
            this.btn_SaveRecipe_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_SaveRecipe_Edge.BackgroundImage")));
            this.btn_SaveRecipe_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_SaveRecipe_Edge.Location = new System.Drawing.Point(174, 22);
            this.btn_SaveRecipe_Edge.Name = "btn_SaveRecipe_Edge";
            this.btn_SaveRecipe_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_SaveRecipe_Edge.TabIndex = 2;
            this.btn_SaveRecipe_Edge.UseVisualStyleBackColor = true;
            // 
            // btn_LoadRecipe_Edge
            // 
            this.btn_LoadRecipe_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadRecipe_Edge.BackgroundImage")));
            this.btn_LoadRecipe_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadRecipe_Edge.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadRecipe_Edge.Name = "btn_LoadRecipe_Edge";
            this.btn_LoadRecipe_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadRecipe_Edge.TabIndex = 5;
            this.btn_LoadRecipe_Edge.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label39.Location = new System.Drawing.Point(60, 3);
            this.label39.Margin = new System.Windows.Forms.Padding(3);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label39.Size = new System.Drawing.Size(51, 13);
            this.label39.TabIndex = 1;
            this.label39.Text = "載入參數";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label37.Location = new System.Drawing.Point(174, 3);
            this.label37.Margin = new System.Windows.Forms.Padding(3);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(51, 13);
            this.label37.TabIndex = 1;
            this.label37.Text = "儲存參數";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label38.Location = new System.Drawing.Point(231, 3);
            this.label38.Margin = new System.Windows.Forms.Padding(3);
            this.label38.Name = "label38";
            this.label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label38.Size = new System.Drawing.Size(51, 13);
            this.label38.TabIndex = 1;
            this.label38.Text = "量測計算";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_MasureTest_Edge
            // 
            this.btn_MasureTest_Edge.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_MasureTest_Edge.BackgroundImage")));
            this.btn_MasureTest_Edge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_MasureTest_Edge.Location = new System.Drawing.Point(231, 22);
            this.btn_MasureTest_Edge.Name = "btn_MasureTest_Edge";
            this.btn_MasureTest_Edge.Size = new System.Drawing.Size(51, 43);
            this.btn_MasureTest_Edge.TabIndex = 5;
            this.btn_MasureTest_Edge.UseVisualStyleBackColor = true;
            // 
            // tbc_EdgeType
            // 
            this.tbc_EdgeType.Controls.Add(this.tbp_TypeB);
            this.tbc_EdgeType.Location = new System.Drawing.Point(19, 169);
            this.tbc_EdgeType.Name = "tbc_EdgeType";
            this.tbc_EdgeType.SelectedIndex = 0;
            this.tbc_EdgeType.Size = new System.Drawing.Size(411, 584);
            this.tbc_EdgeType.TabIndex = 4;
            // 
            // tbp_TypeB
            // 
            this.tbp_TypeB.Controls.Add(this.tableLayoutPanel3);
            this.tbp_TypeB.Location = new System.Drawing.Point(4, 25);
            this.tbp_TypeB.Name = "tbp_TypeB";
            this.tbp_TypeB.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_TypeB.Size = new System.Drawing.Size(403, 555);
            this.tbp_TypeB.TabIndex = 0;
            this.tbp_TypeB.Text = "TypeB";
            this.tbp_TypeB.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.97298F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.02703F));
            this.tableLayoutPanel3.Controls.Add(this.label10, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.numericUpDown1, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label8, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.nud_bu2Ratio, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.nud_bv2Ratio, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.label6, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label7, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.nud_bu1Ratio, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.nud_bv1Ratio, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleStart1, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleTop1, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label3, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleStart2, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.label5, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.nud_AngleTop2, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox3, 0, 7);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(30);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 12;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(397, 549);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(141, 3);
            this.label10.Margin = new System.Windows.Forms.Padding(3);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(181, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "最大灰階值 GrayMax (Auto : -1)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDown1.Location = new System.Drawing.Point(329, 3);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown1.Size = new System.Drawing.Size(64, 23);
            this.numericUpDown1.TabIndex = 0;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(141, 300);
            this.label9.Margin = new System.Windows.Forms.Padding(3);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(127, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "起始點比率(下)  u2:H2";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(141, 333);
            this.label8.Margin = new System.Windows.Forms.Padding(3);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(114, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "終點比率(下)  v2:H2";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_bu2Ratio
            // 
            this.nud_bu2Ratio.DecimalPlaces = 2;
            this.nud_bu2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu2Ratio.Location = new System.Drawing.Point(329, 300);
            this.nud_bu2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bu2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu2Ratio.Name = "nud_bu2Ratio";
            this.nud_bu2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bu2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bu2Ratio.TabIndex = 0;
            this.nud_bu2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bu2Ratio.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_bu2Ratio.ValueChanged += new System.EventHandler(this.nud_bu2Ratio_ValueChanged);
            // 
            // nud_bv2Ratio
            // 
            this.nud_bv2Ratio.DecimalPlaces = 2;
            this.nud_bv2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv2Ratio.Location = new System.Drawing.Point(329, 333);
            this.nud_bv2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bv2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv2Ratio.Name = "nud_bv2Ratio";
            this.nud_bv2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bv2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bv2Ratio.TabIndex = 0;
            this.nud_bv2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bv2Ratio.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.nud_bv2Ratio.ValueChanged += new System.EventHandler(this.nud_bu2Ratio_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(141, 234);
            this.label6.Margin = new System.Windows.Forms.Padding(3);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(127, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "起始點比率(上)  u1:H1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(141, 267);
            this.label7.Margin = new System.Windows.Forms.Padding(3);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(126, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "終點點比率(上)  v1:H1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_bu1Ratio
            // 
            this.nud_bu1Ratio.DecimalPlaces = 2;
            this.nud_bu1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu1Ratio.Location = new System.Drawing.Point(329, 234);
            this.nud_bu1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bu1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bu1Ratio.Name = "nud_bu1Ratio";
            this.nud_bu1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bu1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bu1Ratio.TabIndex = 0;
            this.nud_bu1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bu1Ratio.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // nud_bv1Ratio
            // 
            this.nud_bv1Ratio.DecimalPlaces = 2;
            this.nud_bv1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv1Ratio.Location = new System.Drawing.Point(329, 267);
            this.nud_bv1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_bv1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_bv1Ratio.Name = "nud_bv1Ratio";
            this.nud_bv1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_bv1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_bv1Ratio.TabIndex = 0;
            this.nud_bv1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_bv1Ratio.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(162, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "起始點a1切線角度(上) [DEG]";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleStart1
            // 
            this.nud_AngleStart1.DecimalPlaces = 2;
            this.nud_AngleStart1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleStart1.Location = new System.Drawing.Point(329, 69);
            this.nud_AngleStart1.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_AngleStart1.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_AngleStart1.Name = "nud_AngleStart1";
            this.nud_AngleStart1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleStart1.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleStart1.TabIndex = 0;
            this.nud_AngleStart1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleStart1.Value = new decimal(new int[] {
            76,
            0,
            0,
            -2147483648});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 102);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(149, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "頂點c1切線角度(上) [DEG]";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleTop1
            // 
            this.nud_AngleTop1.DecimalPlaces = 2;
            this.nud_AngleTop1.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleTop1.Location = new System.Drawing.Point(329, 102);
            this.nud_AngleTop1.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_AngleTop1.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_AngleTop1.Name = "nud_AngleTop1";
            this.nud_AngleTop1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleTop1.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleTop1.TabIndex = 0;
            this.nud_AngleTop1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleTop1.Value = new decimal(new int[] {
            20,
            0,
            0,
            -2147483648});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 168);
            this.label3.Margin = new System.Windows.Forms.Padding(3);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(162, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "起始點a2切線角度(下) [DEG]";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleStart2
            // 
            this.nud_AngleStart2.DecimalPlaces = 2;
            this.nud_AngleStart2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleStart2.Location = new System.Drawing.Point(329, 168);
            this.nud_AngleStart2.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_AngleStart2.Name = "nud_AngleStart2";
            this.nud_AngleStart2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleStart2.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleStart2.TabIndex = 0;
            this.nud_AngleStart2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleStart2.Value = new decimal(new int[] {
            76,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(141, 135);
            this.label5.Margin = new System.Windows.Forms.Padding(3);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(149, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "頂點c2切線角度(下) [DEG]";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_AngleTop2
            // 
            this.nud_AngleTop2.DecimalPlaces = 2;
            this.nud_AngleTop2.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_AngleTop2.Location = new System.Drawing.Point(329, 135);
            this.nud_AngleTop2.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_AngleTop2.Name = "nud_AngleTop2";
            this.nud_AngleTop2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngleTop2.Size = new System.Drawing.Size(64, 23);
            this.nud_AngleTop2.TabIndex = 0;
            this.nud_AngleTop2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngleTop2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(3, 69);
            this.pictureBox2.Name = "pictureBox2";
            this.tableLayoutPanel3.SetRowSpan(this.pictureBox2, 4);
            this.pictureBox2.Size = new System.Drawing.Size(132, 126);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Location = new System.Drawing.Point(3, 234);
            this.pictureBox3.Name = "pictureBox3";
            this.tableLayoutPanel3.SetRowSpan(this.pictureBox3, 4);
            this.pictureBox3.Size = new System.Drawing.Size(132, 126);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "A",
            "B",
            "C"});
            this.comboBox1.Location = new System.Drawing.Point(63, 115);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(35, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "B";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.20035F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.799648F));
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ptb_View, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tbl_MeasureResult, 0, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(446, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.250597F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.7494F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 317F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(658, 781);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label40.Location = new System.Drawing.Point(3, 3);
            this.label40.Margin = new System.Windows.Forms.Padding(3);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(613, 16);
            this.label40.TabIndex = 1;
            this.label40.Text = "影像視窗";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ptb_View
            // 
            this.ptb_View.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ptb_View.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ptb_View.Location = new System.Drawing.Point(3, 25);
            this.ptb_View.Name = "ptb_View";
            this.ptb_View.Size = new System.Drawing.Size(613, 402);
            this.ptb_View.TabIndex = 0;
            this.ptb_View.TabStop = false;
            // 
            // tbl_MeasureResult
            // 
            this.tbl_MeasureResult.ColumnCount = 10;
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.463196F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.31059F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.84919F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.181329F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.02873F));
            this.tbl_MeasureResult.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.38779F));
            this.tbl_MeasureResult.Controls.Add(this.label11, 0, 2);
            this.tbl_MeasureResult.Controls.Add(this.label12, 0, 3);
            this.tbl_MeasureResult.Controls.Add(this.label13, 5, 2);
            this.tbl_MeasureResult.Controls.Add(this.label14, 5, 3);
            this.tbl_MeasureResult.Controls.Add(this.label15, 0, 4);
            this.tbl_MeasureResult.Controls.Add(this.label16, 0, 5);
            this.tbl_MeasureResult.Controls.Add(this.label19, 0, 7);
            this.tbl_MeasureResult.Controls.Add(this.label20, 0, 8);
            this.tbl_MeasureResult.Controls.Add(this.label18, 0, 6);
            this.tbl_MeasureResult.Controls.Add(this.label22, 5, 7);
            this.tbl_MeasureResult.Controls.Add(this.label21, 5, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_A1Upper, 3, 2);
            this.tbl_MeasureResult.Controls.Add(this.label17, 5, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_A1, 1, 2);
            this.tbl_MeasureResult.Controls.Add(this.txb_A2, 1, 3);
            this.tbl_MeasureResult.Controls.Add(this.txb_B1, 1, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_B2, 1, 5);
            this.tbl_MeasureResult.Controls.Add(this.txb_R1, 1, 6);
            this.tbl_MeasureResult.Controls.Add(this.R2, 1, 7);
            this.tbl_MeasureResult.Controls.Add(this.t, 1, 8);
            this.tbl_MeasureResult.Controls.Add(this.txb_Ang1, 6, 2);
            this.tbl_MeasureResult.Controls.Add(this.txb_Ang2, 6, 3);
            this.tbl_MeasureResult.Controls.Add(this.txb_BC, 6, 4);
            this.tbl_MeasureResult.Controls.Add(this.txb_C2, 6, 7);
            this.tbl_MeasureResult.Controls.Add(this.txb_C1, 6, 6);
            this.tbl_MeasureResult.Controls.Add(this.label30, 7, 7);
            this.tbl_MeasureResult.Controls.Add(this.label31, 7, 6);
            this.tbl_MeasureResult.Controls.Add(this.label32, 7, 4);
            this.tbl_MeasureResult.Controls.Add(this.label33, 7, 3);
            this.tbl_MeasureResult.Controls.Add(this.label34, 7, 2);
            this.tbl_MeasureResult.Controls.Add(this.label35, 0, 1);
            this.tbl_MeasureResult.Controls.Add(this.label23, 2, 2);
            this.tbl_MeasureResult.Controls.Add(this.label24, 2, 3);
            this.tbl_MeasureResult.Controls.Add(this.label25, 2, 4);
            this.tbl_MeasureResult.Controls.Add(this.label26, 2, 5);
            this.tbl_MeasureResult.Controls.Add(this.label27, 2, 6);
            this.tbl_MeasureResult.Controls.Add(this.label28, 2, 7);
            this.tbl_MeasureResult.Controls.Add(this.label29, 2, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_A1Lower, 4, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_A2Upper, 3, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_A2Lower, 4, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_B1Upper, 3, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_B2Upper, 3, 5);
            this.tbl_MeasureResult.Controls.Add(this.nud_B2Lower, 4, 5);
            this.tbl_MeasureResult.Controls.Add(this.nud_B1Lower, 4, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_R1Upper, 3, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_R2Upper, 3, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_tUpper, 3, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_tLower, 4, 8);
            this.tbl_MeasureResult.Controls.Add(this.nud_R2Lower, 4, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_R1Lower, 4, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_BCUpper, 8, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_BCLower, 9, 4);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang1Upper, 8, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang1Lower, 9, 2);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang2Upper, 8, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_Ang2Lower, 9, 3);
            this.tbl_MeasureResult.Controls.Add(this.nud_C1Upper, 8, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_C2Upper, 8, 7);
            this.tbl_MeasureResult.Controls.Add(this.nud_C1Lower, 9, 6);
            this.tbl_MeasureResult.Controls.Add(this.nud_C2Lower, 9, 7);
            this.tbl_MeasureResult.Controls.Add(this.label41, 3, 1);
            this.tbl_MeasureResult.Controls.Add(this.label42, 4, 1);
            this.tbl_MeasureResult.Controls.Add(this.label43, 5, 1);
            this.tbl_MeasureResult.Controls.Add(this.label44, 8, 1);
            this.tbl_MeasureResult.Controls.Add(this.label45, 9, 1);
            this.tbl_MeasureResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl_MeasureResult.Location = new System.Drawing.Point(3, 433);
            this.tbl_MeasureResult.Name = "tbl_MeasureResult";
            this.tbl_MeasureResult.RowCount = 9;
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.366812F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.46725F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tbl_MeasureResult.Size = new System.Drawing.Size(613, 311);
            this.tbl_MeasureResult.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 34);
            this.label11.TabIndex = 0;
            this.label11.Text = "A1";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 101);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 34);
            this.label12.TabIndex = 0;
            this.label12.Text = "A2";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(301, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 34);
            this.label13.TabIndex = 0;
            this.label13.Text = "Ang1";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(301, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 34);
            this.label14.TabIndex = 0;
            this.label14.Text = "Ang2";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 135);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 34);
            this.label15.TabIndex = 0;
            this.label15.Text = "B1";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(3, 169);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 34);
            this.label16.TabIndex = 0;
            this.label16.Text = "B2";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(3, 237);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 34);
            this.label19.TabIndex = 0;
            this.label19.Text = "R2";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(3, 271);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 40);
            this.label20.TabIndex = 0;
            this.label20.Text = "t";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(3, 203);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 34);
            this.label18.TabIndex = 0;
            this.label18.Text = "R1";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(301, 237);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 34);
            this.label22.TabIndex = 0;
            this.label22.Text = "C2";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(301, 203);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 34);
            this.label21.TabIndex = 0;
            this.label21.Text = "C1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_A1Upper
            // 
            this.nud_A1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A1Upper.Location = new System.Drawing.Point(162, 70);
            this.nud_A1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A1Upper.Name = "nud_A1Upper";
            this.nud_A1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A1Upper.Size = new System.Drawing.Size(50, 23);
            this.nud_A1Upper.TabIndex = 0;
            this.nud_A1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(301, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 34);
            this.label17.TabIndex = 0;
            this.label17.Text = "BC";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txb_A1
            // 
            this.txb_A1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_A1.Location = new System.Drawing.Point(63, 70);
            this.txb_A1.Name = "txb_A1";
            this.txb_A1.ReadOnly = true;
            this.txb_A1.Size = new System.Drawing.Size(54, 23);
            this.txb_A1.TabIndex = 1;
            this.txb_A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_A2
            // 
            this.txb_A2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_A2.Location = new System.Drawing.Point(63, 104);
            this.txb_A2.Name = "txb_A2";
            this.txb_A2.ReadOnly = true;
            this.txb_A2.Size = new System.Drawing.Size(54, 23);
            this.txb_A2.TabIndex = 1;
            this.txb_A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_B1
            // 
            this.txb_B1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_B1.Location = new System.Drawing.Point(63, 138);
            this.txb_B1.Name = "txb_B1";
            this.txb_B1.ReadOnly = true;
            this.txb_B1.Size = new System.Drawing.Size(54, 23);
            this.txb_B1.TabIndex = 1;
            this.txb_B1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_B2
            // 
            this.txb_B2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_B2.Location = new System.Drawing.Point(63, 172);
            this.txb_B2.Name = "txb_B2";
            this.txb_B2.ReadOnly = true;
            this.txb_B2.Size = new System.Drawing.Size(54, 23);
            this.txb_B2.TabIndex = 1;
            this.txb_B2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_R1
            // 
            this.txb_R1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_R1.Location = new System.Drawing.Point(63, 206);
            this.txb_R1.Name = "txb_R1";
            this.txb_R1.ReadOnly = true;
            this.txb_R1.Size = new System.Drawing.Size(54, 23);
            this.txb_R1.TabIndex = 1;
            this.txb_R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // R2
            // 
            this.R2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.R2.Location = new System.Drawing.Point(63, 240);
            this.R2.Name = "R2";
            this.R2.ReadOnly = true;
            this.R2.Size = new System.Drawing.Size(54, 23);
            this.R2.TabIndex = 1;
            this.R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // t
            // 
            this.t.Dock = System.Windows.Forms.DockStyle.Fill;
            this.t.Location = new System.Drawing.Point(63, 274);
            this.t.Name = "t";
            this.t.ReadOnly = true;
            this.t.Size = new System.Drawing.Size(54, 23);
            this.t.TabIndex = 1;
            this.t.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Ang1
            // 
            this.txb_Ang1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Ang1.Location = new System.Drawing.Point(361, 70);
            this.txb_Ang1.Name = "txb_Ang1";
            this.txb_Ang1.ReadOnly = true;
            this.txb_Ang1.Size = new System.Drawing.Size(54, 23);
            this.txb_Ang1.TabIndex = 1;
            this.txb_Ang1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Ang2
            // 
            this.txb_Ang2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Ang2.Location = new System.Drawing.Point(361, 104);
            this.txb_Ang2.Name = "txb_Ang2";
            this.txb_Ang2.ReadOnly = true;
            this.txb_Ang2.Size = new System.Drawing.Size(54, 23);
            this.txb_Ang2.TabIndex = 1;
            this.txb_Ang2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_BC
            // 
            this.txb_BC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_BC.Location = new System.Drawing.Point(361, 138);
            this.txb_BC.Name = "txb_BC";
            this.txb_BC.ReadOnly = true;
            this.txb_BC.Size = new System.Drawing.Size(54, 23);
            this.txb_BC.TabIndex = 1;
            this.txb_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_C2
            // 
            this.txb_C2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_C2.Location = new System.Drawing.Point(361, 240);
            this.txb_C2.Name = "txb_C2";
            this.txb_C2.ReadOnly = true;
            this.txb_C2.Size = new System.Drawing.Size(54, 23);
            this.txb_C2.TabIndex = 1;
            this.txb_C2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_C1
            // 
            this.txb_C1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_C1.Location = new System.Drawing.Point(361, 206);
            this.txb_C1.Name = "txb_C1";
            this.txb_C1.ReadOnly = true;
            this.txb_C1.Size = new System.Drawing.Size(54, 23);
            this.txb_C1.TabIndex = 1;
            this.txb_C1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(421, 237);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 16);
            this.label30.TabIndex = 0;
            this.label30.Text = "um";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(421, 203);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(26, 16);
            this.label31.TabIndex = 0;
            this.label31.Text = "um";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(421, 135);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(26, 16);
            this.label32.TabIndex = 0;
            this.label32.Text = "um";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(421, 101);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(31, 16);
            this.label33.TabIndex = 0;
            this.label33.Text = "deg";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(421, 67);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(31, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "deg";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.tbl_MeasureResult.SetColumnSpan(this.label35, 2);
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(3, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(114, 54);
            this.label35.TabIndex = 0;
            this.label35.Text = "量測結果\r\nMesureResult";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(123, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 16);
            this.label23.TabIndex = 0;
            this.label23.Text = "um";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(123, 101);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 16);
            this.label24.TabIndex = 0;
            this.label24.Text = "um";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(123, 135);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 16);
            this.label25.TabIndex = 0;
            this.label25.Text = "um";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(123, 169);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 16);
            this.label26.TabIndex = 0;
            this.label26.Text = "um";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(123, 203);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 16);
            this.label27.TabIndex = 0;
            this.label27.Text = "um";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(123, 237);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 16);
            this.label28.TabIndex = 0;
            this.label28.Text = "um";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(123, 271);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(26, 16);
            this.label29.TabIndex = 0;
            this.label29.Text = "um";
            // 
            // nud_A1Lower
            // 
            this.nud_A1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A1Lower.Location = new System.Drawing.Point(230, 70);
            this.nud_A1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A1Lower.Name = "nud_A1Lower";
            this.nud_A1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_A1Lower.TabIndex = 0;
            this.nud_A1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_A2Upper
            // 
            this.nud_A2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A2Upper.Location = new System.Drawing.Point(162, 104);
            this.nud_A2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A2Upper.Name = "nud_A2Upper";
            this.nud_A2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_A2Upper.TabIndex = 0;
            this.nud_A2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_A2Lower
            // 
            this.nud_A2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_A2Lower.Location = new System.Drawing.Point(230, 104);
            this.nud_A2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_A2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_A2Lower.Name = "nud_A2Lower";
            this.nud_A2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_A2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_A2Lower.TabIndex = 0;
            this.nud_A2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_A2Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_B1Upper
            // 
            this.nud_B1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B1Upper.Location = new System.Drawing.Point(162, 138);
            this.nud_B1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B1Upper.Name = "nud_B1Upper";
            this.nud_B1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_B1Upper.TabIndex = 0;
            this.nud_B1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_B2Upper
            // 
            this.nud_B2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B2Upper.Location = new System.Drawing.Point(162, 172);
            this.nud_B2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B2Upper.Name = "nud_B2Upper";
            this.nud_B2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_B2Upper.TabIndex = 0;
            this.nud_B2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_B2Lower
            // 
            this.nud_B2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B2Lower.Location = new System.Drawing.Point(230, 172);
            this.nud_B2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B2Lower.Name = "nud_B2Lower";
            this.nud_B2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_B2Lower.TabIndex = 0;
            this.nud_B2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B2Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_B1Lower
            // 
            this.nud_B1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_B1Lower.Location = new System.Drawing.Point(230, 138);
            this.nud_B1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_B1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_B1Lower.Name = "nud_B1Lower";
            this.nud_B1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_B1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_B1Lower.TabIndex = 0;
            this.nud_B1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_B1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_R1Upper
            // 
            this.nud_R1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R1Upper.Location = new System.Drawing.Point(162, 206);
            this.nud_R1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R1Upper.Name = "nud_R1Upper";
            this.nud_R1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_R1Upper.TabIndex = 0;
            this.nud_R1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_R2Upper
            // 
            this.nud_R2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R2Upper.Location = new System.Drawing.Point(162, 240);
            this.nud_R2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R2Upper.Name = "nud_R2Upper";
            this.nud_R2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_R2Upper.TabIndex = 0;
            this.nud_R2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_tUpper
            // 
            this.nud_tUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_tUpper.Location = new System.Drawing.Point(162, 274);
            this.nud_tUpper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tUpper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_tUpper.Name = "nud_tUpper";
            this.nud_tUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_tUpper.Size = new System.Drawing.Size(49, 23);
            this.nud_tUpper.TabIndex = 0;
            this.nud_tUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tUpper.Value = new decimal(new int[] {
            900,
            0,
            0,
            0});
            // 
            // nud_tLower
            // 
            this.nud_tLower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_tLower.Location = new System.Drawing.Point(230, 274);
            this.nud_tLower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tLower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_tLower.Name = "nud_tLower";
            this.nud_tLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_tLower.Size = new System.Drawing.Size(49, 23);
            this.nud_tLower.TabIndex = 0;
            this.nud_tLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_tLower.Value = new decimal(new int[] {
            700,
            0,
            0,
            0});
            // 
            // nud_R2Lower
            // 
            this.nud_R2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R2Lower.Location = new System.Drawing.Point(230, 240);
            this.nud_R2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R2Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R2Lower.Name = "nud_R2Lower";
            this.nud_R2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_R2Lower.TabIndex = 0;
            this.nud_R2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R2Lower.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_R1Lower
            // 
            this.nud_R1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_R1Lower.Location = new System.Drawing.Point(230, 206);
            this.nud_R1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_R1Lower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_R1Lower.Name = "nud_R1Lower";
            this.nud_R1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_R1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_R1Lower.TabIndex = 0;
            this.nud_R1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_R1Lower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_BCUpper
            // 
            this.nud_BCUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BCUpper.Location = new System.Drawing.Point(464, 138);
            this.nud_BCUpper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_BCUpper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_BCUpper.Name = "nud_BCUpper";
            this.nud_BCUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BCUpper.Size = new System.Drawing.Size(49, 23);
            this.nud_BCUpper.TabIndex = 0;
            this.nud_BCUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BCUpper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_BCLower
            // 
            this.nud_BCLower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_BCLower.Location = new System.Drawing.Point(536, 138);
            this.nud_BCLower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_BCLower.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_BCLower.Name = "nud_BCLower";
            this.nud_BCLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_BCLower.Size = new System.Drawing.Size(49, 23);
            this.nud_BCLower.TabIndex = 0;
            this.nud_BCLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_BCLower.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nud_Ang1Upper
            // 
            this.nud_Ang1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang1Upper.Location = new System.Drawing.Point(464, 70);
            this.nud_Ang1Upper.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang1Upper.Name = "nud_Ang1Upper";
            this.nud_Ang1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang1Upper.TabIndex = 0;
            this.nud_Ang1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang1Upper.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nud_Ang1Lower
            // 
            this.nud_Ang1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang1Lower.Location = new System.Drawing.Point(536, 70);
            this.nud_Ang1Lower.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang1Lower.Name = "nud_Ang1Lower";
            this.nud_Ang1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang1Lower.TabIndex = 0;
            this.nud_Ang1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang1Lower.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_Ang2Upper
            // 
            this.nud_Ang2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang2Upper.Location = new System.Drawing.Point(464, 104);
            this.nud_Ang2Upper.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang2Upper.Name = "nud_Ang2Upper";
            this.nud_Ang2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang2Upper.TabIndex = 0;
            this.nud_Ang2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang2Upper.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nud_Ang2Lower
            // 
            this.nud_Ang2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Ang2Lower.Location = new System.Drawing.Point(536, 104);
            this.nud_Ang2Lower.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Ang2Lower.Name = "nud_Ang2Lower";
            this.nud_Ang2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_Ang2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_Ang2Lower.TabIndex = 0;
            this.nud_Ang2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_Ang2Lower.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // nud_C1Upper
            // 
            this.nud_C1Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C1Upper.Location = new System.Drawing.Point(464, 206);
            this.nud_C1Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C1Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_C1Upper.Name = "nud_C1Upper";
            this.nud_C1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C1Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_C1Upper.TabIndex = 0;
            this.nud_C1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C1Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_C2Upper
            // 
            this.nud_C2Upper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C2Upper.Location = new System.Drawing.Point(464, 240);
            this.nud_C2Upper.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C2Upper.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_C2Upper.Name = "nud_C2Upper";
            this.nud_C2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C2Upper.Size = new System.Drawing.Size(49, 23);
            this.nud_C2Upper.TabIndex = 0;
            this.nud_C2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C2Upper.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // nud_C1Lower
            // 
            this.nud_C1Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C1Lower.Location = new System.Drawing.Point(536, 206);
            this.nud_C1Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C1Lower.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_C1Lower.Name = "nud_C1Lower";
            this.nud_C1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C1Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_C1Lower.TabIndex = 0;
            this.nud_C1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C1Lower.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // nud_C2Lower
            // 
            this.nud_C2Lower.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_C2Lower.Location = new System.Drawing.Point(536, 240);
            this.nud_C2Lower.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_C2Lower.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_C2Lower.Name = "nud_C2Lower";
            this.nud_C2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_C2Lower.Size = new System.Drawing.Size(49, 23);
            this.nud_C2Lower.TabIndex = 0;
            this.nud_C2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_C2Lower.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(162, 13);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(62, 54);
            this.label41.TabIndex = 0;
            this.label41.Text = "上限值\r\nUpper";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(230, 13);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(65, 54);
            this.label42.TabIndex = 0;
            this.label42.Text = "下限值\r\nLower";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.tbl_MeasureResult.SetColumnSpan(this.label43, 2);
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(301, 13);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(114, 54);
            this.label43.TabIndex = 0;
            this.label43.Text = "量測結果\r\nMesureResult";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(464, 13);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(66, 54);
            this.label44.TabIndex = 0;
            this.label44.Text = "上限值\r\nUpper";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(536, 13);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(74, 54);
            this.label45.TabIndex = 0;
            this.label45.Text = "下限值\r\nLower";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbp_Edge);
            this.tabControl1.Controls.Add(this.tbp_Notch);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1121, 822);
            this.tabControl1.TabIndex = 2;
            // 
            // tbp_Notch
            // 
            this.tbp_Notch.Controls.Add(this.tableLayoutPanel5);
            this.tbp_Notch.Location = new System.Drawing.Point(4, 25);
            this.tbp_Notch.Name = "tbp_Notch";
            this.tbp_Notch.Padding = new System.Windows.Forms.Padding(3);
            this.tbp_Notch.Size = new System.Drawing.Size(1113, 793);
            this.tbp_Notch.TabIndex = 1;
            this.tbp_Notch.Text = "Notch";
            this.tbp_Notch.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.01807F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.98193F));
            this.tableLayoutPanel5.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.802817F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1107, 787);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Controls.Add(this.tableLayoutPanel6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(437, 781);
            this.panel2.TabIndex = 2;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.97298F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.02703F));
            this.tableLayoutPanel7.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.nud_NotchGrayMax, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.label51, 1, 9);
            this.tableLayoutPanel7.Controls.Add(this.label54, 1, 8);
            this.tableLayoutPanel7.Controls.Add(this.label55, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.label56, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.nud_b2Ang, 2, 3);
            this.tableLayoutPanel7.Controls.Add(this.label57, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.label58, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.nud_u1Ratio, 2, 4);
            this.tableLayoutPanel7.Controls.Add(this.nud_u2Ratio, 2, 5);
            this.tableLayoutPanel7.Controls.Add(this.nud_VrWidth1, 2, 7);
            this.tableLayoutPanel7.Controls.Add(this.nud_PinRadius, 2, 9);
            this.tableLayoutPanel7.Controls.Add(this.nud_VR12Angle, 2, 10);
            this.tableLayoutPanel7.Controls.Add(this.nud_b1Ang, 2, 2);
            this.tableLayoutPanel7.Controls.Add(this.nud_VrWidth2, 2, 8);
            this.tableLayoutPanel7.Controls.Add(this.label53, 1, 7);
            this.tableLayoutPanel7.Controls.Add(this.label52, 1, 10);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox1, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox4, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.pictureBox6, 0, 7);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(22, 202);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(30);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 12;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(397, 549);
            this.tableLayoutPanel7.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(141, 3);
            this.label50.Margin = new System.Windows.Forms.Padding(3);
            this.label50.Name = "label50";
            this.label50.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label50.Size = new System.Drawing.Size(181, 16);
            this.label50.TabIndex = 1;
            this.label50.Text = "最大灰階值 GrayMax (Auto : -1)";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_NotchGrayMax
            // 
            this.nud_NotchGrayMax.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_NotchGrayMax.Location = new System.Drawing.Point(329, 3);
            this.nud_NotchGrayMax.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_NotchGrayMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_NotchGrayMax.Name = "nud_NotchGrayMax";
            this.nud_NotchGrayMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_NotchGrayMax.Size = new System.Drawing.Size(64, 23);
            this.nud_NotchGrayMax.TabIndex = 0;
            this.nud_NotchGrayMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_NotchGrayMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(141, 300);
            this.label51.Margin = new System.Windows.Forms.Padding(3);
            this.label51.Name = "label51";
            this.label51.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label51.Size = new System.Drawing.Size(106, 16);
            this.label51.TabIndex = 1;
            this.label51.Text = "鑲嵌Pin半徑 [mm]";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(141, 267);
            this.label54.Margin = new System.Windows.Forms.Padding(3);
            this.label54.Name = "label54";
            this.label54.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label54.Size = new System.Drawing.Size(165, 16);
            this.label54.TabIndex = 1;
            this.label54.Text = "槽口底半徑計算寬度(右) [um]";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(141, 69);
            this.label55.Margin = new System.Windows.Forms.Padding(3);
            this.label55.Name = "label55";
            this.label55.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label55.Size = new System.Drawing.Size(162, 16);
            this.label55.TabIndex = 1;
            this.label55.Text = "槽口起點 切線角度(左) [Deg]";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(141, 102);
            this.label56.Margin = new System.Windows.Forms.Padding(3);
            this.label56.Name = "label56";
            this.label56.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label56.Size = new System.Drawing.Size(162, 16);
            this.label56.TabIndex = 1;
            this.label56.Text = "槽口起點 切線角度(右) [Deg]";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_b2Ang
            // 
            this.nud_b2Ang.DecimalPlaces = 2;
            this.nud_b2Ang.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_b2Ang.Location = new System.Drawing.Point(329, 102);
            this.nud_b2Ang.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_b2Ang.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_b2Ang.Name = "nud_b2Ang";
            this.nud_b2Ang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_b2Ang.Size = new System.Drawing.Size(64, 23);
            this.nud_b2Ang.TabIndex = 0;
            this.nud_b2Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_b2Ang.Value = new decimal(new int[] {
            21,
            0,
            0,
            -2147483648});
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(141, 168);
            this.label57.Margin = new System.Windows.Forms.Padding(3);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(115, 16);
            this.label57.TabIndex = 1;
            this.label57.Text = "角度終點比率 h2:Vh";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(141, 135);
            this.label58.Margin = new System.Windows.Forms.Padding(3);
            this.label58.Name = "label58";
            this.label58.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label58.Size = new System.Drawing.Size(115, 16);
            this.label58.TabIndex = 1;
            this.label58.Text = "角度起點比率 h1:Vh";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nud_u1Ratio
            // 
            this.nud_u1Ratio.DecimalPlaces = 2;
            this.nud_u1Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u1Ratio.Location = new System.Drawing.Point(329, 135);
            this.nud_u1Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_u1Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u1Ratio.Name = "nud_u1Ratio";
            this.nud_u1Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_u1Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_u1Ratio.TabIndex = 0;
            this.nud_u1Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_u1Ratio.Value = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            // 
            // nud_u2Ratio
            // 
            this.nud_u2Ratio.DecimalPlaces = 2;
            this.nud_u2Ratio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u2Ratio.Location = new System.Drawing.Point(329, 168);
            this.nud_u2Ratio.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_u2Ratio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_u2Ratio.Name = "nud_u2Ratio";
            this.nud_u2Ratio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_u2Ratio.Size = new System.Drawing.Size(64, 23);
            this.nud_u2Ratio.TabIndex = 0;
            this.nud_u2Ratio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_u2Ratio.Value = new decimal(new int[] {
            7,
            0,
            0,
            65536});
            // 
            // nud_VrWidth1
            // 
            this.nud_VrWidth1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth1.Location = new System.Drawing.Point(329, 234);
            this.nud_VrWidth1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_VrWidth1.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_VrWidth1.Name = "nud_VrWidth1";
            this.nud_VrWidth1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrWidth1.Size = new System.Drawing.Size(64, 23);
            this.nud_VrWidth1.TabIndex = 0;
            this.nud_VrWidth1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrWidth1.Value = new decimal(new int[] {
            600,
            0,
            0,
            0});
            // 
            // nud_PinRadius
            // 
            this.nud_PinRadius.DecimalPlaces = 1;
            this.nud_PinRadius.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_PinRadius.Location = new System.Drawing.Point(329, 300);
            this.nud_PinRadius.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_PinRadius.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_PinRadius.Name = "nud_PinRadius";
            this.nud_PinRadius.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_PinRadius.Size = new System.Drawing.Size(64, 23);
            this.nud_PinRadius.TabIndex = 0;
            this.nud_PinRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_PinRadius.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            // 
            // nud_VR12Angle
            // 
            this.nud_VR12Angle.DecimalPlaces = 2;
            this.nud_VR12Angle.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_VR12Angle.Location = new System.Drawing.Point(329, 333);
            this.nud_VR12Angle.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_VR12Angle.Name = "nud_VR12Angle";
            this.nud_VR12Angle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR12Angle.Size = new System.Drawing.Size(64, 23);
            this.nud_VR12Angle.TabIndex = 0;
            this.nud_VR12Angle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR12Angle.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // nud_b1Ang
            // 
            this.nud_b1Ang.DecimalPlaces = 2;
            this.nud_b1Ang.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_b1Ang.Location = new System.Drawing.Point(329, 69);
            this.nud_b1Ang.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_b1Ang.Name = "nud_b1Ang";
            this.nud_b1Ang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_b1Ang.Size = new System.Drawing.Size(64, 23);
            this.nud_b1Ang.TabIndex = 0;
            this.nud_b1Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_b1Ang.Value = new decimal(new int[] {
            21,
            0,
            0,
            0});
            // 
            // nud_VrWidth2
            // 
            this.nud_VrWidth2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth2.Location = new System.Drawing.Point(329, 267);
            this.nud_VrWidth2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_VrWidth2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_VrWidth2.Name = "nud_VrWidth2";
            this.nud_VrWidth2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrWidth2.Size = new System.Drawing.Size(64, 23);
            this.nud_VrWidth2.TabIndex = 0;
            this.nud_VrWidth2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrWidth2.Value = new decimal(new int[] {
            600,
            0,
            0,
            0});
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(141, 234);
            this.label53.Margin = new System.Windows.Forms.Padding(3);
            this.label53.Name = "label53";
            this.label53.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label53.Size = new System.Drawing.Size(165, 16);
            this.label53.TabIndex = 1;
            this.label53.Text = "槽口底半徑計算寬度(左) [um]";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(141, 333);
            this.label52.Margin = new System.Windows.Forms.Padding(3);
            this.label52.Name = "label52";
            this.label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label52.Size = new System.Drawing.Size(115, 16);
            this.label52.TabIndex = 1;
            this.label52.Text = "槽口肩排除角 [Deg]";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, 69);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(132, 60);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(3, 135);
            this.pictureBox4.Name = "pictureBox4";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox4, 2);
            this.pictureBox4.Size = new System.Drawing.Size(132, 60);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(3, 234);
            this.pictureBox6.Name = "pictureBox6";
            this.tableLayoutPanel7.SetRowSpan(this.pictureBox6, 2);
            this.pictureBox6.Size = new System.Drawing.Size(132, 60);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 6;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.Controls.Add(this.label46, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_LoadImage_Notch, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.btn_SaveRecipe_Notch, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.btn_LoadRecipe_Notch, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.label47, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label48, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label49, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.btn_MasureTest_Notch, 4, 1);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(19, 25);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.98551F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.0145F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(343, 69);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label46.Location = new System.Drawing.Point(3, 3);
            this.label46.Margin = new System.Windows.Forms.Padding(3);
            this.label46.Name = "label46";
            this.label46.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label46.Size = new System.Drawing.Size(51, 13);
            this.label46.TabIndex = 1;
            this.label46.Text = "開啟圖片";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_LoadImage_Notch
            // 
            this.btn_LoadImage_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadImage_Notch.BackgroundImage")));
            this.btn_LoadImage_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadImage_Notch.Location = new System.Drawing.Point(3, 22);
            this.btn_LoadImage_Notch.Name = "btn_LoadImage_Notch";
            this.btn_LoadImage_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadImage_Notch.TabIndex = 2;
            this.btn_LoadImage_Notch.UseVisualStyleBackColor = true;
            // 
            // btn_SaveRecipe_Notch
            // 
            this.btn_SaveRecipe_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_SaveRecipe_Notch.BackgroundImage")));
            this.btn_SaveRecipe_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_SaveRecipe_Notch.Location = new System.Drawing.Point(174, 22);
            this.btn_SaveRecipe_Notch.Name = "btn_SaveRecipe_Notch";
            this.btn_SaveRecipe_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_SaveRecipe_Notch.TabIndex = 2;
            this.btn_SaveRecipe_Notch.UseVisualStyleBackColor = true;
            // 
            // btn_LoadRecipe_Notch
            // 
            this.btn_LoadRecipe_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LoadRecipe_Notch.BackgroundImage")));
            this.btn_LoadRecipe_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_LoadRecipe_Notch.Location = new System.Drawing.Point(60, 22);
            this.btn_LoadRecipe_Notch.Name = "btn_LoadRecipe_Notch";
            this.btn_LoadRecipe_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_LoadRecipe_Notch.TabIndex = 5;
            this.btn_LoadRecipe_Notch.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label47.Location = new System.Drawing.Point(60, 3);
            this.label47.Margin = new System.Windows.Forms.Padding(3);
            this.label47.Name = "label47";
            this.label47.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label47.Size = new System.Drawing.Size(51, 13);
            this.label47.TabIndex = 1;
            this.label47.Text = "載入參數";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label48.Location = new System.Drawing.Point(174, 3);
            this.label48.Margin = new System.Windows.Forms.Padding(3);
            this.label48.Name = "label48";
            this.label48.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label48.Size = new System.Drawing.Size(51, 13);
            this.label48.TabIndex = 1;
            this.label48.Text = "儲存參數";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微軟正黑體", 8F);
            this.label49.Location = new System.Drawing.Point(231, 3);
            this.label49.Margin = new System.Windows.Forms.Padding(3);
            this.label49.Name = "label49";
            this.label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label49.Size = new System.Drawing.Size(51, 13);
            this.label49.TabIndex = 1;
            this.label49.Text = "量測計算";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_MasureTest_Notch
            // 
            this.btn_MasureTest_Notch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_MasureTest_Notch.BackgroundImage")));
            this.btn_MasureTest_Notch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_MasureTest_Notch.Location = new System.Drawing.Point(231, 22);
            this.btn_MasureTest_Notch.Name = "btn_MasureTest_Notch";
            this.btn_MasureTest_Notch.Size = new System.Drawing.Size(51, 43);
            this.btn_MasureTest_Notch.TabIndex = 5;
            this.btn_MasureTest_Notch.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.20035F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.799648F));
            this.tableLayoutPanel8.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.pictureBox5, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 2);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(446, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 4;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.250597F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.7494F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 317F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(658, 781);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Margin = new System.Windows.Forms.Padding(3);
            this.label60.Name = "label60";
            this.label60.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label60.Size = new System.Drawing.Size(613, 16);
            this.label60.TabIndex = 1;
            this.label60.Text = "影像視窗";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox5.Location = new System.Drawing.Point(3, 25);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(613, 402);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 10;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.463196F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.31059F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.84919F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.181329F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.02873F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.38779F));
            this.tableLayoutPanel9.Controls.Add(this.label61, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.label62, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.label63, 5, 2);
            this.tableLayoutPanel9.Controls.Add(this.label64, 5, 3);
            this.tableLayoutPanel9.Controls.Add(this.label65, 0, 4);
            this.tableLayoutPanel9.Controls.Add(this.label66, 0, 5);
            this.tableLayoutPanel9.Controls.Add(this.label67, 0, 7);
            this.tableLayoutPanel9.Controls.Add(this.label69, 0, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_VhUpper, 3, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vh, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vw, 1, 3);
            this.tableLayoutPanel9.Controls.Add(this.txb_Vr, 1, 4);
            this.tableLayoutPanel9.Controls.Add(this.txb_AngV, 1, 5);
            this.tableLayoutPanel9.Controls.Add(this.txb_P1, 1, 6);
            this.tableLayoutPanel9.Controls.Add(this.txb_P2, 1, 7);
            this.tableLayoutPanel9.Controls.Add(this.txb_VR1, 6, 2);
            this.tableLayoutPanel9.Controls.Add(this.txb_VR2, 6, 3);
            this.tableLayoutPanel9.Controls.Add(this.label76, 7, 3);
            this.tableLayoutPanel9.Controls.Add(this.label77, 7, 2);
            this.tableLayoutPanel9.Controls.Add(this.label78, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label79, 2, 2);
            this.tableLayoutPanel9.Controls.Add(this.label80, 2, 3);
            this.tableLayoutPanel9.Controls.Add(this.label81, 2, 4);
            this.tableLayoutPanel9.Controls.Add(this.label82, 2, 5);
            this.tableLayoutPanel9.Controls.Add(this.label83, 2, 6);
            this.tableLayoutPanel9.Controls.Add(this.label84, 2, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_VhLower, 4, 2);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR1Upper, 8, 2);
            this.tableLayoutPanel9.Controls.Add(this.label86, 3, 1);
            this.tableLayoutPanel9.Controls.Add(this.label87, 4, 1);
            this.tableLayoutPanel9.Controls.Add(this.label88, 5, 1);
            this.tableLayoutPanel9.Controls.Add(this.label89, 8, 1);
            this.tableLayoutPanel9.Controls.Add(this.label90, 9, 1);
            this.tableLayoutPanel9.Controls.Add(this.nud_VwUpper, 3, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VwLower, 4, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VrUpper, 3, 4);
            this.tableLayoutPanel9.Controls.Add(this.nud_VrLower, 4, 4);
            this.tableLayoutPanel9.Controls.Add(this.nud_AngVUpper, 3, 5);
            this.tableLayoutPanel9.Controls.Add(this.nud_P1Upper, 3, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_P1Lower, 4, 6);
            this.tableLayoutPanel9.Controls.Add(this.nud_P2Upper, 3, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_P2Lower, 4, 7);
            this.tableLayoutPanel9.Controls.Add(this.nud_AngVLower, 4, 5);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR1Lower, 9, 2);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR2Upper, 8, 3);
            this.tableLayoutPanel9.Controls.Add(this.nud_VR2Lower, 9, 3);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 433);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 9;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.366812F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.46725F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(613, 311);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(3, 67);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(54, 34);
            this.label61.TabIndex = 0;
            this.label61.Text = "Vh";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(3, 101);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(54, 34);
            this.label62.TabIndex = 0;
            this.label62.Text = "Vw";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(301, 67);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(54, 34);
            this.label63.TabIndex = 0;
            this.label63.Text = "VR1";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(301, 101);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(54, 34);
            this.label64.TabIndex = 0;
            this.label64.Text = "VR2";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 135);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(54, 34);
            this.label65.TabIndex = 0;
            this.label65.Text = "Vr";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(3, 169);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(54, 34);
            this.label66.TabIndex = 0;
            this.label66.Text = "AngV";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(3, 237);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(54, 34);
            this.label67.TabIndex = 0;
            this.label67.Text = "P2";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(3, 203);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(54, 34);
            this.label69.TabIndex = 0;
            this.label69.Text = "P1";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_VhUpper
            // 
            this.nud_VhUpper.DecimalPlaces = 3;
            this.nud_VhUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VhUpper.Location = new System.Drawing.Point(162, 70);
            this.nud_VhUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VhUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VhUpper.Name = "nud_VhUpper";
            this.nud_VhUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VhUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VhUpper.TabIndex = 0;
            this.nud_VhUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VhUpper.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            // 
            // txb_Vh
            // 
            this.txb_Vh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vh.Location = new System.Drawing.Point(63, 70);
            this.txb_Vh.Name = "txb_Vh";
            this.txb_Vh.ReadOnly = true;
            this.txb_Vh.Size = new System.Drawing.Size(54, 23);
            this.txb_Vh.TabIndex = 1;
            this.txb_Vh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Vw
            // 
            this.txb_Vw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vw.Location = new System.Drawing.Point(63, 104);
            this.txb_Vw.Name = "txb_Vw";
            this.txb_Vw.ReadOnly = true;
            this.txb_Vw.Size = new System.Drawing.Size(54, 23);
            this.txb_Vw.TabIndex = 1;
            this.txb_Vw.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_Vr
            // 
            this.txb_Vr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_Vr.Location = new System.Drawing.Point(63, 138);
            this.txb_Vr.Name = "txb_Vr";
            this.txb_Vr.ReadOnly = true;
            this.txb_Vr.Size = new System.Drawing.Size(54, 23);
            this.txb_Vr.TabIndex = 1;
            this.txb_Vr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_AngV
            // 
            this.txb_AngV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_AngV.Location = new System.Drawing.Point(63, 172);
            this.txb_AngV.Name = "txb_AngV";
            this.txb_AngV.ReadOnly = true;
            this.txb_AngV.Size = new System.Drawing.Size(54, 23);
            this.txb_AngV.TabIndex = 1;
            this.txb_AngV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_P1
            // 
            this.txb_P1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_P1.Location = new System.Drawing.Point(63, 206);
            this.txb_P1.Name = "txb_P1";
            this.txb_P1.ReadOnly = true;
            this.txb_P1.Size = new System.Drawing.Size(54, 23);
            this.txb_P1.TabIndex = 1;
            this.txb_P1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_P2
            // 
            this.txb_P2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_P2.Location = new System.Drawing.Point(63, 240);
            this.txb_P2.Name = "txb_P2";
            this.txb_P2.ReadOnly = true;
            this.txb_P2.Size = new System.Drawing.Size(54, 23);
            this.txb_P2.TabIndex = 1;
            this.txb_P2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_VR1
            // 
            this.txb_VR1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_VR1.Location = new System.Drawing.Point(361, 70);
            this.txb_VR1.Name = "txb_VR1";
            this.txb_VR1.ReadOnly = true;
            this.txb_VR1.Size = new System.Drawing.Size(54, 23);
            this.txb_VR1.TabIndex = 1;
            this.txb_VR1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txb_VR2
            // 
            this.txb_VR2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txb_VR2.Location = new System.Drawing.Point(361, 104);
            this.txb_VR2.Name = "txb_VR2";
            this.txb_VR2.ReadOnly = true;
            this.txb_VR2.Size = new System.Drawing.Size(54, 23);
            this.txb_VR2.TabIndex = 1;
            this.txb_VR2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(421, 101);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(30, 16);
            this.label76.TabIndex = 0;
            this.label76.Text = "mm";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(421, 67);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(30, 16);
            this.label77.TabIndex = 0;
            this.label77.Text = "mm";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.tableLayoutPanel9.SetColumnSpan(this.label78, 2);
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(3, 13);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(114, 54);
            this.label78.TabIndex = 0;
            this.label78.Text = "量測結果\r\nMesureResult";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(123, 67);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(30, 16);
            this.label79.TabIndex = 0;
            this.label79.Text = "mm";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(123, 101);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(30, 16);
            this.label80.TabIndex = 0;
            this.label80.Text = "mm";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(123, 135);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(30, 16);
            this.label81.TabIndex = 0;
            this.label81.Text = "mm";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(123, 169);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(31, 16);
            this.label82.TabIndex = 0;
            this.label82.Text = "deg";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(123, 203);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(30, 16);
            this.label83.TabIndex = 0;
            this.label83.Text = "mm";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(123, 237);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(30, 16);
            this.label84.TabIndex = 0;
            this.label84.Text = "mm";
            // 
            // nud_VhLower
            // 
            this.nud_VhLower.DecimalPlaces = 3;
            this.nud_VhLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VhLower.Location = new System.Drawing.Point(230, 70);
            this.nud_VhLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VhLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VhLower.Name = "nud_VhLower";
            this.nud_VhLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VhLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VhLower.TabIndex = 0;
            this.nud_VhLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VhLower.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_VR1Upper
            // 
            this.nud_VR1Upper.DecimalPlaces = 3;
            this.nud_VR1Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR1Upper.Location = new System.Drawing.Point(464, 70);
            this.nud_VR1Upper.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR1Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR1Upper.Name = "nud_VR1Upper";
            this.nud_VR1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR1Upper.Size = new System.Drawing.Size(66, 23);
            this.nud_VR1Upper.TabIndex = 0;
            this.nud_VR1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR1Upper.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(162, 13);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(62, 54);
            this.label86.TabIndex = 0;
            this.label86.Text = "上限值\r\nUpper";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(230, 13);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(65, 54);
            this.label87.TabIndex = 0;
            this.label87.Text = "下限值\r\nLower";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.tableLayoutPanel9.SetColumnSpan(this.label88, 2);
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(301, 13);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(114, 54);
            this.label88.TabIndex = 0;
            this.label88.Text = "量測結果\r\nMesureResult";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(464, 13);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(66, 54);
            this.label89.TabIndex = 0;
            this.label89.Text = "上限值\r\nUpper";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(536, 13);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(74, 54);
            this.label90.TabIndex = 0;
            this.label90.Text = "下限值\r\nLower";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_VwUpper
            // 
            this.nud_VwUpper.DecimalPlaces = 3;
            this.nud_VwUpper.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_VwUpper.Location = new System.Drawing.Point(162, 104);
            this.nud_VwUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VwUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VwUpper.Name = "nud_VwUpper";
            this.nud_VwUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VwUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VwUpper.TabIndex = 0;
            this.nud_VwUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VwUpper.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_VwLower
            // 
            this.nud_VwLower.DecimalPlaces = 3;
            this.nud_VwLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VwLower.Location = new System.Drawing.Point(230, 104);
            this.nud_VwLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VwLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VwLower.Name = "nud_VwLower";
            this.nud_VwLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VwLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VwLower.TabIndex = 0;
            this.nud_VwLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VwLower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_VrUpper
            // 
            this.nud_VrUpper.DecimalPlaces = 3;
            this.nud_VrUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VrUpper.Location = new System.Drawing.Point(162, 138);
            this.nud_VrUpper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VrUpper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VrUpper.Name = "nud_VrUpper";
            this.nud_VrUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_VrUpper.TabIndex = 0;
            this.nud_VrUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrUpper.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_VrLower
            // 
            this.nud_VrLower.DecimalPlaces = 3;
            this.nud_VrLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VrLower.Location = new System.Drawing.Point(230, 138);
            this.nud_VrLower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_VrLower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VrLower.Name = "nud_VrLower";
            this.nud_VrLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VrLower.Size = new System.Drawing.Size(65, 23);
            this.nud_VrLower.TabIndex = 0;
            this.nud_VrLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VrLower.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_AngVUpper
            // 
            this.nud_AngVUpper.DecimalPlaces = 1;
            this.nud_AngVUpper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_AngVUpper.Location = new System.Drawing.Point(162, 172);
            this.nud_AngVUpper.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nud_AngVUpper.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_AngVUpper.Name = "nud_AngVUpper";
            this.nud_AngVUpper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngVUpper.Size = new System.Drawing.Size(62, 23);
            this.nud_AngVUpper.TabIndex = 0;
            this.nud_AngVUpper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngVUpper.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // nud_P1Upper
            // 
            this.nud_P1Upper.DecimalPlaces = 3;
            this.nud_P1Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P1Upper.Location = new System.Drawing.Point(162, 206);
            this.nud_P1Upper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P1Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P1Upper.Name = "nud_P1Upper";
            this.nud_P1Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P1Upper.Size = new System.Drawing.Size(62, 23);
            this.nud_P1Upper.TabIndex = 0;
            this.nud_P1Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P1Upper.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // nud_P1Lower
            // 
            this.nud_P1Lower.DecimalPlaces = 3;
            this.nud_P1Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P1Lower.Location = new System.Drawing.Point(230, 206);
            this.nud_P1Lower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P1Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P1Lower.Name = "nud_P1Lower";
            this.nud_P1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P1Lower.Size = new System.Drawing.Size(65, 23);
            this.nud_P1Lower.TabIndex = 0;
            this.nud_P1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P1Lower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_P2Upper
            // 
            this.nud_P2Upper.DecimalPlaces = 3;
            this.nud_P2Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P2Upper.Location = new System.Drawing.Point(162, 240);
            this.nud_P2Upper.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P2Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P2Upper.Name = "nud_P2Upper";
            this.nud_P2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P2Upper.Size = new System.Drawing.Size(62, 23);
            this.nud_P2Upper.TabIndex = 0;
            this.nud_P2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P2Upper.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // nud_P2Lower
            // 
            this.nud_P2Lower.DecimalPlaces = 3;
            this.nud_P2Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_P2Lower.Location = new System.Drawing.Point(230, 240);
            this.nud_P2Lower.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_P2Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_P2Lower.Name = "nud_P2Lower";
            this.nud_P2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_P2Lower.Size = new System.Drawing.Size(65, 23);
            this.nud_P2Lower.TabIndex = 0;
            this.nud_P2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_P2Lower.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_AngVLower
            // 
            this.nud_AngVLower.DecimalPlaces = 1;
            this.nud_AngVLower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_AngVLower.Location = new System.Drawing.Point(230, 172);
            this.nud_AngVLower.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.nud_AngVLower.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_AngVLower.Name = "nud_AngVLower";
            this.nud_AngVLower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_AngVLower.Size = new System.Drawing.Size(65, 23);
            this.nud_AngVLower.TabIndex = 0;
            this.nud_AngVLower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_AngVLower.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // nud_VR1Lower
            // 
            this.nud_VR1Lower.DecimalPlaces = 3;
            this.nud_VR1Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR1Lower.Location = new System.Drawing.Point(536, 70);
            this.nud_VR1Lower.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR1Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR1Lower.Name = "nud_VR1Lower";
            this.nud_VR1Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR1Lower.Size = new System.Drawing.Size(66, 23);
            this.nud_VR1Lower.TabIndex = 0;
            this.nud_VR1Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR1Lower.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // nud_VR2Upper
            // 
            this.nud_VR2Upper.DecimalPlaces = 3;
            this.nud_VR2Upper.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR2Upper.Location = new System.Drawing.Point(464, 104);
            this.nud_VR2Upper.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR2Upper.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR2Upper.Name = "nud_VR2Upper";
            this.nud_VR2Upper.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR2Upper.Size = new System.Drawing.Size(66, 23);
            this.nud_VR2Upper.TabIndex = 0;
            this.nud_VR2Upper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR2Upper.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_VR2Lower
            // 
            this.nud_VR2Lower.DecimalPlaces = 3;
            this.nud_VR2Lower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_VR2Lower.Location = new System.Drawing.Point(536, 104);
            this.nud_VR2Lower.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_VR2Lower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.nud_VR2Lower.Name = "nud_VR2Lower";
            this.nud_VR2Lower.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nud_VR2Lower.Size = new System.Drawing.Size(66, 23);
            this.nud_VR2Lower.TabIndex = 0;
            this.nud_VR2Lower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_VR2Lower.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // RecipeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 822);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RecipeForm";
            this.Text = "RecipeForm";
            this.tbp_Edge.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tbc_EdgeType.ResumeLayout(false);
            this.tbp_TypeB.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bu1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_bv1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleStart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngleTop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_View)).EndInit();
            this.tbl_MeasureResult.ResumeLayout(false);
            this.tbl_MeasureResult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_A2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_B1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_R1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_BCLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ang2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_C2Lower)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tbp_Notch.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NotchGrayMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b2Ang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u1Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_u2Ratio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PinRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR12Angle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_b1Ang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrWidth2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VhLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VwLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VrLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVUpper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_P2Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AngVLower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR1Lower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Upper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_VR2Lower)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tbp_Edge;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btn_LoadImage_Edge;
        private System.Windows.Forms.Button btn_SaveRecipe_Edge;
        private System.Windows.Forms.Button btn_LoadRecipe_Edge;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btn_MasureTest_Edge;
        private System.Windows.Forms.TabControl tbc_EdgeType;
        private System.Windows.Forms.TabPage tbp_TypeB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nud_bu2Ratio;
        private System.Windows.Forms.NumericUpDown nud_bv2Ratio;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_bu1Ratio;
        private System.Windows.Forms.NumericUpDown nud_bv1Ratio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nud_AngleStart1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_AngleTop1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nud_AngleStart2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_AngleTop2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox ptb_View;
        private System.Windows.Forms.TableLayoutPanel tbl_MeasureResult;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nud_A1Upper;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txb_A1;
        private System.Windows.Forms.TextBox txb_A2;
        private System.Windows.Forms.TextBox txb_B1;
        private System.Windows.Forms.TextBox txb_B2;
        private System.Windows.Forms.TextBox txb_R1;
        private System.Windows.Forms.TextBox R2;
        private System.Windows.Forms.TextBox t;
        private System.Windows.Forms.TextBox txb_Ang1;
        private System.Windows.Forms.TextBox txb_Ang2;
        private System.Windows.Forms.TextBox txb_BC;
        private System.Windows.Forms.TextBox txb_C2;
        private System.Windows.Forms.TextBox txb_C1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown nud_A1Lower;
        private System.Windows.Forms.NumericUpDown nud_A2Upper;
        private System.Windows.Forms.NumericUpDown nud_A2Lower;
        private System.Windows.Forms.NumericUpDown nud_B1Upper;
        private System.Windows.Forms.NumericUpDown nud_B2Upper;
        private System.Windows.Forms.NumericUpDown nud_B2Lower;
        private System.Windows.Forms.NumericUpDown nud_B1Lower;
        private System.Windows.Forms.NumericUpDown nud_R1Upper;
        private System.Windows.Forms.NumericUpDown nud_R2Upper;
        private System.Windows.Forms.NumericUpDown nud_tUpper;
        private System.Windows.Forms.NumericUpDown nud_tLower;
        private System.Windows.Forms.NumericUpDown nud_R2Lower;
        private System.Windows.Forms.NumericUpDown nud_R1Lower;
        private System.Windows.Forms.NumericUpDown nud_BCUpper;
        private System.Windows.Forms.NumericUpDown nud_BCLower;
        private System.Windows.Forms.NumericUpDown nud_Ang1Upper;
        private System.Windows.Forms.NumericUpDown nud_Ang1Lower;
        private System.Windows.Forms.NumericUpDown nud_Ang2Upper;
        private System.Windows.Forms.NumericUpDown nud_Ang2Lower;
        private System.Windows.Forms.NumericUpDown nud_C1Upper;
        private System.Windows.Forms.NumericUpDown nud_C2Upper;
        private System.Windows.Forms.NumericUpDown nud_C1Lower;
        private System.Windows.Forms.NumericUpDown nud_C2Lower;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TabPage tbp_Notch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown nud_NotchGrayMax;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown nud_VrWidth1;
        private System.Windows.Forms.NumericUpDown nud_PinRadius;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.NumericUpDown nud_u1Ratio;
        private System.Windows.Forms.NumericUpDown nud_u2Ratio;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown nud_VrWidth2;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.NumericUpDown nud_b2Ang;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.NumericUpDown nud_VR12Angle;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown nud_b1Ang;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btn_LoadImage_Notch;
        private System.Windows.Forms.Button btn_SaveRecipe_Notch;
        private System.Windows.Forms.Button btn_LoadRecipe_Notch;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button btn_MasureTest_Notch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.NumericUpDown nud_VhUpper;
        private System.Windows.Forms.TextBox txb_Vh;
        private System.Windows.Forms.TextBox txb_Vw;
        private System.Windows.Forms.TextBox txb_Vr;
        private System.Windows.Forms.TextBox txb_AngV;
        private System.Windows.Forms.TextBox txb_P1;
        private System.Windows.Forms.TextBox txb_P2;
        private System.Windows.Forms.TextBox txb_VR1;
        private System.Windows.Forms.TextBox txb_VR2;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.NumericUpDown nud_VhLower;
        private System.Windows.Forms.NumericUpDown nud_VR1Upper;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown nud_VwUpper;
        private System.Windows.Forms.NumericUpDown nud_VwLower;
        private System.Windows.Forms.NumericUpDown nud_VrUpper;
        private System.Windows.Forms.NumericUpDown nud_VrLower;
        private System.Windows.Forms.NumericUpDown nud_AngVUpper;
        private System.Windows.Forms.NumericUpDown nud_P1Upper;
        private System.Windows.Forms.NumericUpDown nud_P1Lower;
        private System.Windows.Forms.NumericUpDown nud_P2Upper;
        private System.Windows.Forms.NumericUpDown nud_P2Lower;
        private System.Windows.Forms.NumericUpDown nud_AngVLower;
        private System.Windows.Forms.NumericUpDown nud_VR1Lower;
        private System.Windows.Forms.NumericUpDown nud_VR2Upper;
        private System.Windows.Forms.NumericUpDown nud_VR2Lower;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}

