#import the libraries

import pandas as pd

import numpy as np

import seaborn as sns

import matplotlib.pyplot as plt

# load the files

df_red = pd.read_csv("winequality-red.csv", sep=";")

df_white = pd.read_csv("winequality-white.csv", sep=";")


df = pd.concat([df_red, df_white], axis=0)

print(df.isnull().sum())

# identify the correlation

plt.subplots(figsize=(20,15))

corr = df.corr()

sns.heatmap(corr,square=True, annot=True)



