﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeasureWaferRecipe
{
    public partial class RecipeForm : Form
    {
        HObject ho_Image;
        private HTuple WindowHandle;

        public RecipeForm()
        {
            InitializeComponent();
        }

        private void nud_bu2Ratio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btn_MasureTest_Edge_Click(object sender, EventArgs e)
        {
            String path = "";
            HImage newImage = new HImage();
            newImage.ReadImage(path);
            HObject ho_Image = newImage;

            HTuple hv_PixelSize;
            HTuple hv_rotateAngle;
            HTuple hv_GrayMax;
            HTuple hv_RoiY1;
            HTuple hv_RoiX1;
            HTuple hv_RoiY2;
            HTuple hv_RoiX2;
            HTuple hv_A1Ang;
            HTuple hv_A2Ang;
            HTuple hv_C1Ang;
            HTuple hv_C2Ang;
            HTuple hv_bu11;
            HTuple hv_bv11;
            HTuple hv_bu22;
            HTuple hv_bv22;
            HTuple hv_A1;
            HTuple hv_A2;
            HTuple hv_B1;
            HTuple hv_B2;
            HTuple hv_BC;
            HTuple hv_C1;
            HTuple hv_C2;
            HTuple hv_R1;
            HTuple hv_R2;
            HTuple hv_t;
            HTuple hv_Ang1;
            HTuple hv_Ang2;
            HTuple hv_ErrorMsg;
            HTuple hv_Phi_OrgX_OrgY;
            HTuple hv_Cir_c1;
            HTuple hv_Cir_c2;
            HTuple hv_LinesX1;
            HTuple hv_LinesY1;
            HTuple hv_LinesX2;
            HTuple hv_LinesY2;
            HTuple hv_TextsText;
            HTuple hv_TextsX;
            HTuple hv_TextsY;


        }

        private void btn_LoadImage_Edge_Click(object sender, EventArgs e)
        {
            //try
            //{
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    HOperatorSet.ReadImage(out ho_Image, openFileDialog.FileName);
                    HOperatorSet.GetImageSize(ho_Image, out HTuple hv_Width, out HTuple hv_Height);
                    HOperatorSet.OpenWindow(0, 0, ptb_View.Width, ptb_View.Height, ptb_View.Handle, "visible", "", out WindowHandle);
                    HOperatorSet.DispObj(ho_Image, WindowHandle);
                }

            //}
            //catch (Exception)
            //{

            //    MessageBox.Show("图片文件错误！");
            //}
        }
    }
}
