﻿using HalconDotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MeasureWaferRecipe
{
    public static class   AlogrithmFunction
    {//2023/02/15 更新  MeasureWaferEdgeB v1.1    MeasurePos v1.1
        // Chapter: XLD / Creation
        // Short Description: Creates an arrow shaped XLD contour. 
        public static void gen_arrow_contour_xld(out HObject ho_Arrow, HTuple hv_Row1, HTuple hv_Column1,
            HTuple hv_Row2, HTuple hv_Column2, HTuple hv_HeadLength, HTuple hv_HeadWidth)
        {



            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_TempArrow = null;

            // Local control variables 

            HTuple hv_Length = new HTuple(), hv_ZeroLengthIndices = new HTuple();
            HTuple hv_DR = new HTuple(), hv_DC = new HTuple(), hv_HalfHeadWidth = new HTuple();
            HTuple hv_RowP1 = new HTuple(), hv_ColP1 = new HTuple();
            HTuple hv_RowP2 = new HTuple(), hv_ColP2 = new HTuple();
            HTuple hv_Index = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Arrow);
            HOperatorSet.GenEmptyObj(out ho_TempArrow);
            try
            {
                //This procedure generates arrow shaped XLD contours,
                //pointing from (Row1, Column1) to (Row2, Column2).
                //If starting and end point are identical, a contour consisting
                //of a single point is returned.
                //
                //input parameteres:
                //Row1, Column1: Coordinates of the arrows' starting points
                //Row2, Column2: Coordinates of the arrows' end points
                //HeadLength, HeadWidth: Size of the arrow heads in pixels
                //
                //output parameter:
                //Arrow: The resulting XLD contour
                //
                //The input tuples Row1, Column1, Row2, and Column2 have to be of
                //the same length.
                //HeadLength and HeadWidth either have to be of the same length as
                //Row1, Column1, Row2, and Column2 or have to be a single element.
                //If one of the above restrictions is violated, an error will occur.
                //
                //
                //Init
                ho_Arrow.Dispose();
                HOperatorSet.GenEmptyObj(out ho_Arrow);
                //
                //Calculate the arrow length
                hv_Length.Dispose();
                HOperatorSet.DistancePp(hv_Row1, hv_Column1, hv_Row2, hv_Column2, out hv_Length);
                //
                //Mark arrows with identical start and end point
                //(set Length to -1 to avoid division-by-zero exception)
                hv_ZeroLengthIndices.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ZeroLengthIndices = hv_Length.TupleFind(
                        0);
                }
                if ((int)(new HTuple(hv_ZeroLengthIndices.TupleNotEqual(-1))) != 0)
                {
                    if (hv_Length == null)
                        hv_Length = new HTuple();
                    hv_Length[hv_ZeroLengthIndices] = -1;
                }
                //
                //Calculate auxiliary variables.
                hv_DR.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_DR = (1.0 * (hv_Row2 - hv_Row1)) / hv_Length;
                }
                hv_DC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_DC = (1.0 * (hv_Column2 - hv_Column1)) / hv_Length;
                }
                hv_HalfHeadWidth.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_HalfHeadWidth = hv_HeadWidth / 2.0;
                }
                //
                //Calculate end points of the arrow head.
                hv_RowP1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RowP1 = (hv_Row1 + ((hv_Length - hv_HeadLength) * hv_DR)) + (hv_HalfHeadWidth * hv_DC);
                }
                hv_ColP1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ColP1 = (hv_Column1 + ((hv_Length - hv_HeadLength) * hv_DC)) - (hv_HalfHeadWidth * hv_DR);
                }
                hv_RowP2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RowP2 = (hv_Row1 + ((hv_Length - hv_HeadLength) * hv_DR)) - (hv_HalfHeadWidth * hv_DC);
                }
                hv_ColP2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_ColP2 = (hv_Column1 + ((hv_Length - hv_HeadLength) * hv_DC)) + (hv_HalfHeadWidth * hv_DR);
                }
                //
                //Finally create output XLD contour for each input point pair
                for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_Length.TupleLength())) - 1); hv_Index = (int)hv_Index + 1)
                {
                    if ((int)(new HTuple(((hv_Length.TupleSelect(hv_Index))).TupleEqual(-1))) != 0)
                    {
                        //Create_ single points for arrows with identical start and end point
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_TempArrow.Dispose();
                            HOperatorSet.GenContourPolygonXld(out ho_TempArrow, hv_Row1.TupleSelect(
                                hv_Index), hv_Column1.TupleSelect(hv_Index));
                        }
                    }
                    else
                    {
                        //Create arrow contour
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_TempArrow.Dispose();
                            HOperatorSet.GenContourPolygonXld(out ho_TempArrow, ((((((((((hv_Row1.TupleSelect(
                                hv_Index))).TupleConcat(hv_Row2.TupleSelect(hv_Index)))).TupleConcat(
                                hv_RowP1.TupleSelect(hv_Index)))).TupleConcat(hv_Row2.TupleSelect(hv_Index)))).TupleConcat(
                                hv_RowP2.TupleSelect(hv_Index)))).TupleConcat(hv_Row2.TupleSelect(hv_Index)),
                                ((((((((((hv_Column1.TupleSelect(hv_Index))).TupleConcat(hv_Column2.TupleSelect(
                                hv_Index)))).TupleConcat(hv_ColP1.TupleSelect(hv_Index)))).TupleConcat(
                                hv_Column2.TupleSelect(hv_Index)))).TupleConcat(hv_ColP2.TupleSelect(
                                hv_Index)))).TupleConcat(hv_Column2.TupleSelect(hv_Index)));
                        }
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.ConcatObj(ho_Arrow, ho_TempArrow, out ExpTmpOutVar_0);
                        ho_Arrow.Dispose();
                        ho_Arrow = ExpTmpOutVar_0;
                    }
                }
                ho_TempArrow.Dispose();

                hv_Length.Dispose();
                hv_ZeroLengthIndices.Dispose();
                hv_DR.Dispose();
                hv_DC.Dispose();
                hv_HalfHeadWidth.Dispose();
                hv_RowP1.Dispose();
                hv_ColP1.Dispose();
                hv_RowP2.Dispose();
                hv_ColP2.Dispose();
                hv_Index.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_TempArrow.Dispose();

                hv_Length.Dispose();
                hv_ZeroLengthIndices.Dispose();
                hv_DR.Dispose();
                hv_DC.Dispose();
                hv_HalfHeadWidth.Dispose();
                hv_RowP1.Dispose();
                hv_ColP1.Dispose();
                hv_RowP2.Dispose();
                hv_ColP2.Dispose();
                hv_Index.Dispose();

                throw HDevExpDefaultException;
            }
        }

        // Chapter: File / Misc
        // Short Description: Get all image files under the given path 
        public static void list_image_files(HTuple hv_ImageDirectory, HTuple hv_Extensions, HTuple hv_Options,
            out HTuple hv_ImageFiles)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_ImageDirectoryIndex = new HTuple();
            HTuple hv_ImageFilesTmp = new HTuple(), hv_CurrentImageDirectory = new HTuple();
            HTuple hv_HalconImages = new HTuple(), hv_OS = new HTuple();
            HTuple hv_Directories = new HTuple(), hv_Index = new HTuple();
            HTuple hv_Length = new HTuple(), hv_NetworkDrive = new HTuple();
            HTuple hv_Substring = new HTuple(), hv_FileExists = new HTuple();
            HTuple hv_AllFiles = new HTuple(), hv_i = new HTuple();
            HTuple hv_Selection = new HTuple();
            HTuple hv_Extensions_COPY_INP_TMP = new HTuple(hv_Extensions);

            // Initialize local and output iconic variables 
            hv_ImageFiles = new HTuple();
            try
            {
                //This procedure returns all files in a given directory
                //with one of the suffixes specified in Extensions.
                //
                //Input parameters:
                //ImageDirectory: Directory or a tuple of directories with images.
                //   If a directory is not found locally, the respective directory
                //   is searched under %HALCONIMAGES%/ImageDirectory.
                //   See the Installation Guide for further information
                //   in case %HALCONIMAGES% is not set.
                //Extensions: A string tuple containing the extensions to be found
                //   e.g. ['png','tif',jpg'] or others
                //If Extensions is set to 'default' or the empty string '',
                //   all image suffixes supported by HALCON are used.
                //Options: as in the operator list_files, except that the 'files'
                //   option is always used. Note that the 'directories' option
                //   has no effect but increases runtime, because only files are
                //   returned.
                //
                //Output parameter:
                //ImageFiles: A tuple of all found image file names
                //
                if ((int)((new HTuple((new HTuple(hv_Extensions_COPY_INP_TMP.TupleEqual(new HTuple()))).TupleOr(
                    new HTuple(hv_Extensions_COPY_INP_TMP.TupleEqual(""))))).TupleOr(new HTuple(hv_Extensions_COPY_INP_TMP.TupleEqual(
                    "default")))) != 0)
                {
                    hv_Extensions_COPY_INP_TMP.Dispose();
                    hv_Extensions_COPY_INP_TMP = new HTuple();
                    hv_Extensions_COPY_INP_TMP[0] = "ima";
                    hv_Extensions_COPY_INP_TMP[1] = "tif";
                    hv_Extensions_COPY_INP_TMP[2] = "tiff";
                    hv_Extensions_COPY_INP_TMP[3] = "gif";
                    hv_Extensions_COPY_INP_TMP[4] = "bmp";
                    hv_Extensions_COPY_INP_TMP[5] = "jpg";
                    hv_Extensions_COPY_INP_TMP[6] = "jpeg";
                    hv_Extensions_COPY_INP_TMP[7] = "jp2";
                    hv_Extensions_COPY_INP_TMP[8] = "jxr";
                    hv_Extensions_COPY_INP_TMP[9] = "png";
                    hv_Extensions_COPY_INP_TMP[10] = "pcx";
                    hv_Extensions_COPY_INP_TMP[11] = "ras";
                    hv_Extensions_COPY_INP_TMP[12] = "xwd";
                    hv_Extensions_COPY_INP_TMP[13] = "pbm";
                    hv_Extensions_COPY_INP_TMP[14] = "pnm";
                    hv_Extensions_COPY_INP_TMP[15] = "pgm";
                    hv_Extensions_COPY_INP_TMP[16] = "ppm";
                    //
                }
                hv_ImageFiles.Dispose();
                hv_ImageFiles = new HTuple();
                //Loop through all given image directories.
                for (hv_ImageDirectoryIndex = 0; (int)hv_ImageDirectoryIndex <= (int)((new HTuple(hv_ImageDirectory.TupleLength()
                    )) - 1); hv_ImageDirectoryIndex = (int)hv_ImageDirectoryIndex + 1)
                {
                    hv_ImageFilesTmp.Dispose();
                    hv_ImageFilesTmp = new HTuple();
                    hv_CurrentImageDirectory.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_CurrentImageDirectory = hv_ImageDirectory.TupleSelect(
                            hv_ImageDirectoryIndex);
                    }
                    if ((int)(new HTuple(hv_CurrentImageDirectory.TupleEqual(""))) != 0)
                    {
                        hv_CurrentImageDirectory.Dispose();
                        hv_CurrentImageDirectory = ".";
                    }
                    hv_HalconImages.Dispose();
                    HOperatorSet.GetSystem("image_dir", out hv_HalconImages);
                    hv_OS.Dispose();
                    HOperatorSet.GetSystem("operating_system", out hv_OS);
                    if ((int)(new HTuple(((hv_OS.TupleSubstr(0, 2))).TupleEqual("Win"))) != 0)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_HalconImages = hv_HalconImages.TupleSplit(
                                    ";");
                                hv_HalconImages.Dispose();
                                hv_HalconImages = ExpTmpLocalVar_HalconImages;
                            }
                        }
                    }
                    else
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_HalconImages = hv_HalconImages.TupleSplit(
                                    ":");
                                hv_HalconImages.Dispose();
                                hv_HalconImages = ExpTmpLocalVar_HalconImages;
                            }
                        }
                    }
                    hv_Directories.Dispose();
                    hv_Directories = new HTuple(hv_CurrentImageDirectory);
                    for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_HalconImages.TupleLength()
                        )) - 1); hv_Index = (int)hv_Index + 1)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            {
                                HTuple
                                  ExpTmpLocalVar_Directories = hv_Directories.TupleConcat(
                                    ((hv_HalconImages.TupleSelect(hv_Index)) + "/") + hv_CurrentImageDirectory);
                                hv_Directories.Dispose();
                                hv_Directories = ExpTmpLocalVar_Directories;
                            }
                        }
                    }
                    hv_Length.Dispose();
                    HOperatorSet.TupleStrlen(hv_Directories, out hv_Length);
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_NetworkDrive.Dispose();
                        HOperatorSet.TupleGenConst(new HTuple(hv_Length.TupleLength()), 0, out hv_NetworkDrive);
                    }
                    if ((int)(new HTuple(((hv_OS.TupleSubstr(0, 2))).TupleEqual("Win"))) != 0)
                    {
                        for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_Length.TupleLength()
                            )) - 1); hv_Index = (int)hv_Index + 1)
                        {
                            if ((int)(new HTuple(((((hv_Directories.TupleSelect(hv_Index))).TupleStrlen()
                                )).TupleGreater(1))) != 0)
                            {
                                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                                {
                                    hv_Substring.Dispose();
                                    HOperatorSet.TupleStrFirstN(hv_Directories.TupleSelect(hv_Index), 1,
                                        out hv_Substring);
                                }
                                if ((int)((new HTuple(hv_Substring.TupleEqual("//"))).TupleOr(new HTuple(hv_Substring.TupleEqual(
                                    "\\\\")))) != 0)
                                {
                                    if (hv_NetworkDrive == null)
                                        hv_NetworkDrive = new HTuple();
                                    hv_NetworkDrive[hv_Index] = 1;
                                }
                            }
                        }
                    }
                    hv_ImageFilesTmp.Dispose();
                    hv_ImageFilesTmp = new HTuple();
                    for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_Directories.TupleLength()
                        )) - 1); hv_Index = (int)hv_Index + 1)
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_FileExists.Dispose();
                            HOperatorSet.FileExists(hv_Directories.TupleSelect(hv_Index), out hv_FileExists);
                        }
                        if ((int)(hv_FileExists) != 0)
                        {
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                hv_AllFiles.Dispose();
                                HOperatorSet.ListFiles(hv_Directories.TupleSelect(hv_Index), (new HTuple("files")).TupleConcat(
                                    hv_Options), out hv_AllFiles);
                            }
                            hv_ImageFilesTmp.Dispose();
                            hv_ImageFilesTmp = new HTuple();
                            for (hv_i = 0; (int)hv_i <= (int)((new HTuple(hv_Extensions_COPY_INP_TMP.TupleLength()
                                )) - 1); hv_i = (int)hv_i + 1)
                            {
                                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                                {
                                    hv_Selection.Dispose();
                                    HOperatorSet.TupleRegexpSelect(hv_AllFiles, (((".*" + (hv_Extensions_COPY_INP_TMP.TupleSelect(
                                        hv_i))) + "$")).TupleConcat("ignore_case"), out hv_Selection);
                                }
                                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                                {
                                    {
                                        HTuple
                                          ExpTmpLocalVar_ImageFilesTmp = hv_ImageFilesTmp.TupleConcat(
                                            hv_Selection);
                                        hv_ImageFilesTmp.Dispose();
                                        hv_ImageFilesTmp = ExpTmpLocalVar_ImageFilesTmp;
                                    }
                                }
                            }
                            {
                                HTuple ExpTmpOutVar_0;
                                HOperatorSet.TupleRegexpReplace(hv_ImageFilesTmp, (new HTuple("\\\\")).TupleConcat(
                                    "replace_all"), "/", out ExpTmpOutVar_0);
                                hv_ImageFilesTmp.Dispose();
                                hv_ImageFilesTmp = ExpTmpOutVar_0;
                            }
                            if ((int)(hv_NetworkDrive.TupleSelect(hv_Index)) != 0)
                            {
                                {
                                    HTuple ExpTmpOutVar_0;
                                    HOperatorSet.TupleRegexpReplace(hv_ImageFilesTmp, (new HTuple("//")).TupleConcat(
                                        "replace_all"), "/", out ExpTmpOutVar_0);
                                    hv_ImageFilesTmp.Dispose();
                                    hv_ImageFilesTmp = ExpTmpOutVar_0;
                                }
                                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                                {
                                    {
                                        HTuple
                                          ExpTmpLocalVar_ImageFilesTmp = "/" + hv_ImageFilesTmp;
                                        hv_ImageFilesTmp.Dispose();
                                        hv_ImageFilesTmp = ExpTmpLocalVar_ImageFilesTmp;
                                    }
                                }
                            }
                            else
                            {
                                {
                                    HTuple ExpTmpOutVar_0;
                                    HOperatorSet.TupleRegexpReplace(hv_ImageFilesTmp, (new HTuple("//")).TupleConcat(
                                        "replace_all"), "/", out ExpTmpOutVar_0);
                                    hv_ImageFilesTmp.Dispose();
                                    hv_ImageFilesTmp = ExpTmpOutVar_0;
                                }
                            }
                            break;
                        }
                    }
                    //Concatenate the output image paths.
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ImageFiles = hv_ImageFiles.TupleConcat(
                                hv_ImageFilesTmp);
                            hv_ImageFiles.Dispose();
                            hv_ImageFiles = ExpTmpLocalVar_ImageFiles;
                        }
                    }
                }

                hv_Extensions_COPY_INP_TMP.Dispose();
                hv_ImageDirectoryIndex.Dispose();
                hv_ImageFilesTmp.Dispose();
                hv_CurrentImageDirectory.Dispose();
                hv_HalconImages.Dispose();
                hv_OS.Dispose();
                hv_Directories.Dispose();
                hv_Index.Dispose();
                hv_Length.Dispose();
                hv_NetworkDrive.Dispose();
                hv_Substring.Dispose();
                hv_FileExists.Dispose();
                hv_AllFiles.Dispose();
                hv_i.Dispose();
                hv_Selection.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Extensions_COPY_INP_TMP.Dispose();
                hv_ImageDirectoryIndex.Dispose();
                hv_ImageFilesTmp.Dispose();
                hv_CurrentImageDirectory.Dispose();
                hv_HalconImages.Dispose();
                hv_OS.Dispose();
                hv_Directories.Dispose();
                hv_Index.Dispose();
                hv_Length.Dispose();
                hv_NetworkDrive.Dispose();
                hv_Substring.Dispose();
                hv_FileExists.Dispose();
                hv_AllFiles.Dispose();
                hv_i.Dispose();
                hv_Selection.Dispose();

                throw HDevExpDefaultException;
            }
        }

        // Chapter: Graphics / Text
        // Short Description: Set font independent of OS 
        public static void set_display_font(HTuple hv_WindowHandle, HTuple hv_Size, HTuple hv_Font,
            HTuple hv_Bold, HTuple hv_Slant)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_OS = new HTuple(), hv_Fonts = new HTuple();
            HTuple hv_Style = new HTuple(), hv_Exception = new HTuple();
            HTuple hv_AvailableFonts = new HTuple(), hv_Fdx = new HTuple();
            HTuple hv_Indices = new HTuple();
            HTuple hv_Font_COPY_INP_TMP = new HTuple(hv_Font);
            HTuple hv_Size_COPY_INP_TMP = new HTuple(hv_Size);

            // Initialize local and output iconic variables 
            try
            {
                //This procedure sets the text font of the current window with
                //the specified attributes.
                //
                //Input parameters:
                //WindowHandle: The graphics window for which the font will be set
                //Size: The font size. If Size=-1, the default of 16 is used.
                //Bold: If set to 'true', a bold font is used
                //Slant: If set to 'true', a slanted font is used
                //
                hv_OS.Dispose();
                HOperatorSet.GetSystem("operating_system", out hv_OS);
                if ((int)((new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(new HTuple()))).TupleOr(
                    new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(-1)))) != 0)
                {
                    hv_Size_COPY_INP_TMP.Dispose();
                    hv_Size_COPY_INP_TMP = 16;
                }
                if ((int)(new HTuple(((hv_OS.TupleSubstr(0, 2))).TupleEqual("Win"))) != 0)
                {
                    //Restore previous behaviour
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = ((1.13677 * hv_Size_COPY_INP_TMP)).TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                else
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = hv_Size_COPY_INP_TMP.TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("Courier"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Courier";
                    hv_Fonts[1] = "Courier 10 Pitch";
                    hv_Fonts[2] = "Courier New";
                    hv_Fonts[3] = "CourierNew";
                    hv_Fonts[4] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("mono"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Consolas";
                    hv_Fonts[1] = "Menlo";
                    hv_Fonts[2] = "Courier";
                    hv_Fonts[3] = "Courier 10 Pitch";
                    hv_Fonts[4] = "FreeMono";
                    hv_Fonts[5] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("sans"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Luxi Sans";
                    hv_Fonts[1] = "DejaVu Sans";
                    hv_Fonts[2] = "FreeSans";
                    hv_Fonts[3] = "Arial";
                    hv_Fonts[4] = "Liberation Sans";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("serif"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Times New Roman";
                    hv_Fonts[1] = "Luxi Serif";
                    hv_Fonts[2] = "DejaVu Serif";
                    hv_Fonts[3] = "FreeSerif";
                    hv_Fonts[4] = "Utopia";
                    hv_Fonts[5] = "Liberation Serif";
                }
                else
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple(hv_Font_COPY_INP_TMP);
                }
                hv_Style.Dispose();
                hv_Style = "";
                if ((int)(new HTuple(hv_Bold.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Bold";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Bold.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Bold";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Slant.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Italic";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Slant.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Slant";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Style.TupleEqual(""))) != 0)
                {
                    hv_Style.Dispose();
                    hv_Style = "Normal";
                }
                hv_AvailableFonts.Dispose();
                HOperatorSet.QueryFont(hv_WindowHandle, out hv_AvailableFonts);
                hv_Font_COPY_INP_TMP.Dispose();
                hv_Font_COPY_INP_TMP = "";
                for (hv_Fdx = 0; (int)hv_Fdx <= (int)((new HTuple(hv_Fonts.TupleLength())) - 1); hv_Fdx = (int)hv_Fdx + 1)
                {
                    hv_Indices.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Indices = hv_AvailableFonts.TupleFind(
                            hv_Fonts.TupleSelect(hv_Fdx));
                    }
                    if ((int)(new HTuple((new HTuple(hv_Indices.TupleLength())).TupleGreater(
                        0))) != 0)
                    {
                        if ((int)(new HTuple(((hv_Indices.TupleSelect(0))).TupleGreaterEqual(0))) != 0)
                        {
                            hv_Font_COPY_INP_TMP.Dispose();
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                hv_Font_COPY_INP_TMP = hv_Fonts.TupleSelect(
                                    hv_Fdx);
                            }
                            break;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual(""))) != 0)
                {
                    throw new HalconException("Wrong value of control parameter Font");
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Font = (((hv_Font_COPY_INP_TMP + "-") + hv_Style) + "-") + hv_Size_COPY_INP_TMP;
                        hv_Font_COPY_INP_TMP.Dispose();
                        hv_Font_COPY_INP_TMP = ExpTmpLocalVar_Font;
                    }
                }
                HOperatorSet.SetFont(hv_WindowHandle, hv_Font_COPY_INP_TMP);

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                throw HDevExpDefaultException;
            }
        }

        // Local procedures 
        // Short Description: 將輸入參數角度 轉換為實際內部演算角度 
        /// <summary>
        /// 
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)
        /// ------------------------
        /// 輸入參數座標
        /// 
        ///     ▼轉換如下▼
        /// 
        /// 內部實際演算角度
        /// ------------------------
        /// ↗+
        /// →  0度   
        /// ↘-
        /// range(-90~90)
        /// </summary>
        /// <param name = "hv_Angle">
        /// <para>輸入座標
        /// 向上為零度
        /// 
        /// 順時針為正
        /// 逆時針為負
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_AngleOut">
        /// <para>輸出座標,
        /// 向右為零度
        /// 
        /// 逆時針 為正
        /// 順時針 為負
        /// ↗+
        /// →  0度   
        /// ↘-
        /// range(-90~90)</para>
        /// <para>型態: </para>
        /// <para>語義: angle.deg</para>
        /// </param>
        public static void AngleTrans(HTuple hv_Angle, out HTuple hv_AngleOut)
        {



            // Local iconic variables 
            // Initialize local and output iconic variables 
            hv_AngleOut = new HTuple();
            //20230213 v1.0 將座標轉換將輸入參數角度 轉換為實際內部演算角度
            hv_AngleOut.Dispose();
            hv_AngleOut = new HTuple();
            if ((int)((new HTuple(hv_Angle.TupleGreater(90))).TupleOr(new HTuple(hv_Angle.TupleLess(
                -90)))) != 0)
            {
                throw new HalconException("輸入角度範圍只能為-90~90度");


                return;
            }
            if ((int)(new HTuple(hv_Angle.TupleGreaterEqual(0))) != 0)
            {
                hv_AngleOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_AngleOut = -(hv_Angle - 90);
                }
            }
            else
            {
                hv_AngleOut.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_AngleOut = -(hv_Angle + 90);
                }
            }


            return;
        }

        /// <summary>
        /// 量測1D邊緣
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ResultCross">
        /// <para>輸出座標點</para>
        /// <para>型態: HObject</para>
        /// </param>
        /// <param name = "hv_Y1">
        /// <para>輸入量測線起始點Y1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X1">
        /// <para>輸入量測線起始點X1</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Y2">
        /// <para>輸入量測線起始點Y2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_X2">
        /// <para>輸入量測線起始點X2</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Width">
        /// <para>輸入量測寬度</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Amp">
        /// <para>黑白震幅</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_Sigma">
        /// <para>高斯平滑參數</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// <para>範圍: 1.000000 ＜= hv_Sigma ＜= 11.000000</para>
        /// </param>
        /// <param name = "hv_ResultY">
        /// <para>結果輸出座標Y</para>
        /// <para>型態: </para>
        /// </param>
        /// <param name = "hv_ResultX">
        /// <para>結果輸出座標X</para>
        /// <para>型態: </para>
        /// </param>
        public static void MeasurePos(HObject ho_Image, out HObject ho_ResultCross, HTuple hv_Y1,
            HTuple hv_X1, HTuple hv_Y2, HTuple hv_X2, HTuple hv_Width, HTuple hv_Amp, HTuple hv_Sigma,
            out HTuple hv_ResultY, out HTuple hv_ResultX)
        {




            // Local iconic variables 

            HObject ho_Rectangle;

            // Local control variables 

            HTuple hv_TmpCtrl_Row = new HTuple(), hv_TmpCtrl_Column = new HTuple();
            HTuple hv_TmpCtrl_Dr = new HTuple(), hv_TmpCtrl_Dc = new HTuple();
            HTuple hv_TmpCtrl_Phi = new HTuple(), hv_TmpCtrl_Len1 = new HTuple();
            HTuple hv_TmpCtrl_Len2 = new HTuple(), hv_Height = new HTuple();
            HTuple hv_MsrHandle_Measure_02_0 = new HTuple(), hv_Amplitude_Measure_02_0 = new HTuple();
            HTuple hv_Distance_Measure_02_0 = new HTuple();
            HTuple hv_Width_COPY_INP_TMP = new HTuple(hv_Width);

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ResultCross);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            hv_ResultY = new HTuple();
            hv_ResultX = new HTuple();
            try
            {
                //20230213 v1.0 量測1D邊緣
                //20230214 v1.1 新增參數:量測角度
                hv_TmpCtrl_Row.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Row = 0.5 * (hv_Y1 + hv_Y2);
                }
                hv_TmpCtrl_Column.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Column = 0.5 * (hv_X1 + hv_X2);
                }
                hv_TmpCtrl_Dr.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dr = hv_Y1 - hv_Y2;
                }
                hv_TmpCtrl_Dc.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Dc = hv_X2 - hv_X1;
                }
                hv_TmpCtrl_Phi.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Phi = hv_TmpCtrl_Dr.TupleAtan2(
                        hv_TmpCtrl_Dc);
                }
                hv_TmpCtrl_Len1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TmpCtrl_Len1 = 0.5 * ((((hv_TmpCtrl_Dr * hv_TmpCtrl_Dr) + (hv_TmpCtrl_Dc * hv_TmpCtrl_Dc))).TupleSqrt()
                        );
                }
                hv_TmpCtrl_Len2.Dispose();
                hv_TmpCtrl_Len2 = new HTuple(hv_Width_COPY_INP_TMP);
                ho_ResultCross.Dispose();
                HOperatorSet.GenEmptyObj(out ho_ResultCross);
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle2(out ho_Rectangle, hv_TmpCtrl_Row, hv_TmpCtrl_Column,
                    hv_TmpCtrl_Phi, hv_TmpCtrl_Len1, hv_TmpCtrl_Len2);
                hv_Width_COPY_INP_TMP.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_Image, out hv_Width_COPY_INP_TMP, out hv_Height);
                hv_MsrHandle_Measure_02_0.Dispose();
                HOperatorSet.GenMeasureRectangle2(hv_TmpCtrl_Row, hv_TmpCtrl_Column, hv_TmpCtrl_Phi,
                    hv_TmpCtrl_Len1, hv_TmpCtrl_Len2, hv_Width_COPY_INP_TMP, hv_Height, "nearest_neighbor",
                    out hv_MsrHandle_Measure_02_0);
                hv_ResultY.Dispose(); hv_ResultX.Dispose(); hv_Amplitude_Measure_02_0.Dispose(); hv_Distance_Measure_02_0.Dispose();
                HOperatorSet.MeasurePos(ho_Image, hv_MsrHandle_Measure_02_0, hv_Sigma, hv_Amp,
                    "positive", "first", out hv_ResultY, out hv_ResultX, out hv_Amplitude_Measure_02_0,
                    out hv_Distance_Measure_02_0);
                ho_ResultCross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_ResultCross, hv_ResultY, hv_ResultX,
                    6, 0.785398);
                HOperatorSet.CloseMeasure(hv_MsrHandle_Measure_02_0);
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Rectangle.Dispose();

                hv_Width_COPY_INP_TMP.Dispose();
                hv_TmpCtrl_Row.Dispose();
                hv_TmpCtrl_Column.Dispose();
                hv_TmpCtrl_Dr.Dispose();
                hv_TmpCtrl_Dc.Dispose();
                hv_TmpCtrl_Phi.Dispose();
                hv_TmpCtrl_Len1.Dispose();
                hv_TmpCtrl_Len2.Dispose();
                hv_Height.Dispose();
                hv_MsrHandle_Measure_02_0.Dispose();
                hv_Amplitude_Measure_02_0.Dispose();
                hv_Distance_Measure_02_0.Dispose();

                throw HDevExpDefaultException;
            }
        }

        /// <summary>
        /// 量測面幅 TypeB
        /// </summary>
        /// <param name = "ho_Image">
        /// <para>輸入圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "ho_ImageOut">
        /// <para>輸出圖片</para>
        /// <para>型態: HObject</para>
        /// <para>語義: image</para>
        /// </param>
        /// <param name = "hv_PixelSize">
        /// <para>Pixel Size(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_rotateAngle">
        /// <para>初步轉正(統一轉成 wafer在左側之影像)
        /// 
        /// </para>
        /// <para>型態: int</para>
        /// <para>語義: integer</para>
        /// </param>
        /// <param name = "hv_GrayMax">
        /// <para>wafer區域最大灰階罰直</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiY1">
        /// <para>ROI座標(左上Y</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiX1">
        /// <para>ROI座標(左上X</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiY2">
        /// <para>ROI座標(右下Y</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_RoiX2">
        /// <para>ROI座標(右下X</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A1Ang">
        /// <para>輸入 A1點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_A2Ang">
        /// <para>輸入 A2點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_C1Ang">
        /// <para>輸入 C1點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_C2Ang">
        /// <para>輸入 C2點量測用 切線角度
        ///          0度   
        /// - ↖   ↑   ↗+
        /// range(-90~90)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_bu11">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bv11">
        /// <para>量測斜角的結束值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bu22">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99
        /// 
        /// </para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_bv22">
        /// <para>量測斜角的起始值(比例)
        /// range 0.01~0.99</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A1">
        /// <para>輸出量測結果 A1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_A2">
        /// <para>輸出量測結果 A2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_B1">
        /// <para>輸出量測結果B1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_B2">
        /// <para>輸出量測結果B2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_BC">
        /// <para>輸出量測結果 BC尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_C1">
        /// <para>輸出量測結果C1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_C2">
        /// <para>輸出量測結果 C1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_R1">
        /// <para>輸出量測結果 R1尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_R2">
        /// <para>輸出量測結果R2尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_t">
        /// <para>輸出量測結果 t 尺寸(um)</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_Ang1">
        /// <para>輸出量測結果 Ang1  (0~90度)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_Ang2">
        /// <para>輸出量測結果 Ang2 (0~90度)</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_ErrorMsg">
        /// <para>錯誤訊息</para>
        /// <para>型態: string[]</para>
        /// <para>語義: string</para>
        /// </param>
        /// <param name = "hv_Phi_OrgX_OrgY">
        /// <para>wafer偏轉角度(影像上水平),原點座標X，原點座標Y</para>
        /// <para>型態: double</para>
        /// <para>語義: angle.deg</para>
        /// </param>
        /// <param name = "hv_Cir_c1">
        /// <para>輸出可視化參數 C1:=[CenterX,CenterY,R]</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_Cir_c2">
        /// <para>輸出可視化參數 C1:=[CenterX,CenterY,R]</para>
        /// <para>型態: double</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesX1">
        /// <para>輸出可視化參數:直線起點X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesY1">
        /// <para>輸出可視化參數:直線起點Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesX2">
        /// <para>輸出可視化參數:直線終點X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_LinesY2">
        /// <para>輸出可視化參數:直線終點Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_TextsText">
        /// <para>輸出可視化參數:文字輸出</para>
        /// <para>型態: []</para>
        /// <para>語義: string</para>
        /// </param>
        /// <param name = "hv_TextsX">
        /// <para>輸出可視化參數:文字輸出座標X</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        /// <param name = "hv_TextsY">
        /// <para>輸出可視化參數:文字輸出座標Y</para>
        /// <para>型態: double[]</para>
        /// <para>語義: real</para>
        /// </param>
        public static void MeasureWaferEdgeB(HObject ho_Image, out HObject ho_ImageOut, HTuple hv_PixelSize,
            HTuple hv_rotateAngle, HTuple hv_GrayMax, HTuple hv_RoiY1, HTuple hv_RoiX1,
            HTuple hv_RoiY2, HTuple hv_RoiX2, HTuple hv_A1Ang, HTuple hv_A2Ang, HTuple hv_C1Ang,
            HTuple hv_C2Ang, HTuple hv_bu11, HTuple hv_bv11, HTuple hv_bu22, HTuple hv_bv22,
            out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
            out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
            out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
            out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
            out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
            out HTuple hv_TextsY)
        {




            // Stack for temporary objects 
            HObject[] OTemp = new HObject[20];

            // Local iconic variables 

            HObject ho_Regions = null, ho_ConnectedRegions;
            HObject ho_ObjectSelected1, ho_Rectangle1, ho_Rectangle2;
            HObject ho_Position1Region, ho_Position2Region, ho_Rectangle;
            HObject ho_ImageReduced, ho_Region = null, ho_ConnectedRegions1;
            HObject ho_Cross, ho_bu1, ho_RegionLines, ho_a1, ho_c1;
            HObject ho_a2, ho_c2, ho_Arrow2, ho_bv1, ho_Bu2, ho_bu2;
            HObject ho_bv2, ho_b1, ho_b2, ho_RectangleUp, ho_ImageReduced1;
            HObject ho_ContoursSplit, ho_Circle1, ho_ObjectSelected = null;
            HObject ho_ContEllipse = null, ho_RectangleDown, ho_Circle;
            HObject ho_Arrow1 = null, ho_Surface1 = null, ho_Surface2 = null;
            HObject ho_line = null, ho_line1 = null, ho_Orig = null, ho_OrgLine = null;

            // Local control variables 

            HTuple hv_show = new HTuple(), hv_UsedThreshold = new HTuple();
            HTuple hv_Area4 = new HTuple(), hv_Row1 = new HTuple();
            HTuple hv_Column1 = new HTuple(), hv_Indices = new HTuple();
            HTuple hv_RectRow1 = new HTuple(), hv_RectColumn1 = new HTuple();
            HTuple hv_RectRow2 = new HTuple(), hv_RectColumn2 = new HTuple();
            HTuple hv_RectW = new HTuple(), hv_RectH = new HTuple();
            HTuple hv_Phi = new HTuple(), hv_Area1 = new HTuple();
            HTuple hv_CenterLRow = new HTuple(), hv_CenterLCol = new HTuple();
            HTuple hv_Area3 = new HTuple(), hv_CenterRRow = new HTuple();
            HTuple hv_CenterRCol = new HTuple(), hv_HomMat2DIdentity = new HTuple();
            HTuple hv_rotateRow = new HTuple(), hv_rotateCol = new HTuple();
            HTuple hv_HomMat2DRotate = new HTuple(), hv_rotateAng = new HTuple();
            HTuple hv_Area2 = new HTuple(), hv_Row4 = new HTuple();
            HTuple hv_Column4 = new HTuple(), hv_Indices3 = new HTuple();
            HTuple hv_WaferRow1 = new HTuple(), hv_WaferCol1 = new HTuple();
            HTuple hv_WaferRow2 = new HTuple(), hv_WaferRCol2 = new HTuple();
            HTuple hv_Area = new HTuple(), hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_OriginRow = new HTuple(), hv_OriginCol = new HTuple();
            HTuple hv_Amp = new HTuple(), hv_RoiWidthLen2 = new HTuple();
            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_WaferOriginRow = new HTuple(), hv_WaferOriginCol = new HTuple();
            HTuple hv_RU_row = new HTuple(), hv_RU_col = new HTuple();
            HTuple hv_A1AngOut = new HTuple(), hv_MinDistance1 = new HTuple();
            HTuple hv_Row12 = new HTuple(), hv_Column12 = new HTuple();
            HTuple hv_A1Row = new HTuple(), hv_A1Col = new HTuple();
            HTuple hv_C1AngOut = new HTuple(), hv_C1Row = new HTuple();
            HTuple hv_C1Col = new HTuple(), hv_RD_Row = new HTuple();
            HTuple hv_RD_Col = new HTuple(), hv_A2AngOut = new HTuple();
            HTuple hv_A2Row = new HTuple(), hv_A2Col = new HTuple();
            HTuple hv_C2AngOut = new HTuple(), hv_C2Row = new HTuple();
            HTuple hv_C2Col = new HTuple(), hv_L2 = new HTuple(), hv_Sigma = new HTuple();
            HTuple hv_bu1Row2 = new HTuple(), hv_bu1Col2 = new HTuple();
            HTuple hv_bu1Row1 = new HTuple(), hv_bu1Col1 = new HTuple();
            HTuple hv_bu1Row = new HTuple(), hv_bu1Col = new HTuple();
            HTuple hv_bv1Row2 = new HTuple(), hv_bv1Col2 = new HTuple();
            HTuple hv_bv1Row1 = new HTuple(), hv_bv1Col1 = new HTuple();
            HTuple hv_bv1Row = new HTuple(), hv_bv1Col = new HTuple();
            HTuple hv_bu2Row2 = new HTuple(), hv_bu2Col2 = new HTuple();
            HTuple hv_bu2Row1 = new HTuple(), hv_bu2Col1 = new HTuple();
            HTuple hv_bu2Row = new HTuple(), hv_bu2Col = new HTuple();
            HTuple hv_bv2Row1 = new HTuple(), hv_bv2Col1 = new HTuple();
            HTuple hv_bv2Row2 = new HTuple(), hv_bv2Col2 = new HTuple();
            HTuple hv_bv2Row = new HTuple(), hv_bv2Col = new HTuple();
            HTuple hv_B1Row = new HTuple(), hv_B1Col = new HTuple();
            HTuple hv_IsOverlapping = new HTuple(), hv_B2Row = new HTuple();
            HTuple hv_B2Col = new HTuple(), hv_Angle1 = new HTuple();
            HTuple hv_Angle2 = new HTuple(), hv_Number = new HTuple();
            HTuple hv_R_1 = new HTuple(), hv_R_1CenterRow = new HTuple();
            HTuple hv_R_1CenterCol = new HTuple(), hv_i = new HTuple();
            HTuple hv_Attrib = new HTuple(), hv_Radius = new HTuple();
            HTuple hv_StartPhi = new HTuple(), hv_EndPhi = new HTuple();
            HTuple hv_PointOrder = new HTuple(), hv_R_2 = new HTuple();
            HTuple hv_R_2CenterRow = new HTuple(), hv_R_2CenterCol = new HTuple();
            HTuple hv_Length = new HTuple(), hv_Line_Org = new HTuple();
            HTuple hv_Line_Surface1 = new HTuple(), hv_Line_Surface2 = new HTuple();
            HTuple hv_Line_Ang1 = new HTuple(), hv_Line_Ang2 = new HTuple();
            HTuple hv_Line_A1 = new HTuple(), hv_Line_A2 = new HTuple();
            HTuple hv_Line_B1 = new HTuple(), hv_Line_B2 = new HTuple();
            HTuple hv_Line_R1 = new HTuple(), hv_Line_R2 = new HTuple();
            HTuple hv_Line_C1 = new HTuple(), hv_Line_C2 = new HTuple();
            HTuple hv_Lines = new HTuple(), hv_X1_idx = new HTuple();
            HTuple hv_Y1_idx = new HTuple(), hv_X2_idx = new HTuple();
            HTuple hv_Y2_idx = new HTuple(), hv_textA1 = new HTuple();
            HTuple hv_textA2 = new HTuple(), hv_textB1 = new HTuple();
            HTuple hv_textB2 = new HTuple(), hv_textBC = new HTuple();
            HTuple hv_textC1 = new HTuple(), hv_textC2 = new HTuple();
            HTuple hv_textR1 = new HTuple(), hv_textR2 = new HTuple();
            HTuple hv_textt = new HTuple(), hv_textAng1 = new HTuple();
            HTuple hv_textAng2 = new HTuple(), hv_texts = new HTuple();
            HTuple hv_text_idx = new HTuple(), hv_textX_idx = new HTuple();
            HTuple hv_textY_idx = new HTuple(), hv_S4 = new HTuple();
            HTuple hv_WindowHandle = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_ImageOut);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle2);
            HOperatorSet.GenEmptyObj(out ho_Position1Region);
            HOperatorSet.GenEmptyObj(out ho_Position2Region);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced);
            HOperatorSet.GenEmptyObj(out ho_Region);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Cross);
            HOperatorSet.GenEmptyObj(out ho_bu1);
            HOperatorSet.GenEmptyObj(out ho_RegionLines);
            HOperatorSet.GenEmptyObj(out ho_a1);
            HOperatorSet.GenEmptyObj(out ho_c1);
            HOperatorSet.GenEmptyObj(out ho_a2);
            HOperatorSet.GenEmptyObj(out ho_c2);
            HOperatorSet.GenEmptyObj(out ho_Arrow2);
            HOperatorSet.GenEmptyObj(out ho_bv1);
            HOperatorSet.GenEmptyObj(out ho_Bu2);
            HOperatorSet.GenEmptyObj(out ho_bu2);
            HOperatorSet.GenEmptyObj(out ho_bv2);
            HOperatorSet.GenEmptyObj(out ho_b1);
            HOperatorSet.GenEmptyObj(out ho_b2);
            HOperatorSet.GenEmptyObj(out ho_RectangleUp);
            HOperatorSet.GenEmptyObj(out ho_ImageReduced1);
            HOperatorSet.GenEmptyObj(out ho_ContoursSplit);
            HOperatorSet.GenEmptyObj(out ho_Circle1);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected);
            HOperatorSet.GenEmptyObj(out ho_ContEllipse);
            HOperatorSet.GenEmptyObj(out ho_RectangleDown);
            HOperatorSet.GenEmptyObj(out ho_Circle);
            HOperatorSet.GenEmptyObj(out ho_Arrow1);
            HOperatorSet.GenEmptyObj(out ho_Surface1);
            HOperatorSet.GenEmptyObj(out ho_Surface2);
            HOperatorSet.GenEmptyObj(out ho_line);
            HOperatorSet.GenEmptyObj(out ho_line1);
            HOperatorSet.GenEmptyObj(out ho_Orig);
            HOperatorSet.GenEmptyObj(out ho_OrgLine);
            hv_A1 = new HTuple();
            hv_A2 = new HTuple();
            hv_B1 = new HTuple();
            hv_B2 = new HTuple();
            hv_BC = new HTuple();
            hv_C1 = new HTuple();
            hv_C2 = new HTuple();
            hv_R1 = new HTuple();
            hv_R2 = new HTuple();
            hv_t = new HTuple();
            hv_Ang1 = new HTuple();
            hv_Ang2 = new HTuple();
            hv_ErrorMsg = new HTuple();
            hv_Phi_OrgX_OrgY = new HTuple();
            hv_Cir_c1 = new HTuple();
            hv_Cir_c2 = new HTuple();
            hv_LinesX1 = new HTuple();
            hv_LinesY1 = new HTuple();
            hv_LinesX2 = new HTuple();
            hv_LinesY2 = new HTuple();
            hv_TextsText = new HTuple();
            hv_TextsX = new HTuple();
            hv_TextsY = new HTuple();
            try
            {
                //20230213 v1.0
                //20230214 v1.1 修正MeasurePos指令
                ho_ImageOut.Dispose();
                HOperatorSet.CopyImage(ho_Image, out ho_ImageOut);
                hv_show.Dispose();
                hv_show = 0; //0 不顯示 1顯示
                hv_A1.Dispose();
                hv_A1 = new HTuple();
                hv_A2.Dispose();
                hv_A2 = new HTuple();
                hv_B1.Dispose();
                hv_B1 = new HTuple();
                hv_B2.Dispose();
                hv_B2 = new HTuple();
                hv_BC.Dispose();
                hv_BC = new HTuple();
                hv_C1.Dispose();
                hv_C1 = new HTuple();
                hv_C2.Dispose();
                hv_C2 = new HTuple();
                hv_R1.Dispose();
                hv_R1 = new HTuple();
                hv_R2.Dispose();
                hv_R2 = new HTuple();
                hv_t.Dispose();
                hv_t = new HTuple();
                hv_Ang1.Dispose();
                hv_Ang1 = new HTuple();
                hv_Ang2.Dispose();
                hv_Ang2 = new HTuple();
                hv_ErrorMsg.Dispose();
                hv_ErrorMsg = new HTuple();
                //轉正
                if ((int)(new HTuple(hv_rotateAngle.TupleNotEqual(0))) != 0)
                {
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.RotateImage(ho_ImageOut, out ExpTmpOutVar_0, hv_rotateAngle,
                            "constant");
                        ho_ImageOut.Dispose();
                        ho_ImageOut = ExpTmpOutVar_0;
                    }
                }
                if ((int)(new HTuple(hv_GrayMax.TupleLessEqual(0))) != 0)
                {
                    ho_Regions.Dispose(); hv_UsedThreshold.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageOut, out ho_Regions, "max_separability",
                        "dark", out hv_UsedThreshold);
                }
                else
                {
                    ho_Regions.Dispose();
                    HOperatorSet.Threshold(ho_ImageOut, out ho_Regions, 0, hv_GrayMax);
                }
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
                hv_Area4.Dispose(); hv_Row1.Dispose(); hv_Column1.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions, out hv_Area4, out hv_Row1, out hv_Column1);
                hv_Indices.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area4, out hv_Indices);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_ObjectSelected1.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions, out ho_ObjectSelected1, (hv_Indices.TupleSelect(
                        (new HTuple(hv_Indices.TupleLength())) - 1)) + 1);
                }
                //抓左右兩小區的region 的中心 計算傾斜角度
                hv_RectRow1.Dispose(); hv_RectColumn1.Dispose(); hv_RectRow2.Dispose(); hv_RectColumn2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_ObjectSelected1, out hv_RectRow1, out hv_RectColumn1,
                    out hv_RectRow2, out hv_RectColumn2);
                hv_RectW.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RectW = (hv_RectColumn2 - hv_RectColumn1) - 150;
                }
                hv_RectH.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_RectH = hv_RectRow2 - hv_RectRow1;
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangle1.Dispose();
                    HOperatorSet.GenRectangle1(out ho_Rectangle1, hv_RectRow1 - 30, hv_RectColumn1 + (0.1 * hv_RectW),
                        hv_RectRow2 + 30, hv_RectColumn1 + (0.3 * hv_RectW));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Rectangle2.Dispose();
                    HOperatorSet.GenRectangle1(out ho_Rectangle2, hv_RectRow1 - 30, hv_RectColumn1 + (0.7 * hv_RectW),
                        hv_RectRow2 + 30, hv_RectColumn1 + (0.9 * hv_RectW));
                }
                ho_Position1Region.Dispose();
                HOperatorSet.Intersection(ho_Rectangle1, ho_Regions, out ho_Position1Region
                    );
                ho_Position2Region.Dispose();
                HOperatorSet.Intersection(ho_Rectangle2, ho_Regions, out ho_Position2Region
                    );
                //inner_rectangle1 (Position1Region, Row1L, Column1L, Row2L, Column2L)
                //inner_rectangle1 (Position2Region, Row1R, Column1R, Row2R, Column2R)
                //angle_lx ((Row1L+Row2L)*0.5, (Column1L+Column2L)*0.5, (Row1R+Row2R)*0.5, (Column1R+Column2R)*0.5, Phi)
                hv_Area1.Dispose(); hv_CenterLRow.Dispose(); hv_CenterLCol.Dispose();
                HOperatorSet.AreaCenter(ho_Position1Region, out hv_Area1, out hv_CenterLRow,
                    out hv_CenterLCol);
                hv_Area3.Dispose(); hv_CenterRRow.Dispose(); hv_CenterRCol.Dispose();
                HOperatorSet.AreaCenter(ho_Position2Region, out hv_Area3, out hv_CenterRRow,
                    out hv_CenterRCol);
                hv_Phi.Dispose();
                HOperatorSet.AngleLx(hv_CenterLRow, hv_CenterLCol, hv_CenterRRow, hv_CenterRCol,
                    out hv_Phi);
                hv_Phi_OrgX_OrgY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Phi_OrgX_OrgY = hv_Phi.TupleDeg()
                        ;
                }
                hv_HomMat2DIdentity.Dispose();
                HOperatorSet.HomMat2dIdentity(out hv_HomMat2DIdentity);
                //旋轉中心(Wafer的頂點)
                hv_rotateRow.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_rotateRow = (hv_RectRow1 + hv_RectRow2) / 2;
                }
                hv_rotateCol.Dispose();
                hv_rotateCol = new HTuple(hv_RectColumn2);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_HomMat2DRotate.Dispose();
                    HOperatorSet.HomMat2dRotate(hv_HomMat2DIdentity, -hv_Phi, hv_rotateCol, hv_rotateRow,
                        out hv_HomMat2DRotate);
                }
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.AffineTransImage(ho_ImageOut, out ExpTmpOutVar_0, hv_HomMat2DRotate,
                        "constant", "false");
                    ho_ImageOut.Dispose();
                    ho_ImageOut = ExpTmpOutVar_0;
                }
                hv_rotateAng.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_rotateAng = hv_Phi.TupleDeg()
                        ;
                }
                //抓取ROI區域
                ho_Rectangle.Dispose();
                HOperatorSet.GenRectangle1(out ho_Rectangle, hv_RoiY1, hv_RoiX1, hv_RoiY2,
                    hv_RoiX2);
                ho_ImageReduced.Dispose();
                HOperatorSet.ReduceDomain(ho_ImageOut, ho_Rectangle, out ho_ImageReduced);
                if ((int)(new HTuple(hv_GrayMax.TupleLessEqual(0))) != 0)
                {
                    ho_Region.Dispose(); hv_UsedThreshold.Dispose();
                    HOperatorSet.BinaryThreshold(ho_ImageReduced, out ho_Region, "max_separability",
                        "dark", out hv_UsedThreshold);
                }
                else
                {
                    ho_Region.Dispose();
                    HOperatorSet.Threshold(ho_ImageReduced, out ho_Region, 0, hv_GrayMax);
                }
                //threshold (ImageReduced, Region, 0, UsedThreshold)

                //選擇最大區域的為目標
                ho_ConnectedRegions1.Dispose();
                HOperatorSet.Connection(ho_Region, out ho_ConnectedRegions1);
                hv_Area2.Dispose(); hv_Row4.Dispose(); hv_Column4.Dispose();
                HOperatorSet.AreaCenter(ho_ConnectedRegions1, out hv_Area2, out hv_Row4, out hv_Column4);
                hv_Indices3.Dispose();
                HOperatorSet.TupleSortIndex(hv_Area2, out hv_Indices3);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_Region.Dispose();
                    HOperatorSet.SelectObj(ho_ConnectedRegions1, out ho_Region, (hv_Indices3.TupleSelect(
                        (new HTuple(hv_Indices3.TupleLength())) - 1)) + 1);
                }
                hv_WaferRow1.Dispose(); hv_WaferCol1.Dispose(); hv_WaferRow2.Dispose(); hv_WaferRCol2.Dispose();
                HOperatorSet.SmallestRectangle1(ho_Region, out hv_WaferRow1, out hv_WaferCol1,
                    out hv_WaferRow2, out hv_WaferRCol2);
                hv_Area.Dispose(); hv_Row.Dispose(); hv_Column.Dispose();
                HOperatorSet.AreaCenter(ho_Region, out hv_Area, out hv_Row, out hv_Column);
                hv_OriginRow.Dispose();
                hv_OriginRow = new HTuple(hv_Row);
                hv_OriginCol.Dispose();
                hv_OriginCol = new HTuple(hv_WaferRCol2);
                ho_Cross.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_Cross, hv_OriginRow, hv_OriginCol, 6,
                    0.785398);
                //儲存原點座標
                //OrgRowsOut := [OrgRowsOut,OriginRow*PixelSize]
                //OrgColsOut := [OrgColsOut,OriginCol*PixelSize]
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Phi_OrgX_OrgY = ((hv_Phi_OrgX_OrgY.TupleConcat(
                            hv_OriginRow))).TupleConcat(hv_OriginCol);
                        hv_Phi_OrgX_OrgY.Dispose();
                        hv_Phi_OrgX_OrgY = ExpTmpLocalVar_Phi_OrgX_OrgY;
                    }
                }
                //量測振幅，量測寬度
                hv_Amp.Dispose();
                hv_Amp = 40;
                hv_RoiWidthLen2.Dispose();
                hv_RoiWidthLen2 = 2;
                hv_Width.Dispose(); hv_Height.Dispose();
                HOperatorSet.GetImageSize(ho_ImageReduced, out hv_Width, out hv_Height);

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_bu1.Dispose(); hv_WaferOriginRow.Dispose(); hv_WaferOriginCol.Dispose();
                    MeasurePos(ho_ImageReduced, out ho_bu1, hv_Row, hv_Column, hv_Row, hv_OriginCol + 30,
                        hv_RoiWidthLen2, hv_Amp, 1, out hv_WaferOriginRow, out hv_WaferOriginCol);
                }

                if ((int)(new HTuple(hv_WaferOriginCol.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "找不到原點座標!! 無法計算，請檢查參數和影像");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                    //throw ('找不到原點座標!! 無法計算，請檢查參數和影像')
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_RectangleUp.Dispose();
                    ho_ImageReduced1.Dispose();
                    ho_ContoursSplit.Dispose();
                    ho_Circle1.Dispose();
                    ho_ObjectSelected.Dispose();
                    ho_ContEllipse.Dispose();
                    ho_RectangleDown.Dispose();
                    ho_Circle.Dispose();
                    ho_Arrow1.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_OrgLine.Dispose();

                    hv_show.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Phi.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Amp.Dispose();
                    hv_RoiWidthLen2.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_Row12.Dispose();
                    hv_Column12.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_L2.Dispose();
                    hv_Sigma.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Number.Dispose();
                    hv_R_1.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_i.Dispose();
                    hv_Attrib.Dispose();
                    hv_Radius.Dispose();
                    hv_StartPhi.Dispose();
                    hv_EndPhi.Dispose();
                    hv_PointOrder.Dispose();
                    hv_R_2.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();

                    return;
                }

                //====新版定義 A,C點==
                //轉換座
                hv_RU_row.Dispose();
                hv_RU_row = new HTuple(hv_WaferRow1);
                hv_RU_col.Dispose();
                hv_RU_col = new HTuple(hv_WaferRCol2);
                hv_A1AngOut.Dispose();
                AngleTrans(hv_A1Ang, out hv_A1AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_A1AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_A1AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_A1AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_A1AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_Row12.Dispose(); hv_Column12.Dispose(); hv_A1Row.Dispose(); hv_A1Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_Row12, out hv_Column12, out hv_A1Row, out hv_A1Col);
                ho_a1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_a1, hv_A1Row, hv_A1Col, 6, 0);
                hv_C1AngOut.Dispose();
                AngleTrans(hv_C1Ang, out hv_C1AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RU_row + (1000 * (((hv_C1AngOut.TupleRad()
                        )).TupleSin())), hv_RU_col - (1000 * (((hv_C1AngOut.TupleRad())).TupleCos()
                        )), hv_RU_row - (1000 * (((hv_C1AngOut.TupleRad())).TupleSin())), hv_RU_col + (1000 * (((hv_C1AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_Row12.Dispose(); hv_Column12.Dispose(); hv_C1Row.Dispose(); hv_C1Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_Row12, out hv_Column12, out hv_C1Row, out hv_C1Col);
                ho_c1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_c1, hv_C1Row, hv_C1Col, 6, 0);
                hv_RD_Row.Dispose();
                hv_RD_Row = new HTuple(hv_WaferRow2);
                hv_RD_Col.Dispose();
                hv_RD_Col = new HTuple(hv_WaferRCol2);
                hv_A2AngOut.Dispose();
                AngleTrans(hv_A2Ang, out hv_A2AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_A2AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_A2AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_A2AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_A2AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_Row12.Dispose(); hv_Column12.Dispose(); hv_A2Row.Dispose(); hv_A2Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_Row12, out hv_Column12, out hv_A2Row, out hv_A2Col);
                ho_a2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_a2, hv_A2Row, hv_A2Col, 6, 0);
                hv_C2AngOut.Dispose();
                AngleTrans(hv_C2Ang, out hv_C2AngOut);
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    ho_RegionLines.Dispose();
                    HOperatorSet.GenRegionLine(out ho_RegionLines, hv_RD_Row + (1000 * (((hv_C2AngOut.TupleRad()
                        )).TupleSin())), hv_RD_Col - (1000 * (((hv_C2AngOut.TupleRad())).TupleCos()
                        )), hv_RD_Row - (1000 * (((hv_C2AngOut.TupleRad())).TupleSin())), hv_RD_Col + (1000 * (((hv_C2AngOut.TupleRad()
                        )).TupleCos())));
                }
                hv_MinDistance1.Dispose(); hv_Row12.Dispose(); hv_Column12.Dispose(); hv_C2Row.Dispose(); hv_C2Col.Dispose();
                HOperatorSet.DistanceRrMin(ho_RegionLines, ho_Region, out hv_MinDistance1,
                    out hv_Row12, out hv_Column12, out hv_C2Row, out hv_C2Col);
                ho_c2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_c2, hv_C2Row, hv_C2Col, 6, 0);
                //====新版定義 A,C點==結束

                //====量測Bu Bv 計算Angle===開始==============
                hv_Amp.Dispose();
                hv_Amp = 30;
                hv_L2.Dispose();
                hv_L2 = 1;
                hv_Sigma.Dispose();
                hv_Sigma = 4;
                HOperatorSet.SetSystem("int_zooming", "true");
                hv_bu1Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu1Row2 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bu11);
                }
                hv_bu1Col2.Dispose();
                hv_bu1Col2 = new HTuple(hv_A1Col);
                hv_bu1Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu1Row1 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bu11);
                }
                hv_bu1Col1.Dispose();
                hv_bu1Col1 = new HTuple(hv_WaferOriginCol);
                ho_Arrow2.Dispose();
                gen_arrow_contour_xld(out ho_Arrow2, hv_bu1Row1, hv_bu1Col1, hv_bu1Row2, hv_bu1Col2,
                    5, 5);
                ho_bu1.Dispose(); hv_bu1Row.Dispose(); hv_bu1Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bu1, hv_bu1Row2, hv_bu1Col2, hv_bu1Row1, hv_bu1Col1,
                    hv_L2, hv_Amp, hv_Sigma, out hv_bu1Row, out hv_bu1Col);
                if ((int)(new HTuple(hv_bu1Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bu1量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bv1Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv1Row2 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bv11);
                }
                hv_bv1Col2.Dispose();
                hv_bv1Col2 = new HTuple(hv_A1Col);
                hv_bv1Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv1Row1 = hv_A1Row + ((((hv_A1Row - hv_C1Row)).TupleAbs()
                        ) * hv_bv11);
                }
                hv_bv1Col1.Dispose();
                hv_bv1Col1 = new HTuple(hv_WaferOriginCol);
                ho_Arrow2.Dispose();
                gen_arrow_contour_xld(out ho_Arrow2, hv_bv1Row2, hv_bv1Col2, hv_bv1Row1, hv_bv1Col1,
                    5, 5);
                ho_bv1.Dispose(); hv_bv1Row.Dispose(); hv_bv1Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bv1, hv_bv1Row2, hv_bv1Col2, hv_bv1Row1, hv_bv1Col1,
                    hv_L2, hv_Amp, hv_Sigma, out hv_bv1Row, out hv_bv1Col);
                if ((int)(new HTuple(hv_bv1Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bv1量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bu2Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu2Row2 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bu22);
                }
                hv_bu2Col2.Dispose();
                hv_bu2Col2 = new HTuple(hv_A2Col);
                hv_bu2Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bu2Row1 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bu22);
                }
                hv_bu2Col1.Dispose();
                hv_bu2Col1 = new HTuple(hv_WaferOriginCol);
                ho_Bu2.Dispose();
                gen_arrow_contour_xld(out ho_Bu2, hv_bu2Row1, hv_bu2Col1, hv_bu2Row2, hv_bu2Col2,
                    5, 5);
                ho_bu2.Dispose(); hv_bu2Row.Dispose(); hv_bu2Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bu2, hv_bu2Row2, hv_bu2Col2, hv_bu2Row1, hv_bu2Col1,
                    hv_L2, hv_Amp, hv_Sigma, out hv_bu2Row, out hv_bu2Col);
                if ((int)(new HTuple(hv_bu2Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bu2量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                hv_bv2Row1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv2Row1 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bv22);
                }
                hv_bv2Col1.Dispose();
                hv_bv2Col1 = new HTuple(hv_A2Col);
                hv_bv2Row2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_bv2Row2 = hv_A2Row - ((((hv_A2Row - hv_C2Row)).TupleAbs()
                        ) * hv_bv22);
                }
                hv_bv2Col2.Dispose();
                hv_bv2Col2 = new HTuple(hv_WaferOriginCol);
                ho_bv2.Dispose(); hv_bv2Row.Dispose(); hv_bv2Col.Dispose();
                MeasurePos(ho_ImageOut, out ho_bv2, hv_bv2Row1, hv_bv2Col1, hv_bv2Row2, hv_bv2Col2,
                    hv_L2, hv_Amp, hv_Sigma, out hv_bv2Row, out hv_bv2Col);
                if ((int)(new HTuple(hv_bv2Row.TupleEqual(new HTuple()))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_ErrorMsg = hv_ErrorMsg.TupleConcat(
                                "Bv2量測失敗");
                            hv_ErrorMsg.Dispose();
                            hv_ErrorMsg = ExpTmpLocalVar_ErrorMsg;
                        }
                    }
                }
                if ((int)(new HTuple(hv_ErrorMsg.TupleNotEqual(new HTuple()))) != 0)
                {
                    //throw (ErrorMsg)
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_ObjectSelected1.Dispose();
                    ho_Rectangle1.Dispose();
                    ho_Rectangle2.Dispose();
                    ho_Position1Region.Dispose();
                    ho_Position2Region.Dispose();
                    ho_Rectangle.Dispose();
                    ho_ImageReduced.Dispose();
                    ho_Region.Dispose();
                    ho_ConnectedRegions1.Dispose();
                    ho_Cross.Dispose();
                    ho_bu1.Dispose();
                    ho_RegionLines.Dispose();
                    ho_a1.Dispose();
                    ho_c1.Dispose();
                    ho_a2.Dispose();
                    ho_c2.Dispose();
                    ho_Arrow2.Dispose();
                    ho_bv1.Dispose();
                    ho_Bu2.Dispose();
                    ho_bu2.Dispose();
                    ho_bv2.Dispose();
                    ho_b1.Dispose();
                    ho_b2.Dispose();
                    ho_RectangleUp.Dispose();
                    ho_ImageReduced1.Dispose();
                    ho_ContoursSplit.Dispose();
                    ho_Circle1.Dispose();
                    ho_ObjectSelected.Dispose();
                    ho_ContEllipse.Dispose();
                    ho_RectangleDown.Dispose();
                    ho_Circle.Dispose();
                    ho_Arrow1.Dispose();
                    ho_Surface1.Dispose();
                    ho_Surface2.Dispose();
                    ho_line.Dispose();
                    ho_line1.Dispose();
                    ho_Orig.Dispose();
                    ho_OrgLine.Dispose();

                    hv_show.Dispose();
                    hv_UsedThreshold.Dispose();
                    hv_Area4.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Indices.Dispose();
                    hv_RectRow1.Dispose();
                    hv_RectColumn1.Dispose();
                    hv_RectRow2.Dispose();
                    hv_RectColumn2.Dispose();
                    hv_RectW.Dispose();
                    hv_RectH.Dispose();
                    hv_Phi.Dispose();
                    hv_Area1.Dispose();
                    hv_CenterLRow.Dispose();
                    hv_CenterLCol.Dispose();
                    hv_Area3.Dispose();
                    hv_CenterRRow.Dispose();
                    hv_CenterRCol.Dispose();
                    hv_HomMat2DIdentity.Dispose();
                    hv_rotateRow.Dispose();
                    hv_rotateCol.Dispose();
                    hv_HomMat2DRotate.Dispose();
                    hv_rotateAng.Dispose();
                    hv_Area2.Dispose();
                    hv_Row4.Dispose();
                    hv_Column4.Dispose();
                    hv_Indices3.Dispose();
                    hv_WaferRow1.Dispose();
                    hv_WaferCol1.Dispose();
                    hv_WaferRow2.Dispose();
                    hv_WaferRCol2.Dispose();
                    hv_Area.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_OriginRow.Dispose();
                    hv_OriginCol.Dispose();
                    hv_Amp.Dispose();
                    hv_RoiWidthLen2.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_WaferOriginRow.Dispose();
                    hv_WaferOriginCol.Dispose();
                    hv_RU_row.Dispose();
                    hv_RU_col.Dispose();
                    hv_A1AngOut.Dispose();
                    hv_MinDistance1.Dispose();
                    hv_Row12.Dispose();
                    hv_Column12.Dispose();
                    hv_A1Row.Dispose();
                    hv_A1Col.Dispose();
                    hv_C1AngOut.Dispose();
                    hv_C1Row.Dispose();
                    hv_C1Col.Dispose();
                    hv_RD_Row.Dispose();
                    hv_RD_Col.Dispose();
                    hv_A2AngOut.Dispose();
                    hv_A2Row.Dispose();
                    hv_A2Col.Dispose();
                    hv_C2AngOut.Dispose();
                    hv_C2Row.Dispose();
                    hv_C2Col.Dispose();
                    hv_L2.Dispose();
                    hv_Sigma.Dispose();
                    hv_bu1Row2.Dispose();
                    hv_bu1Col2.Dispose();
                    hv_bu1Row1.Dispose();
                    hv_bu1Col1.Dispose();
                    hv_bu1Row.Dispose();
                    hv_bu1Col.Dispose();
                    hv_bv1Row2.Dispose();
                    hv_bv1Col2.Dispose();
                    hv_bv1Row1.Dispose();
                    hv_bv1Col1.Dispose();
                    hv_bv1Row.Dispose();
                    hv_bv1Col.Dispose();
                    hv_bu2Row2.Dispose();
                    hv_bu2Col2.Dispose();
                    hv_bu2Row1.Dispose();
                    hv_bu2Col1.Dispose();
                    hv_bu2Row.Dispose();
                    hv_bu2Col.Dispose();
                    hv_bv2Row1.Dispose();
                    hv_bv2Col1.Dispose();
                    hv_bv2Row2.Dispose();
                    hv_bv2Col2.Dispose();
                    hv_bv2Row.Dispose();
                    hv_bv2Col.Dispose();
                    hv_B1Row.Dispose();
                    hv_B1Col.Dispose();
                    hv_IsOverlapping.Dispose();
                    hv_B2Row.Dispose();
                    hv_B2Col.Dispose();
                    hv_Angle1.Dispose();
                    hv_Angle2.Dispose();
                    hv_Number.Dispose();
                    hv_R_1.Dispose();
                    hv_R_1CenterRow.Dispose();
                    hv_R_1CenterCol.Dispose();
                    hv_i.Dispose();
                    hv_Attrib.Dispose();
                    hv_Radius.Dispose();
                    hv_StartPhi.Dispose();
                    hv_EndPhi.Dispose();
                    hv_PointOrder.Dispose();
                    hv_R_2.Dispose();
                    hv_R_2CenterRow.Dispose();
                    hv_R_2CenterCol.Dispose();
                    hv_Length.Dispose();
                    hv_Line_Org.Dispose();
                    hv_Line_Surface1.Dispose();
                    hv_Line_Surface2.Dispose();
                    hv_Line_Ang1.Dispose();
                    hv_Line_Ang2.Dispose();
                    hv_Line_A1.Dispose();
                    hv_Line_A2.Dispose();
                    hv_Line_B1.Dispose();
                    hv_Line_B2.Dispose();
                    hv_Line_R1.Dispose();
                    hv_Line_R2.Dispose();
                    hv_Line_C1.Dispose();
                    hv_Line_C2.Dispose();
                    hv_Lines.Dispose();
                    hv_X1_idx.Dispose();
                    hv_Y1_idx.Dispose();
                    hv_X2_idx.Dispose();
                    hv_Y2_idx.Dispose();
                    hv_textA1.Dispose();
                    hv_textA2.Dispose();
                    hv_textB1.Dispose();
                    hv_textB2.Dispose();
                    hv_textBC.Dispose();
                    hv_textC1.Dispose();
                    hv_textC2.Dispose();
                    hv_textR1.Dispose();
                    hv_textR2.Dispose();
                    hv_textt.Dispose();
                    hv_textAng1.Dispose();
                    hv_textAng2.Dispose();
                    hv_texts.Dispose();
                    hv_text_idx.Dispose();
                    hv_textX_idx.Dispose();
                    hv_textY_idx.Dispose();
                    hv_S4.Dispose();
                    hv_WindowHandle.Dispose();

                    return;
                }
                //計算B1
                hv_B1Row.Dispose(); hv_B1Col.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_bu1Row, hv_bu1Col, hv_bv1Row, hv_bv1Col,
                    0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol, out hv_B1Row, out hv_B1Col,
                    out hv_IsOverlapping);
                //計算B2
                hv_B2Row.Dispose(); hv_B2Col.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_bu2Row, hv_bu2Col, hv_bv2Row, hv_bv2Col,
                    0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol, out hv_B2Row, out hv_B2Col,
                    out hv_IsOverlapping);
                ho_b1.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b1, hv_B1Row, hv_B1Col, 20, 0);
                ho_b2.Dispose();
                HOperatorSet.GenCrossContourXld(out ho_b2, hv_B2Row, hv_B2Col, 20, 0);
                //計算 B1 & B2 座標
                hv_Angle1.Dispose();
                HOperatorSet.AngleLx(hv_bu1Row, hv_bu1Col, hv_bv1Row, hv_bv1Col, out hv_Angle1);
                hv_Angle2.Dispose();
                HOperatorSet.AngleLx(hv_bu2Row, hv_bu2Col, hv_bv2Row, hv_bv2Col, out hv_Angle2);
                hv_Ang1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Ang1 = ((hv_Angle1.TupleDeg()
                        )).TupleAbs();
                }
                hv_Ang2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Ang2 = ((hv_Angle2.TupleDeg()
                        )).TupleAbs();
                }
                //====量測Bu Bv 計算Angle===結束===========

                //計算t
                hv_t.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_t = ((hv_A1Row - hv_A2Row)).TupleAbs()
                        ;
                }

                //量測導角上-----開始----
                ho_RectangleUp.Dispose();
                HOperatorSet.GenRectangle1(out ho_RectangleUp, hv_bv1Row, hv_bv1Col, hv_C1Row,
                    hv_C1Col);
                ho_ImageReduced1.Dispose();
                HOperatorSet.ReduceDomain(ho_ImageOut, ho_RectangleUp, out ho_ImageReduced1
                    );
                ho_ContoursSplit.Dispose();
                HOperatorSet.ThresholdSubPix(ho_ImageReduced1, out ho_ContoursSplit, 128);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.SegmentContoursXld(ho_ContoursSplit, out ExpTmpOutVar_0, "lines_circles",
                        5, 1, 3);
                    ho_ContoursSplit.Dispose();
                    ho_ContoursSplit = ExpTmpOutVar_0;
                }
                hv_Number.Dispose();
                HOperatorSet.CountObj(ho_ContoursSplit, out hv_Number);
                ho_Circle1.Dispose();
                HOperatorSet.GenEmptyObj(out ho_Circle1);
                hv_R_1.Dispose();
                hv_R_1 = new HTuple();
                hv_R_1CenterRow.Dispose();
                hv_R_1CenterRow = new HTuple();
                hv_R_1CenterCol.Dispose();
                hv_R_1CenterCol = new HTuple();
                HTuple end_val183 = hv_Number;
                HTuple step_val183 = 1;
                for (hv_i = 1; hv_i.Continue(end_val183, step_val183); hv_i = hv_i.TupleAdd(step_val183))
                {
                    ho_ObjectSelected.Dispose();
                    HOperatorSet.SelectObj(ho_ContoursSplit, out ho_ObjectSelected, hv_i);
                    hv_Attrib.Dispose();
                    HOperatorSet.GetContourGlobalAttribXld(ho_ObjectSelected, "cont_approx",
                        out hv_Attrib);
                    if ((int)(new HTuple(hv_Attrib.TupleGreater(0))) != 0)
                    {
                        hv_Row.Dispose(); hv_Column.Dispose(); hv_Radius.Dispose(); hv_StartPhi.Dispose(); hv_EndPhi.Dispose(); hv_PointOrder.Dispose();
                        HOperatorSet.FitCircleContourXld(ho_ObjectSelected, "ahuber", -1, 2, 0,
                            3, 2, out hv_Row, out hv_Column, out hv_Radius, out hv_StartPhi, out hv_EndPhi,
                            out hv_PointOrder);
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_ContEllipse.Dispose();
                            HOperatorSet.GenEllipseContourXld(out ho_ContEllipse, hv_Row, hv_Column,
                                0, hv_Radius, hv_Radius, 0, 4 * ((new HTuple(0)).TupleAcos()), "positive",
                                1.0);
                        }

                        if ((int)((new HTuple((new HTuple(hv_Radius.TupleLess(hv_t / 2))).TupleAnd(
                            new HTuple(hv_Radius.TupleGreater(hv_t / 4))))).TupleAnd(new HTuple(hv_Row.TupleLess(
                            hv_WaferOriginRow)))) != 0)
                        {
                            {
                                HObject ExpTmpOutVar_0;
                                HOperatorSet.ConcatObj(ho_Circle1, ho_ContEllipse, out ExpTmpOutVar_0
                                    );
                                ho_Circle1.Dispose();
                                ho_Circle1 = ExpTmpOutVar_0;
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_1 = hv_R_1.TupleConcat(
                                        hv_Radius);
                                    hv_R_1.Dispose();
                                    hv_R_1 = ExpTmpLocalVar_R_1;
                                }
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_1CenterRow = hv_R_1CenterRow.TupleConcat(
                                        hv_Row);
                                    hv_R_1CenterRow.Dispose();
                                    hv_R_1CenterRow = ExpTmpLocalVar_R_1CenterRow;
                                }
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_1CenterCol = hv_R_1CenterCol.TupleConcat(
                                        hv_Column);
                                    hv_R_1CenterCol.Dispose();
                                    hv_R_1CenterCol = ExpTmpLocalVar_R_1CenterCol;
                                }
                            }
                        }
                    }
                }
                //導角上-----結束----

                //導角下-----開始----
                ho_RectangleDown.Dispose();
                HOperatorSet.GenRectangle1(out ho_RectangleDown, hv_C2Row, hv_bv2Col, hv_bv2Row,
                    hv_C2Col);
                ho_ImageReduced1.Dispose();
                HOperatorSet.ReduceDomain(ho_ImageOut, ho_RectangleDown, out ho_ImageReduced1
                    );
                ho_ContoursSplit.Dispose();
                HOperatorSet.ThresholdSubPix(ho_ImageReduced1, out ho_ContoursSplit, hv_UsedThreshold);
                {
                    HObject ExpTmpOutVar_0;
                    HOperatorSet.SegmentContoursXld(ho_ContoursSplit, out ExpTmpOutVar_0, "lines_circles",
                        5, 1, 3);
                    ho_ContoursSplit.Dispose();
                    ho_ContoursSplit = ExpTmpOutVar_0;
                }
                hv_Number.Dispose();
                HOperatorSet.CountObj(ho_ContoursSplit, out hv_Number);
                ho_Circle.Dispose();
                HOperatorSet.GenEmptyObj(out ho_Circle);
                hv_R_2.Dispose();
                hv_R_2 = new HTuple();
                hv_R_2CenterRow.Dispose();
                hv_R_2CenterRow = new HTuple();
                hv_R_2CenterCol.Dispose();
                hv_R_2CenterCol = new HTuple();
                HTuple end_val210 = hv_Number;
                HTuple step_val210 = 1;
                for (hv_i = 1; hv_i.Continue(end_val210, step_val210); hv_i = hv_i.TupleAdd(step_val210))
                {
                    ho_ObjectSelected.Dispose();
                    HOperatorSet.SelectObj(ho_ContoursSplit, out ho_ObjectSelected, hv_i);
                    hv_Attrib.Dispose();
                    HOperatorSet.GetContourGlobalAttribXld(ho_ObjectSelected, "cont_approx",
                        out hv_Attrib);
                    if ((int)(new HTuple(hv_Attrib.TupleGreater(0))) != 0)
                    {
                        hv_Row.Dispose(); hv_Column.Dispose(); hv_Radius.Dispose(); hv_StartPhi.Dispose(); hv_EndPhi.Dispose(); hv_PointOrder.Dispose();
                        HOperatorSet.FitCircleContourXld(ho_ObjectSelected, "ahuber", -1, 2, 0,
                            3, 2, out hv_Row, out hv_Column, out hv_Radius, out hv_StartPhi, out hv_EndPhi,
                            out hv_PointOrder);
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            ho_ContEllipse.Dispose();
                            HOperatorSet.GenEllipseContourXld(out ho_ContEllipse, hv_Row, hv_Column,
                                0, hv_Radius, hv_Radius, 0, 4 * ((new HTuple(0)).TupleAcos()), "positive",
                                1.0);
                        }

                        if ((int)((new HTuple((new HTuple(hv_Radius.TupleLess(hv_t / 2))).TupleAnd(
                            new HTuple(hv_Radius.TupleGreater(hv_t / 4))))).TupleAnd(new HTuple(hv_Row.TupleGreater(
                            hv_WaferOriginRow)))) != 0)
                        {
                            {
                                HObject ExpTmpOutVar_0;
                                HOperatorSet.ConcatObj(ho_Circle, ho_ContEllipse, out ExpTmpOutVar_0);
                                ho_Circle.Dispose();
                                ho_Circle = ExpTmpOutVar_0;
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_2 = hv_R_2.TupleConcat(
                                        hv_Radius);
                                    hv_R_2.Dispose();
                                    hv_R_2 = ExpTmpLocalVar_R_2;
                                }
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_2CenterRow = hv_R_2CenterRow.TupleConcat(
                                        hv_Row);
                                    hv_R_2CenterRow.Dispose();
                                    hv_R_2CenterRow = ExpTmpLocalVar_R_2CenterRow;
                                }
                            }
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                {
                                    HTuple
                                      ExpTmpLocalVar_R_2CenterCol = hv_R_2CenterCol.TupleConcat(
                                        hv_Column);
                                    hv_R_2CenterCol.Dispose();
                                    hv_R_2CenterCol = ExpTmpLocalVar_R_2CenterCol;
                                }
                            }
                        }
                    }

                }
                //導角下-----結束----




                hv_A1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A1 = (hv_B1Col - hv_A1Col) * hv_PixelSize;
                }
                hv_A2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_A2 = (hv_B2Col - hv_A2Col) * hv_PixelSize;
                }
                hv_B1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_B1 = (((hv_A1Row - hv_B1Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                hv_B2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_B2 = (((hv_A2Row - hv_B2Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                hv_BC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_BC = (((hv_B1Row - hv_B2Row)).TupleAbs()
                        ) * hv_PixelSize;
                }
                if ((int)(new HTuple(hv_R_1CenterRow.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_C1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_C1 = (((hv_B1Row - (hv_R_1CenterRow.TupleSelect(
                            0)))).TupleAbs()) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_C1.Dispose();
                    hv_C1 = -1;
                }
                if ((int)(new HTuple(hv_R_2CenterRow.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_C2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_C2 = (((hv_B2Row - (hv_R_2CenterRow.TupleSelect(
                            0)))).TupleAbs()) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_C2.Dispose();
                    hv_C2 = -1;
                }


                if ((int)(new HTuple(hv_R_1.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_R1.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_R1 = (hv_R_1.TupleSelect(
                            0)) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_R1.Dispose();
                    hv_R1 = -1;
                }
                if ((int)(new HTuple(hv_R_2.TupleNotEqual(new HTuple()))) != 0)
                {
                    hv_R2.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_R2 = (hv_R_2.TupleSelect(
                            0)) * hv_PixelSize;
                    }
                }
                else
                {
                    hv_R2.Dispose();
                    hv_R2 = -1;
                }

                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_t = hv_t * hv_PixelSize;
                        hv_t.Dispose();
                        hv_t = ExpTmpLocalVar_t;
                    }
                }
                //可視化參數輸出
                hv_Length.Dispose();
                hv_Length = 100;
                hv_Cir_c1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Cir_c1 = new HTuple();
                    hv_Cir_c1 = hv_Cir_c1.TupleConcat(hv_R_1CenterCol.TupleSelect(
                        0));
                    hv_Cir_c1 = hv_Cir_c1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                    hv_Cir_c1 = hv_Cir_c1.TupleConcat((hv_R_1.TupleSelect(0)) / hv_PixelSize);
                }
                hv_Cir_c2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Cir_c2 = new HTuple();
                    hv_Cir_c2 = hv_Cir_c2.TupleConcat(hv_R_2CenterCol.TupleSelect(
                        0));
                    hv_Cir_c2 = hv_Cir_c2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                    hv_Cir_c2 = hv_Cir_c2.TupleConcat((hv_R_2.TupleSelect(0)) / hv_PixelSize);
                }

                hv_Line_Org.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Org = new HTuple();
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_OriginCol);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_A1Row - hv_Length);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_OriginCol);
                    hv_Line_Org = hv_Line_Org.TupleConcat(hv_A2Row + hv_Length);
                }
                hv_Line_Surface1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Surface1 = new HTuple();
                    hv_Line_Surface1[0] = 0;
                    hv_Line_Surface1 = hv_Line_Surface1.TupleConcat(hv_A1Row);
                    hv_Line_Surface1 = hv_Line_Surface1.TupleConcat(hv_B1Col + hv_Length);
                    hv_Line_Surface1 = hv_Line_Surface1.TupleConcat(hv_A1Row);
                }
                hv_Line_Surface2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Surface2 = new HTuple();
                    hv_Line_Surface2[0] = 0;
                    hv_Line_Surface2 = hv_Line_Surface2.TupleConcat(hv_A2Row);
                    hv_Line_Surface2 = hv_Line_Surface2.TupleConcat(hv_B2Col + hv_Length);
                    hv_Line_Surface2 = hv_Line_Surface2.TupleConcat(hv_A2Row);
                }
                hv_Line_Ang1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Ang1 = new HTuple();
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_bu1Col - ((hv_Length * 2) * (((((-hv_Ang1)).TupleRad()
                        )).TupleCos())));
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_bu1Row + ((hv_Length * 2) * (((((-hv_Ang1)).TupleRad()
                        )).TupleSin())));
                    hv_Line_Ang1 = hv_Line_Ang1.TupleConcat(hv_B1Col, hv_B1Row);
                }
                hv_Line_Ang2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_Ang2 = new HTuple();
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_bu2Col - ((hv_Length * 2) * (((hv_Ang2.TupleRad()
                        )).TupleCos())));
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_bu2Row + ((hv_Length * 2) * (((hv_Ang2.TupleRad()
                        )).TupleSin())));
                    hv_Line_Ang2 = hv_Line_Ang2.TupleConcat(hv_B2Col, hv_B2Row);
                }
                hv_Line_A1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_A1 = new HTuple();
                    hv_Line_A1 = hv_Line_A1.TupleConcat(hv_A1Col, hv_A1Row, hv_A1Col);
                    hv_Line_A1 = hv_Line_A1.TupleConcat(hv_A1Row - hv_Length);
                }
                hv_Line_A2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_A2 = new HTuple();
                    hv_Line_A2 = hv_Line_A2.TupleConcat(hv_A2Col, hv_A2Row, hv_A2Col);
                    hv_Line_A2 = hv_Line_A2.TupleConcat(hv_A2Row + hv_Length);
                }
                hv_Line_B1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_B1 = new HTuple();
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Col, hv_B1Row);
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Col + hv_Length);
                    hv_Line_B1 = hv_Line_B1.TupleConcat(hv_B1Row);
                }
                hv_Line_B2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_B2 = new HTuple();
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Col, hv_B2Row);
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Col + hv_Length);
                    hv_Line_B2 = hv_Line_B2.TupleConcat(hv_B2Row);
                }
                hv_Line_R1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_R1 = new HTuple();
                    hv_Line_R1 = hv_Line_R1.TupleConcat(hv_R_1CenterCol.TupleSelect(
                        0));
                    hv_Line_R1 = hv_Line_R1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                    hv_Line_R1 = hv_Line_R1.TupleConcat((hv_R_1CenterCol.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleCos()
                        )));
                    hv_Line_R1 = hv_Line_R1.TupleConcat((hv_R_1CenterRow.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_Line_R2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_R2 = new HTuple();
                    hv_Line_R2 = hv_Line_R2.TupleConcat(hv_R_2CenterCol.TupleSelect(
                        0));
                    hv_Line_R2 = hv_Line_R2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                    hv_Line_R2 = hv_Line_R2.TupleConcat((hv_R_2CenterCol.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang2)).TupleRad())).TupleCos()
                        )));
                    hv_Line_R2 = hv_Line_R2.TupleConcat((hv_R_2CenterRow.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_Line_C1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_C1 = new HTuple();
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_OriginCol + (hv_Length * 0.1));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_OriginCol + (hv_Length * 0.5));
                    hv_Line_C1 = hv_Line_C1.TupleConcat(hv_R_1CenterRow.TupleSelect(
                        0));
                }
                hv_Line_C2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Line_C2 = new HTuple();
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_OriginCol + (hv_Length * 0.1));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_OriginCol + (hv_Length * 0.5));
                    hv_Line_C2 = hv_Line_C2.TupleConcat(hv_R_2CenterRow.TupleSelect(
                        0));
                }

                hv_Lines.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Lines = new HTuple();
                    hv_Lines = hv_Lines.TupleConcat(hv_Line_Org, hv_Line_Surface1, hv_Line_Surface2, hv_Line_Ang1, hv_Line_Ang2, hv_Line_A1, hv_Line_A2, hv_Line_B1, hv_Line_B2, hv_Line_R1, hv_Line_R2, hv_Line_C1, hv_Line_C2);
                }
                hv_Number.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Number = new HTuple(hv_Lines.TupleLength()
                        );
                }
                hv_X1_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X1_idx = HTuple.TupleGenSequence(
                        0, hv_Number - 1, 4);
                }
                hv_Y1_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Y1_idx = HTuple.TupleGenSequence(
                        1, hv_Number - 1, 4);
                }
                hv_X2_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_X2_idx = HTuple.TupleGenSequence(
                        2, hv_Number - 1, 4);
                }
                hv_Y2_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_Y2_idx = HTuple.TupleGenSequence(
                        3, hv_Number - 1, 4);
                }

                hv_LinesX1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesX1 = hv_Lines.TupleSelect(
                        hv_X1_idx);
                }
                hv_LinesY1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesY1 = hv_Lines.TupleSelect(
                        hv_Y1_idx);
                }
                hv_LinesX2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesX2 = hv_Lines.TupleSelect(
                        hv_X2_idx);
                }
                hv_LinesY2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_LinesY2 = hv_Lines.TupleSelect(
                        hv_Y2_idx);
                }
                //建立每個輸出的文字及座標
                hv_textA1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textA1 = new HTuple();
                    hv_textA1[0] = "A1";
                    hv_textA1 = hv_textA1.TupleConcat((((hv_A1Col + hv_OriginCol)).TupleAbs()
                        ) / 2);
                    hv_textA1 = hv_textA1.TupleConcat(hv_A1Row);
                }
                hv_textA2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textA2 = new HTuple();
                    hv_textA2[0] = "A2";
                    hv_textA2 = hv_textA2.TupleConcat((((hv_A2Col + hv_OriginCol)).TupleAbs()
                        ) / 2);
                    hv_textA2 = hv_textA2.TupleConcat(hv_A2Row);
                }
                hv_textB1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textB1 = new HTuple();
                    hv_textB1[0] = "B1";
                    hv_textB1 = hv_textB1.TupleConcat(hv_B1Col);
                    hv_textB1 = hv_textB1.TupleConcat((((hv_B1Row + hv_A1Row)).TupleAbs()
                        ) / 2);
                }
                hv_textB2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textB2 = new HTuple();
                    hv_textB2[0] = "B1";
                    hv_textB2 = hv_textB2.TupleConcat(hv_B1Col);
                    hv_textB2 = hv_textB2.TupleConcat((((hv_B2Row + hv_A2Row)).TupleAbs()
                        ) / 2);
                }
                hv_textBC.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textBC = new HTuple();
                    hv_textBC[0] = "BC";
                    hv_textBC = hv_textBC.TupleConcat(hv_OriginCol + (0.8 * hv_Length));
                    hv_textBC = hv_textBC.TupleConcat(hv_OriginRow);
                }
                hv_textC1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textC1 = new HTuple();
                    hv_textC1[0] = "C1";
                    hv_textC1 = hv_textC1.TupleConcat(hv_OriginCol + (0.55 * hv_Length));
                    hv_textC1 = hv_textC1.TupleConcat(hv_B1Row + (hv_Cir_c1.TupleSelect(
                        2)));
                }
                hv_textC2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textC2 = new HTuple();
                    hv_textC2[0] = "C2";
                    hv_textC2 = hv_textC2.TupleConcat(hv_OriginCol + (0.55 * hv_Length));
                    hv_textC2 = hv_textC2.TupleConcat(hv_B2Row - (hv_Cir_c2.TupleSelect(
                        2)));
                }
                hv_textR1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textR1 = new HTuple();
                    hv_textR1[0] = "R1";
                    hv_textR1 = hv_textR1.TupleConcat((hv_R_1CenterCol.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleCos()
                        )));
                    hv_textR1 = hv_textR1.TupleConcat((hv_R_1CenterRow.TupleSelect(
                        0)) + ((hv_R_1.TupleSelect(0)) * (((((180 + hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_textR2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textR2 = new HTuple();
                    hv_textR2[0] = "R2";
                    hv_textR2 = hv_textR2.TupleConcat((hv_R_2CenterCol.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang2)).TupleRad())).TupleCos()
                        )));
                    hv_textR2 = hv_textR2.TupleConcat((hv_R_2CenterRow.TupleSelect(
                        0)) + ((hv_R_2.TupleSelect(0)) * (((((180 - hv_Ang1)).TupleRad())).TupleSin()
                        )));
                }
                hv_textt.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textt = new HTuple();
                    hv_textt[0] = "t";
                    hv_textt = hv_textt.TupleConcat(hv_A1Col - hv_Length);
                    hv_textt = hv_textt.TupleConcat(hv_OriginRow);
                }
                hv_textAng1.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textAng1 = new HTuple();
                    hv_textAng1[0] = "Ang1";
                    hv_textAng1 = hv_textAng1.TupleConcat(hv_bu1Col - ((hv_Length * 2) * ((((((-hv_Ang1) / 2)).TupleRad()
                        )).TupleCos())));
                    hv_textAng1 = hv_textAng1.TupleConcat(hv_bu1Row + ((hv_Length * 2) * ((((((-hv_Ang1) / 2)).TupleRad()
                        )).TupleSin())));
                }
                hv_textAng2.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textAng2 = new HTuple();
                    hv_textAng2[0] = "Ang2";
                    hv_textAng2 = hv_textAng2.TupleConcat(hv_bu2Col - ((hv_Length * 2) * (((((hv_Ang2 / 2)).TupleRad()
                        )).TupleCos())));
                    hv_textAng2 = hv_textAng2.TupleConcat(hv_bu2Row + ((hv_Length * 2) * (((((hv_Ang2 / 2)).TupleRad()
                        )).TupleSin())));
                }
                //建立全部文字
                hv_texts.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_texts = new HTuple();
                    hv_texts = hv_texts.TupleConcat(hv_textA1, hv_textA2, hv_textB1, hv_textB2, hv_textBC, hv_textC1, hv_textC2, hv_textR1, hv_textR2, hv_textt, hv_textAng1, hv_textAng2);
                }
                hv_text_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_text_idx = HTuple.TupleGenSequence(
                        0, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_textX_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textX_idx = HTuple.TupleGenSequence(
                        1, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_textY_idx.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_textY_idx = HTuple.TupleGenSequence(
                        2, (new HTuple(hv_texts.TupleLength())) - 1, 3);
                }
                hv_TextsText.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsText = hv_texts.TupleSelect(
                        hv_text_idx);
                }
                hv_TextsX.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsX = hv_texts.TupleSelect(
                        hv_textX_idx);
                }
                hv_TextsY.Dispose();
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    hv_TextsY = hv_texts.TupleSelect(
                        hv_textY_idx);
                }

                //===顯示開始====
                if ((int)(new HTuple(hv_show.TupleEqual(1))) != 0)
                {
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.ClearWindow(HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_ImageOut, HDevWindowStack.GetActive());
                    }
                    //====新版
                    //gen_cross_contour_xld (Cross, Pnt_a1[1], Pnt_a1[0], 6, Ang1)
                    //gen_cross_contour_xld (Cross1, Pnt_a2[1], Pnt_a2[0], 6, Ang1)
                    //gen_cross_contour_xld (Cross2, Cir_c1[1], Cir_c1[0], 6, Ang1)
                    //gen_cross_contour_xld (Cross3, Cir_c2[1], Cir_c2[0], 6, Ang1)
                    //gen_arrow_contour_xld (Arrow, Line_Ang1[1], Line_Ang1[0], Line_Ang1[3], Line_Ang1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow1, Line_Ang2[1], Line_Ang2[0], Line_Ang2[3], Line_Ang2[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow2, Line_Surface1[1], Line_Surface1[0], Line_Surface1[3], Line_Surface1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow3, Line_Surface2[1], Line_Surface2[0], Line_Surface2[3], Line_Surface2[2], 0, 0)
                    //gen_circle_contour_xld (ContCircle, Cir_c1[1], Cir_c1[0], Cir_c1[2], 0, 6.28318, 'positive', 1)
                    //gen_circle_contour_xld (ContCircle2, Cir_c2[1], Cir_c2[0], Cir_c2[2], 0, 6.28318, 'positive', 1)
                    //gen_arrow_contour_xld (Arrow, Line_Org[1], Line_Org[0], Line_Org[3], Line_Org[2], 0, 0)

                    //gen_arrow_contour_xld (Arrow, Line_A1[1], Line_A1[0], Line_A1[3], Line_A1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_A2[1], Line_A2[0], Line_A2[3], Line_A2[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_B1[1], Line_B1[0], Line_B1[3], Line_B1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_B2[1], Line_B2[0], Line_B2[3], Line_B2[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_R1[1], Line_R1[0], Line_R1[3], Line_R1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_R2[1], Line_R2[0], Line_R2[3], Line_R2[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_C1[1], Line_C1[0], Line_C1[3], Line_C1[2], 0, 0)
                    //gen_arrow_contour_xld (Arrow, Line_C2[1], Line_C2[0], Line_C2[3], Line_C2[2], 0, 0)

                    //=======

                    ho_Surface1.Dispose();
                    gen_arrow_contour_xld(out ho_Surface1, hv_A1Row, 0, hv_A1Row, hv_Width, 0,
                        0);
                    ho_Surface2.Dispose();
                    gen_arrow_contour_xld(out ho_Surface2, hv_A2Row, 0, hv_A2Row, hv_Width, 0,
                        0);
                    ho_line.Dispose();
                    gen_arrow_contour_xld(out ho_line, hv_bu1Row, hv_bu1Col, hv_B1Row, hv_B1Col,
                        0, 0);
                    ho_line1.Dispose();
                    gen_arrow_contour_xld(out ho_line1, hv_bu2Row, hv_bu2Col, hv_B2Row, hv_B2Col,
                        0, 0);
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_line, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_line1, HDevWindowStack.GetActive());
                    }
                    ho_a1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_a1, hv_A1Row, hv_A1Col, 20, 0);
                    ho_c1.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_c1, hv_C1Row, hv_C1Col, 20, 0);
                    ho_a2.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_a2, hv_A2Row, hv_A2Col, 20, 0);
                    ho_c2.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_c2, hv_C2Row, hv_C2Col, 20, 0);
                    ho_Orig.Dispose();
                    HOperatorSet.GenCrossContourXld(out ho_Orig, hv_WaferOriginRow, hv_WaferOriginCol,
                        20, 0);
                    ho_Arrow1.Dispose();
                    gen_arrow_contour_xld(out ho_Arrow1, 0, hv_WaferOriginCol, hv_Height, hv_WaferOriginCol,
                        0, 0);
                    ho_OrgLine.Dispose();
                    gen_arrow_contour_xld(out ho_OrgLine, hv_WaferOriginRow, 0, hv_WaferOriginRow,
                        hv_Width, 5, 5);
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_OrgLine, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Orig, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Arrow1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Surface1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Surface2, HDevWindowStack.GetActive());
                    }
                    {
                        HObject ExpTmpOutVar_0;
                        HOperatorSet.SelectObj(ho_Circle1, out ExpTmpOutVar_0, 1);
                        ho_Circle1.Dispose();
                        ho_Circle1 = ExpTmpOutVar_0;
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Circle1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Circle, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "t= " + hv_t, "image",
                                hv_WaferOriginRow, 1080, "red", "box", "false");
                        }
                    }

                    hv_S4.Dispose();
                    HOperatorSet.CountSeconds(out hv_S4);
                    if (HDevWindowStack.IsOpen())
                    {
                        hv_WindowHandle = HDevWindowStack.GetActive();
                    }
                    set_display_font(hv_WindowHandle, 16, "mono", "true", "false");
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetDraw(HDevWindowStack.GetActive(), "margin");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Rectangle, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "blue");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_a1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_c1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_a2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_c2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_b1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_b2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispText(HDevWindowStack.GetActive(), "a2", "image", hv_A2Row,
                            hv_A2Col, "blue", "box", "false");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "a1", "image", hv_A1Row - 25,
                                hv_A1Col, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "b1", "image", hv_B1Row - 25,
                                hv_B1Col - 25, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "b2", "image", hv_B2Row,
                                hv_B2Col - 25, "blue", "box", "false");
                        }
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bv1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bv2, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bu1, HDevWindowStack.GetActive());
                    }
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_bu2, HDevWindowStack.GetActive());
                    }
                    //這一行可以加到function外面顯示結果   ((可加圖片編號'No.'+[]
                    if (HDevWindowStack.IsOpen())
                    {
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), (((((((((((((((((((((((((("No." + new HTuple()) + "   Phi ") + hv_Phi_OrgX_OrgY)).TupleConcat(
                                "A1 =" + (hv_A1.TupleString(".2f"))))).TupleConcat("A2 =" + (hv_A2.TupleString(
                                ".2f"))))).TupleConcat("B1 =" + (hv_B1.TupleString(".2f"))))).TupleConcat(
                                "B2 =" + (hv_B2.TupleString(".2f"))))).TupleConcat("BC =" + (hv_BC.TupleString(
                                ".2f"))))).TupleConcat("C1 =" + hv_C1))).TupleConcat("C2 =" + hv_C2))).TupleConcat(
                                "R1 =" + hv_R1))).TupleConcat("R2 =" + hv_R2))).TupleConcat("t =" + hv_t))).TupleConcat(
                                "Ang1 =" + hv_Ang1))).TupleConcat("Ang2 =" + hv_Ang2), "window", 80, 50,
                                "black", new HTuple(), new HTuple());
                        }
                    }
                }
                //===顯示結束====
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_Position1Region.Dispose();
                ho_Position2Region.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Region.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Cross.Dispose();
                ho_bu1.Dispose();
                ho_RegionLines.Dispose();
                ho_a1.Dispose();
                ho_c1.Dispose();
                ho_a2.Dispose();
                ho_c2.Dispose();
                ho_Arrow2.Dispose();
                ho_bv1.Dispose();
                ho_Bu2.Dispose();
                ho_bu2.Dispose();
                ho_bv2.Dispose();
                ho_b1.Dispose();
                ho_b2.Dispose();
                ho_RectangleUp.Dispose();
                ho_ImageReduced1.Dispose();
                ho_ContoursSplit.Dispose();
                ho_Circle1.Dispose();
                ho_ObjectSelected.Dispose();
                ho_ContEllipse.Dispose();
                ho_RectangleDown.Dispose();
                ho_Circle.Dispose();
                ho_Arrow1.Dispose();
                ho_Surface1.Dispose();
                ho_Surface2.Dispose();
                ho_line.Dispose();
                ho_line1.Dispose();
                ho_Orig.Dispose();
                ho_OrgLine.Dispose();

                hv_show.Dispose();
                hv_UsedThreshold.Dispose();
                hv_Area4.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices.Dispose();
                hv_RectRow1.Dispose();
                hv_RectColumn1.Dispose();
                hv_RectRow2.Dispose();
                hv_RectColumn2.Dispose();
                hv_RectW.Dispose();
                hv_RectH.Dispose();
                hv_Phi.Dispose();
                hv_Area1.Dispose();
                hv_CenterLRow.Dispose();
                hv_CenterLCol.Dispose();
                hv_Area3.Dispose();
                hv_CenterRRow.Dispose();
                hv_CenterRCol.Dispose();
                hv_HomMat2DIdentity.Dispose();
                hv_rotateRow.Dispose();
                hv_rotateCol.Dispose();
                hv_HomMat2DRotate.Dispose();
                hv_rotateAng.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Indices3.Dispose();
                hv_WaferRow1.Dispose();
                hv_WaferCol1.Dispose();
                hv_WaferRow2.Dispose();
                hv_WaferRCol2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_OriginRow.Dispose();
                hv_OriginCol.Dispose();
                hv_Amp.Dispose();
                hv_RoiWidthLen2.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_WaferOriginRow.Dispose();
                hv_WaferOriginCol.Dispose();
                hv_RU_row.Dispose();
                hv_RU_col.Dispose();
                hv_A1AngOut.Dispose();
                hv_MinDistance1.Dispose();
                hv_Row12.Dispose();
                hv_Column12.Dispose();
                hv_A1Row.Dispose();
                hv_A1Col.Dispose();
                hv_C1AngOut.Dispose();
                hv_C1Row.Dispose();
                hv_C1Col.Dispose();
                hv_RD_Row.Dispose();
                hv_RD_Col.Dispose();
                hv_A2AngOut.Dispose();
                hv_A2Row.Dispose();
                hv_A2Col.Dispose();
                hv_C2AngOut.Dispose();
                hv_C2Row.Dispose();
                hv_C2Col.Dispose();
                hv_L2.Dispose();
                hv_Sigma.Dispose();
                hv_bu1Row2.Dispose();
                hv_bu1Col2.Dispose();
                hv_bu1Row1.Dispose();
                hv_bu1Col1.Dispose();
                hv_bu1Row.Dispose();
                hv_bu1Col.Dispose();
                hv_bv1Row2.Dispose();
                hv_bv1Col2.Dispose();
                hv_bv1Row1.Dispose();
                hv_bv1Col1.Dispose();
                hv_bv1Row.Dispose();
                hv_bv1Col.Dispose();
                hv_bu2Row2.Dispose();
                hv_bu2Col2.Dispose();
                hv_bu2Row1.Dispose();
                hv_bu2Col1.Dispose();
                hv_bu2Row.Dispose();
                hv_bu2Col.Dispose();
                hv_bv2Row1.Dispose();
                hv_bv2Col1.Dispose();
                hv_bv2Row2.Dispose();
                hv_bv2Col2.Dispose();
                hv_bv2Row.Dispose();
                hv_bv2Col.Dispose();
                hv_B1Row.Dispose();
                hv_B1Col.Dispose();
                hv_IsOverlapping.Dispose();
                hv_B2Row.Dispose();
                hv_B2Col.Dispose();
                hv_Angle1.Dispose();
                hv_Angle2.Dispose();
                hv_Number.Dispose();
                hv_R_1.Dispose();
                hv_R_1CenterRow.Dispose();
                hv_R_1CenterCol.Dispose();
                hv_i.Dispose();
                hv_Attrib.Dispose();
                hv_Radius.Dispose();
                hv_StartPhi.Dispose();
                hv_EndPhi.Dispose();
                hv_PointOrder.Dispose();
                hv_R_2.Dispose();
                hv_R_2CenterRow.Dispose();
                hv_R_2CenterCol.Dispose();
                hv_Length.Dispose();
                hv_Line_Org.Dispose();
                hv_Line_Surface1.Dispose();
                hv_Line_Surface2.Dispose();
                hv_Line_Ang1.Dispose();
                hv_Line_Ang2.Dispose();
                hv_Line_A1.Dispose();
                hv_Line_A2.Dispose();
                hv_Line_B1.Dispose();
                hv_Line_B2.Dispose();
                hv_Line_R1.Dispose();
                hv_Line_R2.Dispose();
                hv_Line_C1.Dispose();
                hv_Line_C2.Dispose();
                hv_Lines.Dispose();
                hv_X1_idx.Dispose();
                hv_Y1_idx.Dispose();
                hv_X2_idx.Dispose();
                hv_Y2_idx.Dispose();
                hv_textA1.Dispose();
                hv_textA2.Dispose();
                hv_textB1.Dispose();
                hv_textB2.Dispose();
                hv_textBC.Dispose();
                hv_textC1.Dispose();
                hv_textC2.Dispose();
                hv_textR1.Dispose();
                hv_textR2.Dispose();
                hv_textt.Dispose();
                hv_textAng1.Dispose();
                hv_textAng2.Dispose();
                hv_texts.Dispose();
                hv_text_idx.Dispose();
                hv_textX_idx.Dispose();
                hv_textY_idx.Dispose();
                hv_S4.Dispose();
                hv_WindowHandle.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_ObjectSelected1.Dispose();
                ho_Rectangle1.Dispose();
                ho_Rectangle2.Dispose();
                ho_Position1Region.Dispose();
                ho_Position2Region.Dispose();
                ho_Rectangle.Dispose();
                ho_ImageReduced.Dispose();
                ho_Region.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_Cross.Dispose();
                ho_bu1.Dispose();
                ho_RegionLines.Dispose();
                ho_a1.Dispose();
                ho_c1.Dispose();
                ho_a2.Dispose();
                ho_c2.Dispose();
                ho_Arrow2.Dispose();
                ho_bv1.Dispose();
                ho_Bu2.Dispose();
                ho_bu2.Dispose();
                ho_bv2.Dispose();
                ho_b1.Dispose();
                ho_b2.Dispose();
                ho_RectangleUp.Dispose();
                ho_ImageReduced1.Dispose();
                ho_ContoursSplit.Dispose();
                ho_Circle1.Dispose();
                ho_ObjectSelected.Dispose();
                ho_ContEllipse.Dispose();
                ho_RectangleDown.Dispose();
                ho_Circle.Dispose();
                ho_Arrow1.Dispose();
                ho_Surface1.Dispose();
                ho_Surface2.Dispose();
                ho_line.Dispose();
                ho_line1.Dispose();
                ho_Orig.Dispose();
                ho_OrgLine.Dispose();

                hv_show.Dispose();
                hv_UsedThreshold.Dispose();
                hv_Area4.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Indices.Dispose();
                hv_RectRow1.Dispose();
                hv_RectColumn1.Dispose();
                hv_RectRow2.Dispose();
                hv_RectColumn2.Dispose();
                hv_RectW.Dispose();
                hv_RectH.Dispose();
                hv_Phi.Dispose();
                hv_Area1.Dispose();
                hv_CenterLRow.Dispose();
                hv_CenterLCol.Dispose();
                hv_Area3.Dispose();
                hv_CenterRRow.Dispose();
                hv_CenterRCol.Dispose();
                hv_HomMat2DIdentity.Dispose();
                hv_rotateRow.Dispose();
                hv_rotateCol.Dispose();
                hv_HomMat2DRotate.Dispose();
                hv_rotateAng.Dispose();
                hv_Area2.Dispose();
                hv_Row4.Dispose();
                hv_Column4.Dispose();
                hv_Indices3.Dispose();
                hv_WaferRow1.Dispose();
                hv_WaferCol1.Dispose();
                hv_WaferRow2.Dispose();
                hv_WaferRCol2.Dispose();
                hv_Area.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_OriginRow.Dispose();
                hv_OriginCol.Dispose();
                hv_Amp.Dispose();
                hv_RoiWidthLen2.Dispose();
                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_WaferOriginRow.Dispose();
                hv_WaferOriginCol.Dispose();
                hv_RU_row.Dispose();
                hv_RU_col.Dispose();
                hv_A1AngOut.Dispose();
                hv_MinDistance1.Dispose();
                hv_Row12.Dispose();
                hv_Column12.Dispose();
                hv_A1Row.Dispose();
                hv_A1Col.Dispose();
                hv_C1AngOut.Dispose();
                hv_C1Row.Dispose();
                hv_C1Col.Dispose();
                hv_RD_Row.Dispose();
                hv_RD_Col.Dispose();
                hv_A2AngOut.Dispose();
                hv_A2Row.Dispose();
                hv_A2Col.Dispose();
                hv_C2AngOut.Dispose();
                hv_C2Row.Dispose();
                hv_C2Col.Dispose();
                hv_L2.Dispose();
                hv_Sigma.Dispose();
                hv_bu1Row2.Dispose();
                hv_bu1Col2.Dispose();
                hv_bu1Row1.Dispose();
                hv_bu1Col1.Dispose();
                hv_bu1Row.Dispose();
                hv_bu1Col.Dispose();
                hv_bv1Row2.Dispose();
                hv_bv1Col2.Dispose();
                hv_bv1Row1.Dispose();
                hv_bv1Col1.Dispose();
                hv_bv1Row.Dispose();
                hv_bv1Col.Dispose();
                hv_bu2Row2.Dispose();
                hv_bu2Col2.Dispose();
                hv_bu2Row1.Dispose();
                hv_bu2Col1.Dispose();
                hv_bu2Row.Dispose();
                hv_bu2Col.Dispose();
                hv_bv2Row1.Dispose();
                hv_bv2Col1.Dispose();
                hv_bv2Row2.Dispose();
                hv_bv2Col2.Dispose();
                hv_bv2Row.Dispose();
                hv_bv2Col.Dispose();
                hv_B1Row.Dispose();
                hv_B1Col.Dispose();
                hv_IsOverlapping.Dispose();
                hv_B2Row.Dispose();
                hv_B2Col.Dispose();
                hv_Angle1.Dispose();
                hv_Angle2.Dispose();
                hv_Number.Dispose();
                hv_R_1.Dispose();
                hv_R_1CenterRow.Dispose();
                hv_R_1CenterCol.Dispose();
                hv_i.Dispose();
                hv_Attrib.Dispose();
                hv_Radius.Dispose();
                hv_StartPhi.Dispose();
                hv_EndPhi.Dispose();
                hv_PointOrder.Dispose();
                hv_R_2.Dispose();
                hv_R_2CenterRow.Dispose();
                hv_R_2CenterCol.Dispose();
                hv_Length.Dispose();
                hv_Line_Org.Dispose();
                hv_Line_Surface1.Dispose();
                hv_Line_Surface2.Dispose();
                hv_Line_Ang1.Dispose();
                hv_Line_Ang2.Dispose();
                hv_Line_A1.Dispose();
                hv_Line_A2.Dispose();
                hv_Line_B1.Dispose();
                hv_Line_B2.Dispose();
                hv_Line_R1.Dispose();
                hv_Line_R2.Dispose();
                hv_Line_C1.Dispose();
                hv_Line_C2.Dispose();
                hv_Lines.Dispose();
                hv_X1_idx.Dispose();
                hv_Y1_idx.Dispose();
                hv_X2_idx.Dispose();
                hv_Y2_idx.Dispose();
                hv_textA1.Dispose();
                hv_textA2.Dispose();
                hv_textB1.Dispose();
                hv_textB2.Dispose();
                hv_textBC.Dispose();
                hv_textC1.Dispose();
                hv_textC2.Dispose();
                hv_textR1.Dispose();
                hv_textR2.Dispose();
                hv_textt.Dispose();
                hv_textAng1.Dispose();
                hv_textAng2.Dispose();
                hv_texts.Dispose();
                hv_text_idx.Dispose();
                hv_textX_idx.Dispose();
                hv_textY_idx.Dispose();
                hv_S4.Dispose();
                hv_WindowHandle.Dispose();

                throw HDevExpDefaultException;
            }
        }




    }
}
