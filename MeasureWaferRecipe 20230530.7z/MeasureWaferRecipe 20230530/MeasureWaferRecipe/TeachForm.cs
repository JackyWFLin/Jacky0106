﻿using AOISystem.Halcon.Controls;
using HalconDotNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeasureWaferRecipe
{
    public partial class RecipeForm : Form
    {
        public RecipeForm()
        {
            InitializeComponent();
        }
       
        HObject EdgeImage;
        HObject NotchImage;

        //缺陷1
        HObject ho_NotchImage;
        HObject RawImage;
        HTuple ModelID;
        HTuple hv_EdgePntRows = null, hv_EdgePntCols;
        bool IsDefectFirstTest = false;
        HObject ho_CropImage, ho_CropImage_AI;
        bool IsCropOK = false;
        bool IsDomainFirst = false;
        private OpenFileDialog openFileDialog2 = new OpenFileDialog();

        private void nud_bu2Ratio_ValueChanged(object sender, EventArgs e)
        {
        }
        
       
        private void btn_LoadImage_Edge_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_EdgeImgPath.Text = openFileDialog2.FileName;
                if (txb_EdgeImgPath.Text == "")
                    return;
                HOperatorSet.ReadImage(out EdgeImage, txb_EdgeImgPath.Text);
                HOperatorSet.GetImageSize(EdgeImage, out HTuple width, out HTuple height);
                if(height>1440)
                {
                    txb_EdgeImgPath.Text = "";
                    MessageBox.Show("影像尺寸錯誤非面幅影像");
                    return;
                }
                    

                hctrl_EdgeView.ReadImage(EdgeImage);
                hctrl_EdgeView.ZoomToFit();
            }
        }

        private void btn_MasureTest_Edge_Click(object sender, EventArgs e)
        {
            if (txb_EdgeImgPath.Text == "")
            {
                MessageBox.Show("請先輸入圖片");
                return;
            }

            HTuple hv_PixelSize = 3.45;  //um
            double hv_rotateAngle = Convert.ToDouble(nud_EdgeRotateAngle.Value);
            double hv_GrayMax = Convert.ToDouble(nud_GrayMax.Value);
            double hv_RoiY1 = 221.418;
            double hv_RoiX1 = 227.161;
            double hv_RoiY2 = 913.062;
            double hv_RoiX2 = 1071.17;

            double hv_A1Ang = Convert.ToDouble(nud_AngleStart1.Value);
            double hv_A2Ang = Convert.ToDouble(nud_AngleStart2.Value);
            double hv_C1Ang = Convert.ToDouble(nud_AngleTop1.Value);
            double hv_C2Ang = Convert.ToDouble(nud_AngleTop2.Value);
            double hv_bu11 = Convert.ToDouble(nud_bu1Ratio.Value);
            double hv_bv11 = Convert.ToDouble(nud_bv1Ratio.Value);
            double hv_bu22 = Convert.ToDouble(nud_bu2Ratio.Value);
            double hv_bv22 = Convert.ToDouble(nud_bv2Ratio.Value);
            AlogrithmFunction.MeasureWaferEdgeB(EdgeImage, out HObject ho_ImageOut, hv_PixelSize,
                                     hv_rotateAngle, hv_GrayMax, hv_RoiY1, hv_RoiX1,
                                     hv_RoiY2, hv_RoiX2, hv_A1Ang, hv_A2Ang, hv_C1Ang,
                                     hv_C2Ang, hv_bu11, hv_bv11, hv_bu22, hv_bv22,
                                    out HTuple hv_A1, out HTuple hv_A2, out HTuple hv_B1, out HTuple hv_B2, out HTuple hv_BC,
                                    out HTuple hv_C1, out HTuple hv_C2, out HTuple hv_R1, out HTuple hv_R2, out HTuple hv_t,
                                    out HTuple hv_Ang1, out HTuple hv_Ang2, out HTuple hv_ErrorMsg, out HTuple hv_Phi_OrgX_OrgY,
                                    out HTuple hv_Cir_c1, out HTuple hv_Cir_c2, out HTuple hv_LinesX1, out HTuple hv_LinesY1,
                                    out HTuple hv_LinesX2, out HTuple hv_LinesY2, out HTuple hv_TextsText, out HTuple hv_TextsX,
                                    out HTuple hv_TextsY);

            if (hv_ErrorMsg.Length != 0 || hv_A2.Length == 0)
            {
                MessageBox.Show(hv_ErrorMsg);
                return;
            }
            hctrl_EdgeView.ReadImage(ho_ImageOut);
            hctrl_EdgeView.ZoomToFit();
            txb_A1.Text = "" + hv_A1;
            txb_A2.Text = "" + hv_A2;
            txb_B1.Text = "" + hv_B1;
            txb_B2.Text = "" + hv_B2;
            txb_R1.Text = "" + hv_R1;
            txb_R2.Text = "" + hv_R2;
            txb_t.Text = "" + hv_t;
            txb_Ang1.Text = "" + hv_Ang1;
            txb_Ang2.Text = "" + hv_Ang2;
            txb_BC.Text = "" + hv_BC;
            txb_C1.Text = "" + hv_C1;
            txb_C2.Text = "" + hv_C2;
        }
       
        private void btn_LoadImage_Notch_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_NotchImgPath.Text = openFileDialog2.FileName;
                if (txb_NotchImgPath.Text == "")
                    return;
                HOperatorSet.ReadImage(out NotchImage, txb_NotchImgPath.Text);
                hctrl_NotchView.ReadImage(NotchImage);
                hctrl_NotchView.ZoomToFit();
            }
        }

        private void btn_MasureTest_Notch_Click(object sender, EventArgs e)
        {
            HTuple hv_PixelSize = 7.04;//um
            int hv_Rotate =Convert.ToInt32( nud_NotchRotate.Value);
            HTuple hv_Resize = 1.11;
            int hv_GrayMin = Convert.ToInt32(nud_NotchGrayMax.Value);
            double hv_b1Ang=Convert.ToDouble(nud_b1Ang.Value);
            double hv_b2Ang = Convert.ToDouble(nud_b2Ang.Value);
            double hv_u1 = Convert.ToDouble(nud_u1Ratio.Value);
            double hv_u2 = Convert.ToDouble(nud_u2Ratio.Value);
            double hv_RWidth1 = Convert.ToDouble(nud_VrWidth1.Value);
            double hv_RWidth2 = Convert.ToDouble(nud_VrWidth2.Value);
            double hv_PinR = Convert.ToDouble(nud_PinRadius.Value);
            double hv_VRAng = Convert.ToDouble(nud_VR12Angle.Value);
            if(txb_NotchImgPath.Text=="")
            {
                MessageBox.Show("請輸入圖片再進測試");
                return;

            }

            AlogrithmFunction.MeasureNotch(NotchImage, out HObject ho_ResultImage, hv_PixelSize,
                        hv_Rotate, hv_Resize, hv_GrayMin, hv_b1Ang, hv_b2Ang,
                        hv_u1, hv_u2, hv_RWidth1, hv_RWidth2, hv_PinR,
                        hv_VRAng, out HTuple hv_Vh, out HTuple hv_Vw, out HTuple hv_Vr, out HTuple hv_P1,
                       out HTuple hv_P2, out HTuple hv_AngV, out HTuple hv_VR1, out HTuple hv_VR2,
                       out HTuple hv_ErrorMsg);
            txb_Vh.Text = "" + hv_Vh;
            txb_Vw.Text = "" + hv_Vw;
            txb_Vr.Text = "" + hv_Vr;
            txb_AngV.Text = "" + hv_P1;
            txb_P1.Text = "" + hv_P2;
            txb_P2.Text = "" + hv_AngV;
            txb_VR1.Text = "" + hv_VR1;
            txb_VR2.Text = "" + hv_VR2;
            hctrl_NotchView.ReadImage(ho_ResultImage);
            hctrl_NotchView.ZoomToFit();
        }
        
        private void btn_LoadImage_Defect_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_ImageRaw_1.Text = openFileDialog2.FileName;
                if (txb_ImageRaw_1.Text == "")
                    return;
                HOperatorSet.ReadImage(out RawImage, txb_ImageRaw_1.Text);
                hctrl_RawImage_1.ReadImage(RawImage);
                hctrl_RawImage_1.ZoomToFit();
            }
        }



        private void btn_TestCropNotch_Click(object sender, EventArgs e)

        {
            IsCropOK = false;
            IsDomainFirst = false;
            IsDefectFirstTest = false;

            string ModelPath = txb_model_1.Text;
            string[] sArray = ModelPath.Split('.');

            if (txb_model_1.Text=="" || sArray [sArray.Length-1] != "shm")
            {
                MessageBox.Show("Model檔案錯誤");
                return;
            }

            if (txb_ImageRaw_1.Text == "" )
            {
                MessageBox.Show("請輸入影像");
                return;
            }

            double hv_CropNotchWidth = Convert.ToDouble(nud_CropNotchWidth_1.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_1.Value);
            double hv_PixelSize = Convert.ToDouble(nud_PixelSize_1.Value);
            double hv_CropSize = Convert.ToDouble(nud_CropSize_1.Value);
            double hv_MinScore = Convert.ToDouble(nud_MinScore_1.Value);
            AlogrithmFunction.CalculateEdgePntAndCropNotch(RawImage, out ho_NotchImage,
                         ModelID, hv_CropNotchWidth, hv_InDistance, hv_PixelSize,
                         hv_CropSize, hv_MinScore, out  hv_EdgePntRows, out  hv_EdgePntCols,
                        out HTuple hv_ErrMsg);

            if (hv_ErrMsg.Length != 0)
            {
                MessageBox.Show(hv_ErrMsg + "請調整參數");
                return;
            }
            else
            {
                hctrl_NotchImg_1.ReadImage(ho_NotchImage);
                hctrl_NotchImg_1.ZoomToFit();
                int number=hv_EdgePntRows.Length;
                lab_dispNumber_1.Text = "全部共有 "+ number + " 張";
                nud_SelectCropImg_1.Maximum = number;
                IsCropOK = true;  //裁切成功
            }


        }
       
        private void btn_TestDefect_Click(object sender, EventArgs e)
        {
            if(IsDefectFirstTest!= false)
            {
                btn_CropInspectionImg_Click(sender, e);
            }
            else
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            IsDefectFirstTest = true;

            double hv_RoiWidthToBevelCenter =  Convert.ToDouble(nud_RoiWidthToBevelCenter_1.Value); 
             double hv_BevelWidth = Convert.ToDouble(nud_BevelWidth_1.Value);
             double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_1.Value);
            double hv_AiDefectSize = Convert.ToDouble(nud_AiDefectSize_1.Value);
            double hv_AiMinGray = Convert.ToDouble(nud_AiMinGray_1.Value);
            double hv_InnerDefectAreaSize = Convert.ToDouble(nud_InnerDefectAreaSize_1.Value);
            double hv_InnerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_1.Value);


            AlogrithmFunction.InspectWaferEdgeDefectAndDrawAi( ho_CropImage, ho_CropImage_AI,
                        out HObject ho_ImageOut, hv_RoiWidthToBevelCenter, hv_BevelWidth,
                          hv_DisplayDilation, hv_DisplayDilation, hv_AiDefectSize,
                          hv_AiMinGray, hv_InnerDefectAreaSize, hv_InnerDefectMaxGray,
                        out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
                        out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber);
            hctrl_DefectImg_1.ReadImage(ho_ImageOut);
            hctrl_DefectImg_1.ZoomToFit();
        }
        private void btn_CropInspectionImg_Click(object sender, EventArgs e)
        {
            IsDomainFirst = true;
            IsDefectFirstTest = false;
            if (IsCropOK != true)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_PixelSize = 7.04;//um
            double hv_CropSize = Convert.ToDouble(nud_CropSize_1.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_1.Value);
            int N = Convert.ToInt32(nud_SelectCropImg_1.Value);
            double hv_EdgePntRow = hv_EdgePntRows[N - 1];
            double hv_EdgePntCol = hv_EdgePntCols[N - 1];
            double hv_AI_OutDrawStartX = 166; //Ai開始判定的位置，目前沒用到
            AlogrithmFunction.CropDomainImage(RawImage, out ho_CropImage, out ho_CropImage_AI,
                         hv_PixelSize, hv_CropSize, hv_InDistance, hv_EdgePntRow,
                         hv_EdgePntCol, hv_AI_OutDrawStartX);

            hctrl_DefectImg_1.ReadImage(ho_CropImage);
            hctrl_DefectImg_1.ZoomToFit();
            IsDefectFirstTest = true;
            nud_SelectCropImg_1.Value += 1;

        }

        private void hctrl_NotchImg_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Link;
            else e.Effect = DragDropEffects.None;
        }

        private void hctrl_NotchImg_DragDrop(object sender, DragEventArgs e)
        {
            //其中label1.Text顯示的就是拖進檔案的檔名； 
            string Path = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            string[] ImageData = Path.Split('.');
            int N = ImageData.Length;
            string filename = ImageData[N - 1];

            if (filename == "png" || filename == "bmp" || filename == "jpg" || filename == "jpeg" || filename == "gif" || filename == "tiff")
            {
                HOperatorSet.ReadImage(out  ho_NotchImage, Path);
                hctrl_NotchImg_1.ReadImage(ho_NotchImage);
                hctrl_NotchImg_1.ResetAllHDispObject();
                hctrl_NotchImg_1.ZoomToFit();

            }
            else
            {

                MessageBox.Show("檔案錯誤，請輸入圖片檔");
                return;
            }
        }

        private void btn_loadModel_1_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "* |*.shm";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_model_1.Text = openFileDialog2.FileName;
                if (txb_model_1.Text == "")
                    return;

                HOperatorSet.ReadShapeModel(txb_model_1.Text, out ModelID);

            }
        }
        //缺陷1
        HObject ho_NotchImage2;
        HObject RawImage2;
        HTuple ModelID2;
        HTuple hv_EdgePntRows2 = null, hv_EdgePntCols2;
        bool IsDefectFirstTest2 = false;
        HObject ho_CropImage2, ho_CropImage_AI2;
        bool IsCropOK2 = false;
        bool IsDomainFirst2 = false;
        private void btn_LoadImage_Defect_2_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "Image |*.png;*.bmp;*.jpeg;*.jpg;*.gif ;*.tiff";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_ImageRaw_2.Text = openFileDialog2.FileName;
                if (txb_ImageRaw_2.Text == "")
                    return;
                HOperatorSet.ReadImage(out RawImage2, txb_ImageRaw_2.Text);
                hctrl_RawImage_2.ReadImage(RawImage2);
                hctrl_RawImage_2.ZoomToFit();
            }
        }

        private void btn_loadModel_2_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "* |*.shm";

            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txb_model_2.Text = openFileDialog2.FileName;
                if (txb_model_2.Text == "")
                    return;

                HOperatorSet.ReadShapeModel(txb_model_2.Text, out ModelID2);

            }
        }

        private void btn_TestCropNotch_2_Click(object sender, EventArgs e)
        {
            IsCropOK2 = false;
            IsDomainFirst2 = false;
            IsDefectFirstTest2 = false;

            string ModelPath = txb_model_2.Text;
            string[] sArray = ModelPath.Split('.');

            if (txb_model_2.Text == "" || sArray[sArray.Length - 1] != "shm")
            {
                MessageBox.Show("Model檔案錯誤");
                return;
            }

            if (txb_ImageRaw_2.Text == "")
            {
                MessageBox.Show("請輸入影像");
                return;
            }

            double hv_CropNotchWidth = Convert.ToDouble(nud_CropNotchWidth_2.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_2.Value);
            double hv_PixelSize = Convert.ToDouble(nud_PixelSize_2.Value);
            double hv_CropSize = Convert.ToDouble(nud_CropSize_2.Value);
            double hv_MinScore = Convert.ToDouble(nud_MinScore_2.Value);
            AlogrithmFunction.CalculateEdgePntAndCropNotch(RawImage2, out ho_NotchImage2,
                         ModelID2, hv_CropNotchWidth, hv_InDistance, hv_PixelSize,
                         hv_CropSize, hv_MinScore, out hv_EdgePntRows2, out hv_EdgePntCols2,
                        out HTuple hv_ErrMsg2);

            if (hv_ErrMsg2.Length != 0)
            {
                MessageBox.Show(hv_ErrMsg2 + "請調整參數");
                return;
            }
            else
            {
                hctrl_NotchImg_2.ReadImage(ho_NotchImage2);
                hctrl_NotchImg_2.ZoomToFit();
                int number2 = hv_EdgePntRows2.Length;
                lab_dispNumber_2.Text = "全部共有 " + number2 + " 張";
                nud_SelectCropImg_2.Maximum = number2;
                IsCropOK2 = true;  //裁切成功
            }

        }

        private void btn_CropInspectionImg_2_Click(object sender, EventArgs e)
        {
            IsDomainFirst2 = true;
            IsDefectFirstTest2 = false;
            if (IsCropOK2 != true)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_PixelSize = 7.04;//um
            double hv_CropSize = Convert.ToDouble(nud_CropSize_2.Value);
            double hv_InDistance = Convert.ToDouble(nud_InDistance_2.Value);
            int N = Convert.ToInt32(nud_SelectCropImg_2.Value);
            double hv_EdgePntRow = hv_EdgePntRows2[N - 1];
            double hv_EdgePntCol = hv_EdgePntCols2[N - 1];
            double hv_AI_OutDrawStartX = 166; //Ai開始判定的位置，目前沒用到
            AlogrithmFunction.CropDomainImage(RawImage2, out ho_CropImage2, out ho_CropImage_AI2,
                         hv_PixelSize, hv_CropSize, hv_InDistance, hv_EdgePntRow,
                         hv_EdgePntCol, hv_AI_OutDrawStartX);

            hctrl_DefectImg_2.ReadImage(ho_CropImage2);
            hctrl_DefectImg_2.ZoomToFit();
            IsDefectFirstTest2 = true;
            if(nud_SelectCropImg_2.Value+1 <  nud_SelectCropImg_2.Maximum)
            nud_SelectCropImg_2.Value += 1;
        }

        private void btn_TestDefect_2_Click(object sender, EventArgs e)
        {
            if (IsDefectFirstTest2 != false)
            {
                btn_CropInspectionImg_2_Click(sender, e);
            }
            else
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            IsDefectFirstTest2 = true;

            double hv_RoiWidthToBevelCenter = Convert.ToDouble(nud_RoiWidthToBevelCenter_2.Value);
            double hv_BevelWidth = Convert.ToDouble(nud_BevelWidth_2.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_2.Value);
            double hv_AiDefectSize = Convert.ToDouble(nud_AiDefectSize_2.Value);
            double hv_AiMinGray = Convert.ToDouble(nud_AiMinGray_2.Value);
            double hv_InnerDefectAreaSize = Convert.ToDouble(nud_InnerDefectAreaSize_2.Value);
            double hv_InnerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_2.Value);


            AlogrithmFunction.InspectWaferEdgeDefectAndDrawAi(ho_CropImage2, ho_CropImage_AI2,
                        out HObject ho_ImageOut2, hv_RoiWidthToBevelCenter, hv_BevelWidth,
                          hv_DisplayDilation, hv_DisplayDilation, hv_AiDefectSize,
                          hv_AiMinGray, hv_InnerDefectAreaSize, hv_InnerDefectMaxGray,
                        out HTuple hv_AoiDefectNumber, out HTuple hv_DefectRow1, out HTuple hv_DefectCol1,
                        out HTuple hv_DefectRow2, out HTuple hv_DefectCol2, out HTuple hv_AiDefectNumber);
            hctrl_DefectImg_2.ReadImage(ho_ImageOut2);
            hctrl_DefectImg_2.ZoomToFit();
        }

        private void btn_TestNotchDefect_2_Click(object sender, EventArgs e)
        {
            if (IsCropOK2 == false)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_BackWhiteMinGray = Convert.ToDouble(nud_BackWhiteMinGray_2.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_2.Value);
            double hv_innerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_Notch_2.Value);
            double hv_NotchVwRow1 = Convert.ToDouble(nud_NotchVwRow1_2.Value);
            double hv_NotchVwRow2 = Convert.ToDouble(nud_NotchVwRow2_2.Value);
            double hv_NotchBlackWidth = Convert.ToDouble(nud_NotchBlackWidth_2.Value);
            double hv_InnerDefectMinWidth = Convert.ToDouble(nud_InnerDefectMinWidth_2.Value);
            double hv_OutDefectMinWidth = Convert.ToDouble(nud_OutDefectMinWidth_2.Value);

            AlogrithmFunction.InspectNotchDefect_v2(ho_NotchImage2, out HObject ho_ImageOut2, out HObject ho_ImageOut_Teach2,
          out HObject ho_Teach_Contour2, hv_BackWhiteMinGray, hv_DisplayDilation,
           hv_innerDefectMaxGray, hv_NotchVwRow1, hv_NotchVwRow2,
           hv_NotchBlackWidth, hv_InnerDefectMinWidth, hv_OutDefectMinWidth,
          out HTuple hv_DefectNumber);
            hctrl_NotchImg_2.ReadImage(ho_ImageOut2);
            hctrl_NotchImg_2.ResetAllHXLDInfo();
            hctrl_NotchImg_2.AddHXLD(HColorMode.green, ho_Teach_Contour2);
            //hCtrl_Model.ZoomToFit();
            hctrl_NotchImg_2.ZoomToFit();
        }

        private void btn_TestNotchDefect_Click(object sender, EventArgs e)
        {
            if (IsCropOK == false)
            {
                MessageBox.Show("請完成前步驟");
                return;
            }
            double hv_BackWhiteMinGray = Convert.ToDouble(nud_BackWhiteMinGray_1.Value);
            double hv_DisplayDilation = Convert.ToDouble(nud_DisplayDilation_1.Value);
            double hv_innerDefectMaxGray = Convert.ToDouble(nud_innerDefectMaxGray_Notch_1.Value);
            double hv_NotchVwRow1 = Convert.ToDouble(nud_NotchVwRow1_1.Value);
            double hv_NotchVwRow2 = Convert.ToDouble(nud_NotchVwRow2_1.Value);
            double hv_NotchBlackWidth = Convert.ToDouble(nud_NotchBlackWidth_1.Value);
            double hv_InnerDefectMinWidth = Convert.ToDouble(nud_InnerDefectMinWidth_1.Value);
            double hv_OutDefectMinWidth = Convert.ToDouble(nud_OutDefectMinWidth_1.Value);
            
            AlogrithmFunction.InspectNotchDefect_v2(ho_NotchImage, out HObject ho_ImageOut, out HObject ho_ImageOut_Teach,
          out HObject ho_Teach_Contour, hv_BackWhiteMinGray, hv_DisplayDilation,
           hv_innerDefectMaxGray, hv_NotchVwRow1, hv_NotchVwRow2,
           hv_NotchBlackWidth, hv_InnerDefectMinWidth, hv_OutDefectMinWidth,
          out HTuple hv_DefectNumber);
            hctrl_NotchImg_1.ReadImage(ho_ImageOut);
            hctrl_NotchImg_1.ResetAllHXLDInfo();
            hctrl_NotchImg_1.AddHXLD(HColorMode.green, ho_Teach_Contour);
            //hCtrl_Model.ZoomToFit();
            hctrl_NotchImg_1.ZoomToFit();


        }

       
    }
    }

