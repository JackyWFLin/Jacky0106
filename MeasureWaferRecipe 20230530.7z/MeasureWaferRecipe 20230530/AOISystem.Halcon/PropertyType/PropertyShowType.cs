﻿using System;
using System.Linq;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using HalconDotNet;

namespace AOISystem.Halcon.PropertyType
{
    public class HTupleTypeConverter : ExpandableObjectConverter
    {
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(HTuple))
                return true;
           
            return base.CanConvertTo(context, destinationType);
        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == typeof(String) && value is HTuple)
            {
                return value.ToString();
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }
        //(選擇性) 您可以指定型別轉換器可以從字串轉換，以便在文字方塊中編輯物件的字串
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
                return true;

            return base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            try
            {
                if (value is string)
                {
                    PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(context.Instance);
                    foreach (PropertyDescriptor property in properties)
                    {
                        if (property.PropertyType == typeof(HTuple))
                        {
                            if (context.PropertyDescriptor.Name.Equals(property.Name))
                            {
                                return HTupleStringTypeConverter(value.ToString());
                            }
                        }
                    }
                }
                return base.ConvertFrom(context, culture, value);
            }
            catch
            {
                throw new ArgumentException("無法將 '" + (string)value + "' 轉換為 HTuple 型別");
            }
        }

        public static HTuple HTupleStringTypeConverter(string hTuplValue)
        {
            if (hTuplValue.Contains(';'))
            {
                string[] hTuplValues = hTuplValue.Split(';');
                HTuple[] hTuplObjects = new HTuple[hTuplValues.Length];
                for (int i = 0; i < hTuplValues.Length; i++)
                {
                    hTuplObjects[i] = HTupleStringTypeConverter(hTuplValues[i].Trim());
                }
                return new HTuple(hTuplObjects);
            }
            else
            {
                int intValue;
                if (int.TryParse(hTuplValue, out intValue))
                {
                    return intValue;
                }
                long longValue;
                if (long.TryParse(hTuplValue, out longValue))
                {
                    return longValue;
                }
                double doubleValue;
                if (double.TryParse(hTuplValue, out doubleValue))
                {
                    return doubleValue;
                }
                return hTuplValue;
            }
        }
    }
}
