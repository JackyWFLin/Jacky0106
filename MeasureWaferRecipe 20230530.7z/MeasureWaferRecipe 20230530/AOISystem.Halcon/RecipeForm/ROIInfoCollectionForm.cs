﻿using System;
using System.Windows.Forms;
using AOISystem.Halcon.Recipe;
using AOISystem.Halcon.ROI;

namespace AOISystem.Halcon.RecipeForm
{
    public partial class ROIInfoCollectionForm : Form
    {
        public ROIInfoCollectionForm()
        {
            InitializeComponent();
        }

        private ROIController _rOIController;
        public ROIController ROIController
        {
            get
            {
                return _rOIController;
            }
            set
            {
                _rOIController = value;
            }
        }

        public void RefreshData()
        {
            ROIInfoCollection rOIInfoCollection = new ROIInfoCollection();
            foreach (ROIBase roi in ROIController.ROIList)
            {
                rOIInfoCollection.Add(roi.ROIInfo);
            }
            this.dataGridView.DataSource = rOIInfoCollection;
        }

        private void tspbtnRefresh_Click(object sender, EventArgs e)
        {
            RefreshData();
        }
    }
}
