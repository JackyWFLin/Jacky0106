﻿namespace AOISystem.Halcon.RecipeForm
{
    partial class ROIInfoCollectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ROIInfoCollectionForm));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tspbtnRefresh = new System.Windows.Forms.ToolStripButton();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.indexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inspectIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inspectNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regionTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.widthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.angleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radiusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activeColorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activeHColorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inActiveColorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processIndexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processDoneDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rOIBaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testScore = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.testOverlap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rOIBaseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.toolStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(884, 262);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tspbtnRefresh});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(884, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tspbtnRefresh
            // 
            this.tspbtnRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tspbtnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("tspbtnRefresh.Image")));
            this.tspbtnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tspbtnRefresh.Name = "tspbtnRefresh";
            this.tspbtnRefresh.Size = new System.Drawing.Size(54, 22);
            this.tspbtnRefresh.Text = "Refresh";
            this.tspbtnRefresh.Click += new System.EventHandler(this.tspbtnRefresh_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.indexDataGridViewTextBoxColumn,
            this.inspectIdDataGridViewTextBoxColumn,
            this.inspectNameDataGridViewTextBoxColumn,
            this.regionTypeDataGridViewTextBoxColumn,
            this.xDataGridViewTextBoxColumn,
            this.yDataGridViewTextBoxColumn,
            this.widthDataGridViewTextBoxColumn,
            this.heightDataGridViewTextBoxColumn,
            this.angleDataGridViewTextBoxColumn,
            this.radiusDataGridViewTextBoxColumn,
            this.activeColorDataGridViewTextBoxColumn,
            this.activeHColorDataGridViewTextBoxColumn,
            this.inActiveColorDataGridViewTextBoxColumn,
            this.processIndexDataGridViewTextBoxColumn,
            this.processDoneDataGridViewCheckBoxColumn,
            this.testScore,
            this.testOverlap});
            this.dataGridView.DataSource = this.rOIBaseBindingSource;
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Location = new System.Drawing.Point(3, 28);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(878, 231);
            this.dataGridView.TabIndex = 1;
            // 
            // indexDataGridViewTextBoxColumn
            // 
            this.indexDataGridViewTextBoxColumn.DataPropertyName = "Index";
            this.indexDataGridViewTextBoxColumn.HeaderText = "Index";
            this.indexDataGridViewTextBoxColumn.Name = "indexDataGridViewTextBoxColumn";
            // 
            // inspectIdDataGridViewTextBoxColumn
            // 
            this.inspectIdDataGridViewTextBoxColumn.DataPropertyName = "InspectId";
            this.inspectIdDataGridViewTextBoxColumn.HeaderText = "InspectId";
            this.inspectIdDataGridViewTextBoxColumn.Name = "inspectIdDataGridViewTextBoxColumn";
            // 
            // inspectNameDataGridViewTextBoxColumn
            // 
            this.inspectNameDataGridViewTextBoxColumn.DataPropertyName = "InspectName";
            this.inspectNameDataGridViewTextBoxColumn.HeaderText = "InspectName";
            this.inspectNameDataGridViewTextBoxColumn.Name = "inspectNameDataGridViewTextBoxColumn";
            // 
            // regionTypeDataGridViewTextBoxColumn
            // 
            this.regionTypeDataGridViewTextBoxColumn.DataPropertyName = "RegionType";
            this.regionTypeDataGridViewTextBoxColumn.HeaderText = "RegionType";
            this.regionTypeDataGridViewTextBoxColumn.Name = "regionTypeDataGridViewTextBoxColumn";
            // 
            // xDataGridViewTextBoxColumn
            // 
            this.xDataGridViewTextBoxColumn.DataPropertyName = "X";
            this.xDataGridViewTextBoxColumn.HeaderText = "X";
            this.xDataGridViewTextBoxColumn.Name = "xDataGridViewTextBoxColumn";
            // 
            // yDataGridViewTextBoxColumn
            // 
            this.yDataGridViewTextBoxColumn.DataPropertyName = "Y";
            this.yDataGridViewTextBoxColumn.HeaderText = "Y";
            this.yDataGridViewTextBoxColumn.Name = "yDataGridViewTextBoxColumn";
            // 
            // widthDataGridViewTextBoxColumn
            // 
            this.widthDataGridViewTextBoxColumn.DataPropertyName = "Width";
            this.widthDataGridViewTextBoxColumn.HeaderText = "Width";
            this.widthDataGridViewTextBoxColumn.Name = "widthDataGridViewTextBoxColumn";
            // 
            // heightDataGridViewTextBoxColumn
            // 
            this.heightDataGridViewTextBoxColumn.DataPropertyName = "Height";
            this.heightDataGridViewTextBoxColumn.HeaderText = "Height";
            this.heightDataGridViewTextBoxColumn.Name = "heightDataGridViewTextBoxColumn";
            // 
            // angleDataGridViewTextBoxColumn
            // 
            this.angleDataGridViewTextBoxColumn.DataPropertyName = "Angle";
            this.angleDataGridViewTextBoxColumn.HeaderText = "Angle";
            this.angleDataGridViewTextBoxColumn.Name = "angleDataGridViewTextBoxColumn";
            // 
            // radiusDataGridViewTextBoxColumn
            // 
            this.radiusDataGridViewTextBoxColumn.DataPropertyName = "Radius";
            this.radiusDataGridViewTextBoxColumn.HeaderText = "Radius";
            this.radiusDataGridViewTextBoxColumn.Name = "radiusDataGridViewTextBoxColumn";
            // 
            // activeColorDataGridViewTextBoxColumn
            // 
            this.activeColorDataGridViewTextBoxColumn.DataPropertyName = "ActiveColor";
            this.activeColorDataGridViewTextBoxColumn.HeaderText = "ActiveColor";
            this.activeColorDataGridViewTextBoxColumn.Name = "activeColorDataGridViewTextBoxColumn";
            // 
            // activeHColorDataGridViewTextBoxColumn
            // 
            this.activeHColorDataGridViewTextBoxColumn.DataPropertyName = "ActiveHColor";
            this.activeHColorDataGridViewTextBoxColumn.HeaderText = "ActiveHColor";
            this.activeHColorDataGridViewTextBoxColumn.Name = "activeHColorDataGridViewTextBoxColumn";
            // 
            // inActiveColorDataGridViewTextBoxColumn
            // 
            this.inActiveColorDataGridViewTextBoxColumn.DataPropertyName = "InActiveColor";
            this.inActiveColorDataGridViewTextBoxColumn.HeaderText = "InActiveColor";
            this.inActiveColorDataGridViewTextBoxColumn.Name = "inActiveColorDataGridViewTextBoxColumn";
            // 
            // processIndexDataGridViewTextBoxColumn
            // 
            this.processIndexDataGridViewTextBoxColumn.DataPropertyName = "ProcessIndex";
            this.processIndexDataGridViewTextBoxColumn.HeaderText = "ProcessIndex";
            this.processIndexDataGridViewTextBoxColumn.Name = "processIndexDataGridViewTextBoxColumn";
            // 
            // processDoneDataGridViewCheckBoxColumn
            // 
            this.processDoneDataGridViewCheckBoxColumn.DataPropertyName = "ProcessDone";
            this.processDoneDataGridViewCheckBoxColumn.HeaderText = "ProcessDone";
            this.processDoneDataGridViewCheckBoxColumn.Name = "processDoneDataGridViewCheckBoxColumn";
            // 
            // rOIBaseBindingSource
            // 
            this.rOIBaseBindingSource.DataSource = typeof(AOISystem.Halcon.Recipe.ROIInfo);
            // 
            // testScore
            // 
            this.testScore.DataPropertyName = "testScore";
            this.testScore.HeaderText = "testScore";
            this.testScore.Name = "testScore";
            // 
            // testOverlap
            // 
            this.testOverlap.DataPropertyName = "testOverlap";
            this.testOverlap.HeaderText = "testOverlap";
            this.testOverlap.Name = "testOverlap";
            // 
            // ROIInfoCollectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 262);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ROIInfoCollectionForm";
            this.Text = "ROIInfoCollectionForm";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rOIBaseBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tspbtnRefresh;
        private System.Windows.Forms.BindingSource rOIBaseBindingSource;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn indexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inspectIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inspectNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regionTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn xDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn widthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn angleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn radiusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activeColorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activeHColorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inActiveColorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processIndexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn processDoneDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn testScore;
        private System.Windows.Forms.DataGridViewTextBoxColumn testOverlap;

    }
}