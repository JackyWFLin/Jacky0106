﻿using System;
using System.Windows.Forms;
using AOISystem.Halcon.Recipe;

namespace AOISystem.Halcon.RecipeForm
{
    public partial class CopyRecipeForm : Form
    {
        private RecipeInfo _recipe;

        public CopyRecipeForm()
        {
            InitializeComponent();
        }

        public CopyRecipeForm(RecipeInfo srcRecipeInfo, RecipeInfo destRecipeInfo)
        {
            InitializeComponent();

            _recipe = destRecipeInfo;
            this.txtOldRecipeNo.Text = srcRecipeInfo.RecipeNo.ToString();
            this.txtOldRecipeID.Text = srcRecipeInfo.RecipeID;
            this.txtOldDescription.Text = srcRecipeInfo.Description;
            this.txtNewDescription.Text = srcRecipeInfo.Description;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            _recipe.RecipeNo = int.Parse(this.txtNewRecipeNo.Text);
            _recipe.RecipeID = this.txtNewRecipeID.Text;
            _recipe.Description = this.txtNewDescription.Text;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CopyRecipeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
