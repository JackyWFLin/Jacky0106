﻿using System.Windows.Forms;

namespace AOISystem.Halcon.Controls
{
    /// <summary>
    /// HControl Mouse Double Click Handler
    /// </summary>
    public delegate void HMouseDoubleClickEventHandler(object sender, MouseEventArgs e);
}
