﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOISystem.Halcon.Controls
{
    public class HImageFormat
    {
        //Filter Index = 1
        public static string AllFormat = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}", "All Images|*.jpg;*.jpeg;*.bmp;*.png;*.tif;*.tiff;*.gif", JPEG, BMP, PNG, TIFF, GIF, "All Files|*.*");
        //Filter Index = 2
        public const string BMP = "BMP(*.bmp)|*.bmp";
        //Filter Index = 3
        public const string JPEG = "JPEG(*.jpg;*.jpeg)|*.jpg;*.jpeg";
        //Filter Index = 4
        public const string PNG = "PNG(*.png)|*.png";
        //Filter Index = 5
        public const string TIFF = "TIFF(*.tif;*.tiff)|*.tif;*.tiff";
        //Filter Index = 6
        public const string GIF = "GIF(*.gif)|*.gif";
    }
}
