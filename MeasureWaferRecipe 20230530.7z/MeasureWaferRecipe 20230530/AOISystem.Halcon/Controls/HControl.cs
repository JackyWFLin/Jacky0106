﻿#region - using -
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows.Forms;
using AOISystem.Halcon.HAlgorithm;
using AOISystem.Halcon.Recipe;
using AOISystem.Halcon.RecipeForm;
using AOISystem.Halcon.ROI;
using HalconDotNet;
using System.Threading.Tasks;
#endregion - using -

namespace AOISystem.Halcon.Controls
{
    public partial class HControl : UserControl
    {
        #region - Private Properties -
        private SynchronizationContext _context;

        private bool m_MousePressed;    //Mouse程序旗標

        private PointF _mouseDown; //滑鼠定位點
        private PointF _mousePosNow = new PointF(); //滑鼠目前位置
        private PointF _viewPort;  //Image 定位點

        private int _borderWidth = 0;  //框寬

        private HObject m_HRegion;  //Region暫存
        private List<HRegionInfo> _hRegionInfoList;    //Region暫存列表
        private List<HXLDInfo> _hXLDInfoList;    //XLD暫存列表
        private List<HStringInfo> _hStringInfoList;    //String暫存列表
        private List<HMessageInfo> _hMessageInfoList;    //Message暫存列表

        private ContextMenuStrip htextMenuStrip = new ContextMenuStrip();
        private ToolStripMenuItem SaveImagetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        private ToolStripMenuItem RemovetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        private ToolStripMenuItem TestModeltoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        private ToolStripMenuItem ModeltoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        private ToolStripMenuItem ROIInfotoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();

        private int activeROIIndexR;
        private bool _isCreatingROI;
        private ROIInfo _roiInfo;

        private PropertyForm _propertyForm;

        private static readonly object _keyObj = new object();
        #endregion - Private Properties -

        #region - Public Constructor -
        /// <summary>
        /// Constructor
        /// </summary>
        public HControl()
        {
            InitializeComponent();
            _context = SynchronizationContext.Current;
            _imageBuffer = new ImageBuffer();
            UseROIController();
            InitializeValue();
            InitializeMenu();
            string processName = Process.GetCurrentProcess().ProcessName;
            if (processName == "devenv" || processName == "VCSExpress")
            {
                return;
            }
            CreateWindow();
            ResetViewPort();
            base.Resize += new EventHandler(HControl_Resize);
            this.MouseUp += new MouseEventHandler(HControl_MouseUp);
            this.MouseDown += new MouseEventHandler(HControl_MouseDown);
            this.MouseMove += new MouseEventHandler(HControl_MouseMove);
            _hRegionInfoList = new List<HRegionInfo>();
            _hXLDInfoList = new List<HXLDInfo>();
            _hStringInfoList = new List<HStringInfo>();
            _hMessageInfoList = new List<HMessageInfo>();
        }

        public new void Dispose()
        {
            ResetAllHDispObject();
            if (this.ImageBuffer != null)
            {
                this.ImageBuffer.Dispose();
            }
            DisposeHWindow();
        }

        #endregion - Public Constructor -

        #region - SetParameters -
        private void InitializeValue()
        {
            activeROIIndexR = -1;
            _borderWidth = 0;
            m_MousePressed = false;
            this.Zoom = 1.0f;
            this.BackColor = System.Drawing.Color.Black;
            this.IsDispROIFrameFontInfo = true;
            this.IsDispCenterCross = true;
            this.IsDispHObject = true;
            this.IsUseMenuByMouseRightButton = true;
            this.FontSizeThreshold = 8;
            this.MaxZoom = 100.0f;
            this.MinZoom = 0.01f;
            this.ROIFontZoomMode = FontZoomMode.Constant;
            this.ROIFontSize = 18;
            this.ROIFontSizeThreshold = 10;
            this.KeyCtrlPressStatus = false;
            this.IsLockMouseOperation = false;
            this.ScrollBarEnable = true;
        }

        private void InitializeMenu()
        {
            this.htextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveImagetoolStripMenuItem,
            this.RemovetoolStripMenuItem,
            this.TestModeltoolStripMenuItem,
            this.ModeltoolStripMenuItem,
            this.ROIInfotoolStripMenuItem
            });
            this.SaveImagetoolStripMenuItem.Name = "SaveImagetoolStripMenuItem";
            this.SaveImagetoolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.SaveImagetoolStripMenuItem.Text = "儲圖";
            this.RemovetoolStripMenuItem.Name = "RemovetoolStripMenuItem";
            this.RemovetoolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.RemovetoolStripMenuItem.Text = "刪框";
            this.TestModeltoolStripMenuItem.Name = "TestModeltoolStripMenuItem";
            this.TestModeltoolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.TestModeltoolStripMenuItem.Text = "測試Model";
            this.ModeltoolStripMenuItem.Name = "ModeltoolStripMenuItem";
            this.ModeltoolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.ModeltoolStripMenuItem.Text = "建立Model";
            this.ROIInfotoolStripMenuItem.Name = "ROIInfotoolStripMenuItem";
            this.ROIInfotoolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.ROIInfotoolStripMenuItem.Text = "ROI Info";

            this.SaveImagetoolStripMenuItem.Click += new System.EventHandler(this.MenuItemClick);
            this.RemovetoolStripMenuItem.Click += new System.EventHandler(this.MenuItemClick);
            this.TestModeltoolStripMenuItem.Click += new System.EventHandler(this.MenuItemClick);
            this.ModeltoolStripMenuItem.Click += new System.EventHandler(this.MenuItemClick);
            this.ROIInfotoolStripMenuItem.Click += new System.EventHandler(this.MenuItemClick);
        }

        /// <summary>
        /// Create HWindows
        /// </summary>
        private void CreateWindow()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (this.WindowHandle == null)
                {
                    try
                    {
                        int r, c, h, w;

                        r = _borderWidth;
                        c = _borderWidth;

                        w = HWinWidth() - (2 * _borderWidth);
                        h = HWinHeight() - (2 * _borderWidth);
                        if (w == 0 || h == 0)
                            return;

                        HOperatorSet.SetCheck("~father");
                        HTuple hv_WindowHandle;
                        HOperatorSet.OpenWindow(r, c, w, h, base.Handle, "visible", "", out hv_WindowHandle);
                        this.WindowHandle = new HWindow(hv_WindowHandle.H);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Halcon License Error!");
                        //throw;
                    }
                }
            }
        }
        /// <summary>
        /// Dispose HWindow
        /// </summary>
        private void DisposeHWindow()
        {
            if (this.WindowHandle != null)
            {
                this.WindowHandle.Dispose();
                this.WindowHandle = null;
            }
        }

        private void UseROIController()
        {
            ROIController = new ROIController();
            ROIController.SetViewController(this);
        }
        #endregion - InitializeParameters -

        #region - Public Properties -
        /// <summary>
        /// HControl Paint Event Handler
        /// </summary>
        public event HPaintEventHandler HPaintChanged;

        /// <summary>
        /// HControl Mouse Double Click Event Handler
        /// </summary>
        public event HMouseDoubleClickEventHandler HMouseDoubleClickChanged;

        /// <summary>
        /// HControl Active ROIInfo Changed Event Handler
        /// </summary>
        public event Action<object, ROIInfo> ActiveROIInfoChanged;

        [Browsable(true), Category("HControl屬性狀態"), Description("當前WindowHandle")]
        public HWindow WindowHandle { get; private set; }

        private float _zoom = 1F;
        [Browsable(true), Category("HControl屬性狀態"), Description("當前放大率")]
        public float Zoom
        {
            get { return _zoom; }
            set
            {
                if (value > this.MaxZoom)
                {
                    _zoom = this.MaxZoom;
                }
                else if (value < this.MinZoom)
                {
                    _zoom = this.MinZoom;
                }
                else
                {
                    _zoom = value;
                }
            }
        }

        [Browsable(true), Category("HControl屬性狀態"), Description("當前繪圖區域ViewRow1")]
        public float ViewRow1 { get; private set; }

        [Browsable(true), Category("HControl屬性狀態"), Description("當前繪圖區域ViewColumn1")]
        public float ViewColumn1 { get; private set; }

        [Browsable(true), Category("HControl屬性狀態"), Description("當前繪圖區域ViewRow2")]
        public float ViewRow2 { get; private set; }

        [Browsable(true), Category("HControl屬性狀態"), Description("當前繪圖區域ViewColumn2")]
        public float ViewColumn2 { get; private set; }

        [Browsable(true), Category("ROI框參數設定"), Description("是否顯示ROI框文字訊息")]
        public bool IsDispROIFrameFontInfo { get; set; }

        [Browsable(true), Category("ROI框參數設定"), Description("ROI框文字訊息縮放模式")]
        public FontZoomMode ROIFontZoomMode { get; set; }

        [Browsable(true), Category("ROI框參數設定"), Description("ROI框文字訊息字體大小")]
        public int ROIFontSize { get; set; }

        [Browsable(true), Category("ROI框參數設定"), Description("ROI框文字訊息字體大小多少才顯示")]
        public int ROIFontSizeThreshold { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("是否鎖定所有滑鼠操作")]
        public bool IsLockMouseOperation { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("是否鎖定所有滑鼠操作")]
        public bool IsLockGetMposition { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("是否畫面中心顯示十字")]
        public bool IsDispCenterCross { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("是否顯示各式HOject")]
        public bool IsDispHObject { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("是否使用滑鼠右鍵Menu選單")]
        public bool IsUseMenuByMouseRightButton { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("決定HSring多少字體大小才顯示")]
        public int FontSizeThreshold { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("最大放大率")]
        public float MaxZoom { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("最小放大率")]
        public float MinZoom { get; set; }

        [Browsable(true), Category("HControl參數設定"), Description("Ctrl按下狀態")]
        public bool KeyCtrlPressStatus { get; set; }

        private bool _scrollBarEnable = false;
        [Browsable(true), Category("HControl參數設定"), Description("是否啟用ScrollBar")]
        public bool ScrollBarEnable
        {
            get { return _scrollBarEnable; }
            set
            {
                if (_scrollBarEnable != value)
                {
                    _scrollBarEnable = value;
                    this.hScrollBar.Location = new Point(0, base.Height - this.hScrollBar.Height);
                    this.hScrollBar.Visible = _scrollBarEnable;
                    this.vScrollBar.Location = new Point(base.Width - this.vScrollBar.Width, 0);
                    this.vScrollBar.Visible = _scrollBarEnable;
                    RebuildHWinSize();
                }
            }
        }

        private ImageBuffer _imageBuffer;
        [Browsable(true), Category("HControl參數設定"), Description("當前ImageBuffer")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [TypeConverterAttribute(typeof(ExpandableObjectConverter))]
        public ImageBuffer ImageBuffer
        {
            get { return _imageBuffer; }
            set
            {
                lock (this.ImageBuffer.KeyObj)
                {
                    if (HOperatorSetEx.TestObjDef(this.ImageBuffer.RawImage))
                    {
                        _imageBuffer.Dispose();
                    }
                    _imageBuffer = value;
                }
            }
        }

        [Browsable(true), Category("HControl參數設定"), Description("當前ROIController")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [TypeConverterAttribute(typeof(ExpandableObjectConverter))]
        public ROIController ROIController { get; set; }
        #endregion - Public Properties -

        #region - Private Methods -
        private int HWinWidth()
        {
            int value = this.vScrollBar.Visible ? base.Width - this.vScrollBar.Width : base.Width;
            value = value < 0 ? 0 : value;
            return value;
        }

        private int HWinHeight()
        {
            int value = this.hScrollBar.Visible ? base.Height - this.hScrollBar.Height : base.Height;
            value = value < 0 ? 0 : value;
            return value;
        }

        private void RebuildHWinSize()
        {
            if (IsLockMouseOperation) return;
            try
            {
                if (CheckHWindowState())
                {
                    return;
                }
                lock (_keyObj)
                {
                    HOperatorSet.SetWindowExtents(this.WindowHandle, 0, 0, HWinWidth(), HWinHeight());
                }
                FixViewPort();
                Repaint();
            }
            catch (Exception ex)
            {
                if (HalconExceptionHandler(ex))
                {
                    return;
                }
                throw;
            }
        }

        private void SetViewPort(RectangleF rect)
        {
            if (this.ScrollBarEnable)
            {
                _viewPort = new PointF();
                _context.Send((o) =>
                    {
                        this.vScrollBar.Value = 0;
                        this.hScrollBar.Value = 0;
                    }, null);
            }
            else
            {
                float centerX = rect.X + (rect.Width / 2.0f);
                float centerY = rect.Y + (rect.Height / 2.0f);
                _viewPort = new PointF(centerX, centerY);
            }
            this.Zoom = 1;
        }

        private void SetSrcollBarMaximum()
        {
            if (!this.ScrollBarEnable || base.Width == 0 || base.Height == 0)
            {
                return;
            }
            _context.Send((o) =>
            {
                int w = (int)((base.Width - this.vScrollBar.Width) / this.Zoom);
                int h = (int)((base.Height - this.hScrollBar.Height) / this.Zoom);
                //int w = (int)((base.Width) / this.Zoom);
                //int h = (int)((base.Height) / this.Zoom);

                bool isHScrollBarVisible = this.hScrollBar.Visible;
                bool isVScrollBarVisible = this.vScrollBar.Visible;

                this.hScrollBar.Visible = this.ImageBuffer.Widths > w;
                this.vScrollBar.Visible = this.ImageBuffer.Heights > h;

                if (this.hScrollBar.Visible)
                {
                    this.hScrollBar.Maximum = this.ImageBuffer.Widths - (int)(HWinWidth() / this.Zoom) + 10 - 1;
                    this.hScrollBar.LargeChange = 10;
                    this.hScrollBar.Minimum = 0;
                }
                if (this.vScrollBar.Visible)
                {
                    this.vScrollBar.Maximum = this.ImageBuffer.Heights - (int)(HWinHeight() / this.Zoom) + 10 - 1;
                    this.vScrollBar.LargeChange = 10;
                    this.vScrollBar.Minimum = 0;
                }
                if (this.hScrollBar.Visible && this.vScrollBar.Visible)
                {
                    this.hScrollBar.Width = base.Width - this.vScrollBar.Width;
                    this.vScrollBar.Height = base.Height - this.hScrollBar.Height;
                }
                else if (this.hScrollBar.Visible && !this.vScrollBar.Visible)
                {
                    this.hScrollBar.Width = base.Width;
                }
                else if (!this.hScrollBar.Visible && this.vScrollBar.Visible)
                {
                    this.vScrollBar.Height = base.Height;
                }
                else
                {
                }
                if (isVScrollBarVisible != this.vScrollBar.Visible || isHScrollBarVisible != this.hScrollBar.Visible)
                {
                    RebuildHWinSize();
                }
            }, null);
        }

        private void FixViewPort()
        {
            if (this.ScrollBarEnable)
            {
                try
                {
                    if ((int)_viewPort.X > this.hScrollBar.Maximum - this.hScrollBar.LargeChange + 1)
                    {
                        _viewPort.X = (int)(this.hScrollBar.Maximum - this.hScrollBar.LargeChange + 1);
                    }
                    if (_viewPort.X < 0)
                    {
                        _viewPort.X = 0;
                    }
                    this.hScrollBar.Value = (int)_viewPort.X;
                    if ((int)_viewPort.Y > this.vScrollBar.Maximum - this.vScrollBar.LargeChange + 1)
                    {
                        _viewPort.Y = (int)(this.vScrollBar.Maximum - this.vScrollBar.LargeChange + 1);
                    }
                    if (_viewPort.Y < 0)
                    {
                        _viewPort.Y = 0;
                    }
                    this.vScrollBar.Value = (int)_viewPort.Y;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// 畫出全部檢測框
        /// </summary>
        private void PaintROI()
        {
            if (ROIController != null)
            {
                ROIController.paintData(this.WindowHandle, IsDispROIFrameFontInfo);
            }
        }

        public void DrawLineWidth(double width)
        {
            this.WindowHandle.SetLineWidth(width);
        }

        /// <summary>
        /// 畫面十字中心
        /// </summary>
        private void PaintCross()
        {
            if (!this.IsDispCenterCross)
                return;

            int width = HWinWidth();
            int height = HWinHeight();

            HOperatorSet.SetColor(this.WindowHandle, "green");
            HOperatorSet.SetDraw(this.WindowHandle, "fill");

            if (height > width)
            {
                HOperatorSet.DispCross(this.WindowHandle, _viewPort.Y, _viewPort.X, height / Zoom, 0);
            }
            else
            {
                HOperatorSet.DispCross(this.WindowHandle, _viewPort.Y, _viewPort.X, width / Zoom, 0);
            }
        }

        /// <summary>
        /// HWindow失效
        /// </summary>
        private void DrawStart()
        {
            if (((HTuple)this.WindowHandle).H != (IntPtr)0)
            {
                //Thread.Sleep(5);
                HOperatorSet.SetSystem("flush_graphic", "false");
                HOperatorSet.ClearWindow(this.WindowHandle);
            }
            else
            {
                MessageBox.Show((HTuple)this.WindowHandle);
            }
        }

        /// <summary>
        /// HWindow取回控制
        /// </summary>
        private void DrawEnd()
        {
            HOperatorSet.SetSystem("flush_graphic", "true");
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DispLine(this.WindowHandle, -100.0, -100.0, -101.0, -101.0);
        }

        private void DrawImage()
        {
            if (ImageBuffer.RawImage == null)
                return;
            if (!HOperatorSetEx.TestObjDef(ImageBuffer.RawImage))
                return;
            lock (_keyObj)
            {
                DrawStart();
                HOperatorSet.SetPart(this.WindowHandle, this.ViewRow1, this.ViewColumn1, this.ViewRow2, this.ViewColumn2);
                HOperatorSet.DispObj(ImageBuffer.RawImage, this.WindowHandle);
                DrawEnd();
            }
        }

        // Chapter: Graphics / Text
        // Short Description: This procedure writes a text message.
        private void disp_message(HTuple hv_String, HTuple hv_CoordSystem,
            HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box)
        {


            // Local control variables 

            HTuple hv_Red, hv_Green, hv_Blue, hv_Row1Part;
            HTuple hv_Column1Part, hv_Row2Part, hv_Column2Part, hv_RowWin;
            HTuple hv_ColumnWin, hv_WidthWin = new HTuple(), hv_HeightWin;
            HTuple hv_MaxAscent, hv_MaxDescent, hv_MaxWidth, hv_MaxHeight;
            HTuple hv_R1 = new HTuple(), hv_C1 = new HTuple(), hv_FactorRow = new HTuple();
            HTuple hv_FactorColumn = new HTuple(), hv_Width = new HTuple();
            HTuple hv_Index = new HTuple(), hv_Ascent = new HTuple(), hv_Descent = new HTuple();
            HTuple hv_W = new HTuple(), hv_H = new HTuple(), hv_FrameHeight = new HTuple();
            HTuple hv_FrameWidth = new HTuple(), hv_R2 = new HTuple();
            HTuple hv_C2 = new HTuple(), hv_DrawMode = new HTuple(), hv_Exception = new HTuple();
            HTuple hv_CurrentColor = new HTuple();

            HTuple hv_Color_COPY_INP_TMP = hv_Color.Clone();
            HTuple hv_Column_COPY_INP_TMP = hv_Column.Clone();
            HTuple hv_Row_COPY_INP_TMP = hv_Row.Clone();
            HTuple hv_String_COPY_INP_TMP = hv_String.Clone();

            // Initialize local and output iconic variables 

            //This procedure displays text in a graphics window.
            //
            //Input parameters:
            //WindowHandle: The WindowHandle of the graphics window, where
            //   the message should be displayed
            //String: A tuple of strings containing the text message to be displayed
            //CoordSystem: If set to 'window', the text position is given
            //   with respect to the window coordinate system.
            //   If set to 'image', image coordinates are used.
            //   (This may be useful in zoomed images.)
            //Row: The row coordinate of the desired text position
            //   If set to -1, a default value of 12 is used.
            //Column: The column coordinate of the desired text position
            //   If set to -1, a default value of 12 is used.
            //Color: defines the color of the text as string.
            //   If set to [], '' or 'auto' the currently set color is used.
            //   If a tuple of strings is passed, the colors are used cyclically
            //   for each new textline.
            //Box: If set to 'true', the text is written within a white box.
            //
            //prepare window
            HOperatorSet.SetFont(this.WindowHandle, "Arial-18");// -Arial-18-*-1-*-*-1-ANSI_CHARSET-
            HOperatorSet.GetRgb(this.WindowHandle, out hv_Red, out hv_Green, out hv_Blue);
            HOperatorSet.GetPart(this.WindowHandle, out hv_Row1Part, out hv_Column1Part,
                out hv_Row2Part, out hv_Column2Part);
            HOperatorSet.GetWindowExtents(this.WindowHandle, out hv_RowWin, out hv_ColumnWin,
                out hv_WidthWin, out hv_HeightWin);
            HOperatorSet.SetPart(this.WindowHandle, 0, 0, hv_HeightWin - 1, hv_WidthWin - 1);
            //
            //default settings
            if ((int)(new HTuple(hv_Row_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Row_COPY_INP_TMP = 12;
            }
            if ((int)(new HTuple(hv_Column_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Column_COPY_INP_TMP = 12;
            }
            if ((int)(new HTuple(hv_Color_COPY_INP_TMP.TupleEqual(new HTuple()))) != 0)
            {
                hv_Color_COPY_INP_TMP = "";
            }
            //
            hv_String_COPY_INP_TMP = ((("" + hv_String_COPY_INP_TMP) + "")).TupleSplit("\n");
            //
            //Estimate extentions of text depending on font size.
            HOperatorSet.GetFontExtents(this.WindowHandle, out hv_MaxAscent, out hv_MaxDescent,
                out hv_MaxWidth, out hv_MaxHeight);
            if ((int)(new HTuple(hv_CoordSystem.TupleEqual("window"))) != 0)
            {
                hv_R1 = hv_Row_COPY_INP_TMP.Clone();
                hv_C1 = hv_Column_COPY_INP_TMP.Clone();
            }
            else
            {
                //transform image to window coordinates
                hv_FactorRow = (1.0 * hv_HeightWin) / ((hv_Row2Part - hv_Row1Part) + 1);
                hv_FactorColumn = (1.0 * hv_WidthWin) / ((hv_Column2Part - hv_Column1Part) + 1);
                hv_R1 = ((hv_Row_COPY_INP_TMP - hv_Row1Part) + 0.5) * hv_FactorRow;
                hv_C1 = ((hv_Column_COPY_INP_TMP - hv_Column1Part) + 0.5) * hv_FactorColumn;
            }
            //
            //display text box depending on text size
            if ((int)(new HTuple(hv_Box.TupleEqual("true"))) != 0)
            {
                //calculate box extents
                hv_String_COPY_INP_TMP = (" " + hv_String_COPY_INP_TMP) + " ";
                hv_Width = new HTuple();
                for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                    )) - 1); hv_Index = (int)hv_Index + 1)
                {
                    HOperatorSet.GetStringExtents(this.WindowHandle, hv_String_COPY_INP_TMP.TupleSelect(
                        hv_Index), out hv_Ascent, out hv_Descent, out hv_W, out hv_H);
                    hv_Width = hv_Width.TupleConcat(hv_W);
                }
                hv_FrameHeight = hv_MaxHeight * (new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                    ));
                hv_FrameWidth = (((new HTuple(0)).TupleConcat(hv_Width))).TupleMax();
                hv_R2 = hv_R1 + hv_FrameHeight;
                hv_C2 = hv_C1 + hv_FrameWidth;
                //display rectangles
                HOperatorSet.GetDraw(this.WindowHandle, out hv_DrawMode);
                HOperatorSet.SetDraw(this.WindowHandle, "fill");
                HOperatorSet.SetColor(this.WindowHandle, "light gray");
                HOperatorSet.DispRectangle1(this.WindowHandle, hv_R1 + 3, hv_C1 + 3, hv_R2 + 3,
                    hv_C2 + 3);
                HOperatorSet.SetColor(this.WindowHandle, "white");
                HOperatorSet.DispRectangle1(this.WindowHandle, hv_R1, hv_C1, hv_R2, hv_C2);
                HOperatorSet.SetDraw(this.WindowHandle, hv_DrawMode);
            }
            else if ((int)(new HTuple(hv_Box.TupleNotEqual("false"))) != 0)
            {
                hv_Exception = "Wrong value of control parameter Box";
                throw new HalconException(hv_Exception);
            }
            //Write text.
            for (hv_Index = 0; (int)hv_Index <= (int)((new HTuple(hv_String_COPY_INP_TMP.TupleLength()
                )) - 1); hv_Index = (int)hv_Index + 1)
            {
                hv_CurrentColor = hv_Color_COPY_INP_TMP.TupleSelect(hv_Index % (new HTuple(hv_Color_COPY_INP_TMP.TupleLength()
                    )));
                if ((int)((new HTuple(hv_CurrentColor.TupleNotEqual(""))).TupleAnd(new HTuple(hv_CurrentColor.TupleNotEqual(
                    "auto")))) != 0)
                {
                    HOperatorSet.SetColor(this.WindowHandle, hv_CurrentColor);
                }
                else
                {
                    HOperatorSet.SetRgb(this.WindowHandle, hv_Red, hv_Green, hv_Blue);
                }
                hv_Row_COPY_INP_TMP = hv_R1 + (hv_MaxHeight * hv_Index);
                HOperatorSet.SetTposition(this.WindowHandle, hv_Row_COPY_INP_TMP, hv_C1);
                HOperatorSet.WriteString(this.WindowHandle, hv_String_COPY_INP_TMP.TupleSelect(
                    hv_Index));
            }
            //reset changed window settings
            HOperatorSet.SetRgb(this.WindowHandle, hv_Red, hv_Green, hv_Blue);
            HOperatorSet.SetPart(this.WindowHandle, hv_Row1Part, hv_Column1Part, hv_Row2Part,
                hv_Column2Part);

            return;
        }

        private bool HalconExceptionHandler(Exception exception)
        {
            if (exception is HalconException)
            {
                HalconException halconException = exception as HalconException;
                int code = halconException.GetErrorCode();
                if (code == 5)
                {
                    //HALCON error #5: Operator failed (FAIL) in operator get_mposition
                    return true;
                }
                else if (code == 5178)
                {
                    //HALCON error #5178: Operation not possible (window was created in different thread) in operator get_mposition
                    return true;
                }
                else if (code == 5100)
                {
                    //HALCON error #5100: Wrong (logical) window number in operator set_window_extents
                    DisposeHWindow();
                    CreateWindow();
                    Repaint();
                    return true;
                }
                else if (code == 6021)
                {
                    //HALCON error #6021: Not enough video memory available in operator set_window_extents
                    DisposeHWindow();
                    CreateWindow();
                    Repaint();
                    return true;
                }
                else
                {
                    return true;
                }
            }
            return false;   
        }

        private void DetectMouseClickAction(object sender, MouseEventArgs e, HTuple row, HTuple column, HTuple button)
        {
            if (e.Clicks == 2)
            {
                MouseEventArgs mouseArgs = new MouseEventArgs(e.Button, e.Clicks, column.I, row.I, e.Delta);
                OnHMouseDoubleDoubleClick(this, mouseArgs);
            }
        }

        /// <summary>
        /// 判斷HWindow是否建立或視窗畫布大小是否為0
        /// </summary>
        /// <returns></returns>
        private bool CheckHWindowState()
        {
            return this.WindowHandle == null || HWinWidth() == 0 || HWinHeight() == 0;
        }
        #endregion - Private Methods -

        # region - Public Methods -

        /// <summary>重置目前繪圖位置</summary>
        /// 
        public void ResetViewPort()
        {
            //lock (_objKey)
            //{
            if (this.WindowHandle != null)
            {
                SetViewPort(new RectangleF(0, 0, ImageBuffer.Widths, ImageBuffer.Heights));
            }
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mode"></param>
        public void SetViewState(int mode)
        {
            if (ROIController != null)
                ROIController.resetROI();
        }

        /// <summary>Repaint </summary>
        /// 
        public void Repaint()
        {
            //HOperatorSet.SetDraw(this.WindowHandle, "fill");
            if (CheckHWindowState() || !HOperatorSetEx.TestObjDef(ImageBuffer.RawImage))
                return;
            int x, y;
            int w = (int)(HWinWidth() / this.Zoom);
            int h = (int)(HWinHeight() / this.Zoom);

            if (this.ScrollBarEnable)
            {
                if (ImageBuffer.Widths > w)
                {
                    if (_viewPort.X < 0)
                    {
                        _viewPort.X = 0;
                    }
                    if ((this.ImageBuffer.Widths - _viewPort.X) < w)
                    {
                        _context.Send((o) =>
                        {
                            this.hScrollBar.Value = this.hScrollBar.Maximum - this.hScrollBar.LargeChange + 1;
                            _viewPort.X = this.ImageBuffer.Widths - w + 1;
                        }, null);
                    }
                    x = (int)(_viewPort.X);
                }
                else
                {
                    x = -(int)(w - this.ImageBuffer.Widths) / 2;
                }

                if (ImageBuffer.Heights > h)
                {
                    if (_viewPort.Y < 0)
                    {
                        _viewPort.Y = 0;
                    }
                    if ((this.ImageBuffer.Heights - _viewPort.Y) < h)
                    {
                        _context.Send((o) =>
                        {
                            this.vScrollBar.Value = this.vScrollBar.Maximum - this.vScrollBar.LargeChange + 1;
                            _viewPort.Y = this.ImageBuffer.Heights - h + 1;
                        }, null);
                    }
                    y = (int)(_viewPort.Y);
                }
                else
                {
                    y = -(int)(h - this.ImageBuffer.Heights) / 2;
                }
            }
            else
            {
                int wz2 = (int)Math.Round(w / 2.0f);
                int hz2 = (int)Math.Round(h / 2.0f);

                x = (int)(_viewPort.X - wz2);
                y = (int)(_viewPort.Y - hz2);
            }
            lock (this.ImageBuffer.KeyObj)
            {
                Rectangle rect = new Rectangle(x, y, (int)(w), (int)(h));

                this.ViewRow1 = rect.Y;
                this.ViewColumn1 = rect.X;
                this.ViewRow2 = rect.Y + rect.Height - 1;
                this.ViewColumn2 = rect.X + rect.Width - 1;

                DrawImage();
                setText();

                if (this.IsDispHObject)
                {
                    DisplayHRegions(_hRegionInfoList);

                    DisplayHXLD(_hXLDInfoList);

                    DisplayStrings(_hStringInfoList);

                    DisplayMessages(_hMessageInfoList);

                    PaintROI();

                    PaintCross();

                    //PaintPixel();
                }
            }
        }

        /// <summary>判斷ImageBuffer RawImage是否有正確圖資</summary>
        /// <returns></returns>
        public bool IsExistImage()
        {
            return HOperatorSetEx.TestObjDef(ImageBuffer.RawImage);
        }

        /// <summary>設定指定位置顯示範圍</summary>
        /// <param name="isCenterAlign">是否自動置中</param>
        /// <param name="x">X</param>
        /// <param name="y">Y</param>
        /// <param name="width">Width</param>
        /// <param name="height">Height</param>
        public void SetViewPort(bool isCenterAlign, float x, float y, int width, int height)
        {
            //IsLockMouseOperation = true;
            if (ScrollBarEnable)
            {
                float widthshrinkpercent = (float)(base.Width - this.vScrollBar.Width) / width;
                float heightshrinkpercent = (float)(base.Height - this.hScrollBar.Height) / height;
                this.Zoom = (widthshrinkpercent < heightshrinkpercent) ? widthshrinkpercent : heightshrinkpercent;
                if (this.Zoom < this.MinZoom)
                {
                    this.Zoom = this.MinZoom;
                }
                SetSrcollBarMaximum();
                //if ((base.Width - this.vScrollBar.Width) > (base.Height - this.hScrollBar.Height))
                if (widthshrinkpercent > heightshrinkpercent)
                {
                    float offset = isCenterAlign ? (base.Width - this.vScrollBar.Width - width * this.Zoom) / 2.0f / this.Zoom : 0;
                    _viewPort = new PointF(x - offset, y);
                }
                else
                {
                    float offset = isCenterAlign ? (base.Height - this.hScrollBar.Height - height * this.Zoom) / 2.0f / this.Zoom : 0;
                    _viewPort = new PointF(x, y - offset);
                }
            }
            else
            {
                float widthshrinkpercent = (float)base.Width / width;
                float heightshrinkpercent = (float)base.Height / height;
                this.Zoom = (widthshrinkpercent < heightshrinkpercent) ? widthshrinkpercent : heightshrinkpercent;
                if (this.Zoom < this.MinZoom)
                {
                    this.Zoom = this.MinZoom;
                }
                //if (base.Width > base.Height)
                if (widthshrinkpercent > heightshrinkpercent)
                {
                    float offset = !isCenterAlign ? (base.Width - width * this.Zoom) / 2.0f / this.Zoom : 0;
                    _viewPort = new PointF(x + (width / 2.0f) + offset, y + (height / 2.0f));
                }
                else
                {
                    float offset = !isCenterAlign ? (base.Height - height * this.Zoom) / 2.0f / this.Zoom : 0;
                    _viewPort = new PointF(x + (width / 2.0f), y + (height / 2.0f) + offset);
                }
            }
            FixViewPort();
            Repaint();
            //IsLockMouseOperation = false;
        }

        /// <summary>
        /// 設定指定位置及倍率顯示
        /// </summary>
        /// <param name="x">X</param>
        /// <param name="y">Y</param>
        /// <param name="zoom">Zoom(當輸入為-1時不會改變原有倍率)</param>
        public void SetViewPort(float x, float y, float zoom)
        {
            //IsLockMouseOperation = true;
            if (zoom > 0)
            {
                this.Zoom = zoom;   
            }
            if (ScrollBarEnable)
            {
                SetSrcollBarMaximum();
                _viewPort = new PointF(x, y);
            }
            else
            {
                int w = (int)(HWinWidth() / this.Zoom);
                int h = (int)(HWinHeight() / this.Zoom);
                int wz2 = (int)Math.Round(w / 2.0f);
                int hz2 = (int)Math.Round(h / 2.0f);
                _viewPort = new PointF(x + wz2, y + hz2);
            }
            FixViewPort();
            Repaint();
            //IsLockMouseOperation = false;
        }

        /// <summary>
        /// 判定給定邊界位置是否超過畫布區域並修正
        /// </summary>
        /// <param name="row1"></param>
        /// <param name="column1"></param>
        /// <param name="row2"></param>
        /// <param name="column2"></param>
        public void CheckBoundary(ref HTuple row1, ref HTuple column1, ref HTuple row2, ref HTuple column2)
        {
            CheckBoundary(0, 0, this.ImageBuffer.Rows, this.ImageBuffer.Columns, ref row1, ref column1, ref row2, ref column2);
        }

        /// <summary>
        /// 判定給定邊界位置是否超過畫布區域並修正
        /// </summary>
        /// <param name="startColumn"></param>
        /// <param name="startRow"></param>
        /// <param name="endColumn"></param>
        /// <param name="endRow"></param>
        /// <param name="row1"></param>
        /// <param name="column1"></param>
        /// <param name="row2"></param>
        /// <param name="column2"></param>
        public void CheckBoundary(int startRow, int startColumn, int endRow, int endColumn, ref HTuple row1, ref HTuple column1, ref HTuple row2, ref HTuple column2)
        {
            HTuple rowBoundary1 = this.ImageBuffer.Height * startRow;
            HTuple columnBoundary1 = this.ImageBuffer.Width * startColumn;
            HTuple rowBoundary2 = this.ImageBuffer.Height * (endRow + 1) - 1;
            HTuple columnBoundary2 = this.ImageBuffer.Width * (endColumn + 1) - 1;
            row1 = row1.TupleLess(rowBoundary1) == 1 ? rowBoundary1 : row1;
            column1 = column1.TupleLess(columnBoundary1) == 1 ? columnBoundary1 : column1;
            row2 = row2.TupleGreater(rowBoundary2) == 1 ? rowBoundary2 : row2;
            column2 = column2.TupleGreater(columnBoundary2) == 1 ? columnBoundary2 : column2;
        }
        # endregion - Public Methods -

        #region - Image Operation Methods -
        /// <summary>
        /// ImageBuffer初始化
        /// </summary>
        /// <param name="width">單張Buffer寬</param>
        /// <param name="height">單張Buffer高</param>
        /// <param name="columns">Col方向數量</param>
        /// <param name="rows">Row方向數量</param>
        public void InitializeImageBuffer(int width, int height, int cols, int rows)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
            ImageBuffer.InitializeImageBuffer(width, height, cols, rows);
            //}
            ResetViewPort();
            SetSrcollBarMaximum();
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由圖片路徑讀取到指定ImageBuffer位置
        /// </summary>
        /// <param name="filePath">來源路徑</param>
        /// <param name="column">Col位置</param>
        /// <param name="row">Row位置</param>
        public void ReadImage(string filePath, int col, int row)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                ImageBuffer.ReadImage(filePath, col, row);
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由圖片指標讀取到指定ImageBuffer位置
        /// </summary>
        /// <param name="pointer">來源指標</param>
        /// <param name="column">Col位置</param>
        /// <param name="row">Row位置</param>
        public void ReadImage(IntPtr pointer, int col, int row)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                ImageBuffer.ReadImage(pointer, col, row);
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由圖片HObject讀取到指定ImageBuffer位置
        /// </summary>
        /// <param name="image">來源圖片HObject</param>
        /// <param name="column">Col位置</param>
        /// <param name="row">Row位置</param>
        public void ReadImage(HObject image, int col, int row)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                HImageInfo hImageInfo = HOperatorSetEx.GetImagePointer1(image, false);
                ImageBuffer.ReadImage(hImageInfo.Pointer.IP, col, row);
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由對話視窗讀取圖片
        /// </summary>
        public void ReadImage()
        {
            IsLockMouseOperation = true;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = HImageFormat.AllFormat;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //lock (_objKey)
                //{
                    HObject ho_Image = null;
                    HOperatorSet.GenEmptyObj(out ho_Image);
                    ho_Image.Dispose();
                    HOperatorSet.ReadImage(out ho_Image, openFileDialog.FileName);
                    ReadImage(ho_Image);
                    ResetViewPort();
                    ho_Image.Dispose();
                //}
            }
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由圖片路徑讀取圖片
        /// </summary>
        /// <param name="string">filePath</param>
        public void ReadImage(string filePath)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                if (!File.Exists(filePath))
                {
                    throw new ArgumentException("File Path Error!");
                }
                HObject ho_Image;
                HOperatorSet.ReadImage(out ho_Image, filePath);
                ReadImage(ho_Image);
                ho_Image.Dispose();
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由圖片指標讀取圖片
        /// </summary>
        /// <param name="width">圖片寬</param>
        /// <param name="height">圖片高</param>
        /// <param name="pointer">圖片指標</param>
        public void ReadImage(int width, int height, IntPtr pointer)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                if (pointer == IntPtr.Zero)
                {
                    throw new ArgumentException("Pointer is Zero!");
                }
                HObject ho_Image = HOperatorSetEx.GenImage1(width, height, pointer);
                ReadImage(ho_Image);
                ho_Image.Dispose();
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 由HObject讀取圖片
        /// </summary>
        /// <param name="image"></param>
        public void ReadImage(HObject image)
        {
            IsLockMouseOperation = true;
            //lock (_objKey)
            //{
                if (image == null)
                {
                    throw new ArgumentException("HImage is Null !");
                }
                ImageBuffer.ReadImage(image);
                SetSrcollBarMaximum();
            //}
            IsLockMouseOperation = false;
        }
        /// <summary>由對話視窗儲存現有圖片</summary>
        public void SaveImage()
        {
            IsLockMouseOperation = true;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = HImageFormat.AllFormat;
            saveFileDialog.FilterIndex = 2;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                SaveImage(saveFileDialog.FileName);
            }
            IsLockMouseOperation = false;
        }
        /// <summary>
        /// 儲存圖片到指定路徑
        /// </summary>
        /// <param name="filePath"></param>
        public void SaveImage(string filePath)
        {
            string fileformat = Path.GetExtension(filePath);
            fileformat = fileformat.Substring(1, fileformat.Length - 1);
            HOperatorSet.WriteImage(ImageBuffer.RawImage, fileformat, 0, filePath);
        }
        /// <summary>
        /// 儲存被選擇的ROI圖片
        /// </summary>
        public void SaveSelectedROIImage()
        {
            ROIController.SaveSelectedROIImage();
        }
        /// <summary>
        /// 擷取被選擇的ROI圖片
        /// </summary>
        /// <returns></returns>
        public HObject CropSelectedROIImage()
        {
            HObject ho_CropSelectedROIImage;
            ROIController.CropSelectedROIImage(ImageBuffer.RawImage, out ho_CropSelectedROIImage);
            return ho_CropSelectedROIImage;
        }
        /// <summary>
        /// 儲存當前畫面
        /// </summary>
        public void DumpWindow()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = HImageFormat.AllFormat;
            saveFileDialog.FilterIndex = 4;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string extension = Path.GetExtension(saveFileDialog.FileName);
                DumpWindow(extension.Substring(1, extension.Length - 1), saveFileDialog.FileName);
            }
        }
        /// <summary>
        /// 儲存當前畫面
        /// </summary>
        /// <param name="device">儲存格式</param>
        /// <param name="fileName">儲存圖片檔名</param>
        public void DumpWindow(HTuple device, HTuple fileName)
        {
            HOperatorSet.DumpWindow(this.WindowHandle, device, fileName);
        }
        /// <summary>
        /// 取得目前HControl圖資
        /// </summary>
        public HObject GetHImage(bool isCopyObj)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (ImageBuffer.RawImage != null)
                {
                    if (isCopyObj)
                    {
                        return ImageBuffer.RawImage.CopyObj(1, -1);
                    }
                    else
                    {
                        return ImageBuffer.RawImage;
                    }
                }
                else
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// 取得目前HControl圖資
        /// </summary>
        /// <param name="roiInfo">roiInfo</param>
        /// <returns></returns>
        public HObject GetHImage(ROIInfo roiInfo)
        {
            return GetHImage(roiInfo.Y, roiInfo.X, roiInfo.Y + roiInfo.Height - 1, roiInfo.X + roiInfo.Width - 1);
        }
        /// <summary>
        /// 取得目前HControl圖資
        /// </summary>
        /// <param name="row1">row1</param>
        /// <param name="column1">column1</param>
        /// <param name="row2">row2</param>
        /// <param name="column2">column2</param>
        /// <returns></returns>
        public HObject GetHImage(HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (IsExistImage())
                {
                    return HOperatorSetEx.CropRectangle1(this.ImageBuffer.RawImage,
                                                row1, column1, row2, column2);
                }
                else
                {
                    return null;
                }
            }
        }
        #endregion - Image Operation Methods -

        #region - Region, XLD, String Methods -
        /// <summary>
        /// 增加HRegion到List清單
        /// </summary>
        /// <param name="name">HRegion名稱</param>
        /// <param name="dispColor">HRegion顏色</param>
        /// <param name="drawMode">margin or fill</param>
        /// <param name="hRegion">HRegion</param>
        public void AddHRegion(string name, HColorMode dispColor, HDrawMode drawMode, HObject hRegion)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (HOperatorSetEx.TestObjDef(hRegion))
                {
                    _hRegionInfoList.Add(new HRegionInfo()
                    {
                        Name = name,
                        HDispColor = dispColor,
                        HDrawMode = drawMode,
                        HDispRegion = hRegion.CopyObj(1, -1)
                    });
                }
            }
        }

        /// <summary>
        /// 增加HRegion到List清單
        /// </summary>
        /// <param name="dispColor">HRegion顏色</param>
        /// <param name="drawMode">margin or fill</param>
        /// <param name="hRegion">HRegion</param>
        public void AddHRegion(HColorMode dispColor, HDrawMode drawMode, HObject hRegion)
        {
            AddHRegion(string.Empty, dispColor, drawMode, hRegion);
        }

        /// <summary>
        /// 增加HRegion到List清單
        /// </summary>
        /// <param name="dispColor">HRegion顏色</param>
        /// <param name="hRegion">HRegion</param>
        public void AddHRegion(HColorMode dispColor, HObject hRegion)
        {
            AddHRegion(dispColor, HDrawMode.margin, hRegion);
        }

        /// <summary>
        /// 增加HRegion到List清單
        /// </summary>
        /// <param name="hRegion">HRegion</param>
        public void AddHRegion(string v, HObject hRegion)
        {
            AddHRegion(HColorMode.red, hRegion);
        }

        /// <summary>
        /// 增加HXLD到List清單
        /// </summary>
        /// <param name="name">HXLD名稱</param>
        /// <param name="dispColor">HXLD顏色</param>
        /// <param name="hRegion">HXLD</param>
        public void AddHXLD(string name, HColorMode dispColor, HObject hXLD)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (HOperatorSetEx.TestObjDef(hXLD))
                {
                    _hXLDInfoList.Add(new HXLDInfo()
                    {
                        Name = name,
                        HDispColor = dispColor,
                        HDispXLD = hXLD.CopyObj(1, -1)
                    });
                }
            }
        }

        /// <summary>
        /// 增加HXLD到List清單
        /// </summary>
        /// <param name="dispColor">HXLD顏色</param>
        /// <param name="hRegion">HXLD</param>
        public void AddHXLD(HColorMode dispColor, HObject hXLD)
        {
            AddHXLD(string.Empty, dispColor, hXLD);
        }

        /// <summary>
        /// 增加HXLD到List清單
        /// </summary>
        /// <param name="hRegion">HXLD</param>
        public void AddHXLD(HObject hXLD)
        {
            AddHXLD(HColorMode.red, hXLD);
        }

        /// <summary>
        /// 增加HString到HStringList清單
        /// </summary>
        /// <param name="name">文字名稱</param>
        /// <param name="dispColor">文字顏色</param>
        /// <param name="msg">顯示文字</param>
        /// <param name="fontSize">文字大小</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        public void AddHString(string name, HColorMode dispColor, HTuple msg, HTuple fontSize, HTuple row, HTuple column)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (msg != null)
                {
                    _hStringInfoList.Add(new HStringInfo()
                    {
                        Name = name,
                        DispColor = dispColor,
                        Msg = msg,
                        FontSize = fontSize,
                        Row = row,
                        Column = column
                    });
                }
            }
        }

        /// <summary>
        /// 增加HString到HStringList清單
        /// </summary>
        /// <param name="dispColor">文字顏色</param>
        /// <param name="msg">顯示文字</param>
        /// <param name="fontSize">文字大小</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        public void AddHString(HColorMode dispColor, HTuple msg, HTuple fontSize, HTuple row, HTuple column)
        {
            AddHString(string.Empty, dispColor, msg, fontSize, row, column);
        }

        /// <summary>
        /// 增加HString到HStringList清單
        /// </summary>
        /// <param name="msg">顯示文字</param>
        /// <param name="fontSize">文字大小</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        public void AddHString(HTuple msg, HTuple fontSize, HTuple row, HTuple column)
        {
            AddHString(HColorMode.red, msg, fontSize, row, column);
        }

        /// <summary>
        /// 增加HMessage到HMessageList清單
        /// </summary>
        /// <param name="name">訊息名稱</param>
        /// <param name="dispColor">訊息顏色</param>
        /// <param name="msg">訊息</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        /// <param name="box">是否有白底</param>
        public void AddHMessage(string name, HColorMode dispColor, HTuple msg, HTuple row, HTuple column, HTuple box)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (msg != null)
                {
                    _hMessageInfoList.Add(new HMessageInfo()
                    {
                        Name = name,
                        DispColor = dispColor,
                        Msg = msg,
                        Row = row,
                        Column = column,
                        Box = box
                    });
                }
            }
        }

        /// <summary>
        /// 增加HMessage到HMessageList清單
        /// </summary>
        /// <param name="dispColor">訊息顏色</param>
        /// <param name="msg">訊息</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        /// <param name="box">是否有白底</param>
        public void AddHMessage(HColorMode dispColor, HTuple msg, HTuple row, HTuple column, HTuple box)
        {
            AddHMessage(string.Empty, dispColor, msg, row, column, box);
        }

        /// <summary>
        /// 增加HMessage到HMessageList清單
        /// </summary>
        /// <param name="dispColor">訊息顏色</param>
        /// <param name="msg">訊息</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        public void AddHMessage(HColorMode dispColor, HTuple msg, HTuple row, HTuple column)
        {
            AddHMessage(dispColor, msg, row, column, "true");
        }

        /// <summary>
        /// 增加HMessage到HMessageList清單
        /// </summary>
        /// <param name="msg">訊息</param>
        /// <param name="row">row</param>
        /// <param name="column">column</param>
        public void AddHMessage(HTuple msg, HTuple row, HTuple column)
        {
            AddHMessage(HColorMode.black, msg, row, column, "true");
        }

        /// <summary>
        /// 繪畫 Region 組合
        /// </summary>
        private void DisplayHRegions(List<HRegionInfo> hRegionInfoList)
        {
            //lock (_objKey)
            //{
                string str = "";
                if (hRegionInfoList != null)
                {
                    for (int i = 0; i < hRegionInfoList.Count; i++)
                    {
                        try
                        {
                            string color = hRegionInfoList[i].HDispColor.ToString();
                            if (color.Contains('_'))
                            {
                                color = color.Replace('_', ' ');
                            }
                            HTuple hv_DrawMode;
                            HOperatorSet.GetDraw(this.WindowHandle, out hv_DrawMode);
                            HOperatorSet.SetDraw(this.WindowHandle, hRegionInfoList[i].HDrawMode.ToString());
                            HOperatorSet.SetColor(this.WindowHandle, color);
                            HOperatorSet.DispObj(hRegionInfoList[i].HDispRegion, this.WindowHandle);
                            HOperatorSet.SetDraw(this.WindowHandle, hv_DrawMode);
                        }
                        catch (Exception)
                        {
                            str += i.ToString() + " ,";
                            throw;
                        }
                    }
                }
            //}
        }

        /// <summary>
        /// 繪畫 XLS 組合
        /// </summary>
        private void DisplayHXLD(List<HXLDInfo> hXldInfoList)
        {
            //lock (_objKey)
            //{
                string str = "";
                if (hXldInfoList != null)
                {
                    for (int i = 0; i < hXldInfoList.Count; i++)
                    {
                        try
                        {
                            string color = hXldInfoList[i].HDispColor.ToString();
                            if (color.Contains('_'))
                            {
                                color = color.Replace('_', ' ');
                            }
                            HOperatorSet.SetColor(this.WindowHandle, color);
                            HOperatorSet.DispObj(hXldInfoList[i].HDispXLD, this.WindowHandle);
                        }
                        catch (Exception)
                        {
                            str += i.ToString() + " ,";
                            throw;
                        }
                    }
                }
            //}
        }

        /// <summary>
        /// 繪畫 String 組合
        /// </summary>
        private void DisplayStrings(List<HStringInfo> hStringInfoList)
        {
            //lock (_objKey)
            //{
                if (hStringInfoList != null)
                {
                    for (int i = 0; i < hStringInfoList.Count; i++)
                    {
                        try
                        {
                            if (hStringInfoList[i].FontSize * this.Zoom > this.FontSizeThreshold)
                            {
                                string color = hStringInfoList[i].DispColor.ToString();
                                if (color.Contains('_'))
                                {
                                    color = color.Replace('_', ' ');
                                }
                                HOperatorSet.SetColor(this.WindowHandle, color);
                                if (hStringInfoList[i].Row > this.ViewRow1 && hStringInfoList[i].Row < this.ViewRow2 &&
                                    hStringInfoList[i].Column > this.ViewColumn1 && hStringInfoList[i].Column < this.ViewColumn2)
                                {
                                    PaintFont(hStringInfoList[i].Msg, hStringInfoList[i].FontSize, hStringInfoList[i].Row, hStringInfoList[i].Column);
                                }
                            }
                        }
                        catch
                        {
                            throw;
                        }
                    }
                }
            //}
        }

        /// <summary>
        /// 繪畫 Message 組合
        /// </summary>
        private void DisplayMessages(List<HMessageInfo> hMessageInfoList)
        {
            //lock (_objKey)
            //{
                if (hMessageInfoList != null)
                {
                    for (int i = 0; i < hMessageInfoList.Count; i++)
                    {
                        try
                        {
                            disp_message(hMessageInfoList[i].Msg, "window", hMessageInfoList[i].Row, hMessageInfoList[i].Column, hMessageInfoList[i].DispColor.ToString(), hMessageInfoList[i].Box);
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.ToString());
                        }
                    }
                }
            //}
        }

        /// <summary>
        /// 清除各式顯示物件
        /// </summary>
        public void ResetAllHDispObject()
        {
            //lock (_objKey)
            //{
                ResetAllHRegionInfo();
                ResetAllHXLDInfo();
                ResetAllHStringInfo();
                ResetAllHMessageInfo();      
            //}
        }

        /// <summary>
        /// 清除所有 Region 組合
        /// </summary>
        public void ResetAllHRegionInfo()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (_hRegionInfoList != null)
                {
                    if (_hRegionInfoList.Count != 0)
                    {
                        foreach (HRegionInfo item in _hRegionInfoList)
                        {
                            item.HDispRegion.Dispose();
                        }
                        _hRegionInfoList.Clear();
                    }
                }
            }
        }

        /// <summary>
        /// 清除所有 XLD 組合
        /// </summary>
        public void ResetAllHXLDInfo()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (_hXLDInfoList != null)
                {
                    if (_hXLDInfoList.Count != 0)
                    {
                        foreach (HXLDInfo item in _hXLDInfoList)
                        {
                            item.HDispXLD.Dispose();
                        }
                        _hXLDInfoList.Clear();
                    }
                }
            }
        }

        /// <summary>
        /// 清除所有 String 組合
        /// </summary>
        public void ResetAllHStringInfo()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (_hStringInfoList != null)
                {
                    if (_hStringInfoList.Count != 0)
                    {
                        _hStringInfoList.Clear();
                    }
                }
            }
        }

        /// <summary>
        /// 清除所有 Message 組合
        /// </summary>
        public void ResetAllHMessageInfo()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                if (_hMessageInfoList != null)
                {
                    if (_hMessageInfoList.Count != 0)
                    {
                        _hMessageInfoList.Clear();
                    }
                }
            }
        }

        /// <summary>
        /// 清除指定名稱的 Region 
        /// </summary>
        /// <param name="name">name</param>
        public void RemoveHRegionInfoByName(DeleteMode deleteMode, string name)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                _hRegionInfoList.RemoveAll((x) =>
                {
                    if (x.Name == name && deleteMode == DeleteMode.Match)
                    {
                        x.HDispRegion.Dispose();
                        return true;
                    }
                    else if (x.Name != name && deleteMode == DeleteMode.UnMatch)
                    {
                        x.HDispRegion.Dispose();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                });   
            }
            Repaint();
        }

        /// <summary>
        /// 清除被點選到的 Region 
        /// </summary>
        public void RemoveHRegionInfoByDrawPoint()
        {
            HTuple hv_Row, hv_Column;
            DrawPoint(out hv_Row, out hv_Column);
            RemoveHRegionInfoByPoint(hv_Row, hv_Column);
        }

        /// <summary>
        /// 清除指定座標點的 Region 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="column"></param>
        public void RemoveHRegionInfoByPoint(HTuple row, HTuple column)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                HObject ho_Regions, ho_DestRegions;
                HOperatorSet.GenEmptyObj(out ho_Regions);
                HOperatorSet.GenEmptyObj(out ho_DestRegions);

                ho_Regions = GetConcatHRegion();
                ho_DestRegions.Dispose();
                HOperatorSet.SelectRegionPoint(ho_Regions, out ho_DestRegions, row, column);

                for (int i = 0; i < ho_DestRegions.CountObj(); i++)
                {
                    foreach (HRegionInfo hRegionInfo in _hRegionInfoList)
                    {
                        bool isDelete = false;
                        for (int j = 0; j < hRegionInfo.HDispRegion.CountObj(); j++)
                        {
                            if ((int)ho_DestRegions.SelectObj(i + 1).TestEqualObj(hRegionInfo.HDispRegion.SelectObj(j + 1)) == 1)
                            {
                                hRegionInfo.HDispRegion.Dispose();
                                _hRegionInfoList.Remove(hRegionInfo);
                                isDelete = true;
                                break;
                            }
                        }
                        if (isDelete)
                        {
                            break;
                        }
                    }
                }   
            }
            Repaint();
        }

        /// <summary>
        /// 清除指定名稱的 XLD 
        /// </summary>
        /// <param name="name">name</param>
        public void RemoveHXLDInfoByName(DeleteMode deleteMode, string name)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                _hXLDInfoList.RemoveAll((x) =>
                {
                    if (x.Name == name && deleteMode == DeleteMode.Match)
                    {
                        x.HDispXLD.Dispose();
                        return true;
                    }
                    else if (x.Name != name && deleteMode == DeleteMode.UnMatch)
                    {
                        x.HDispXLD.Dispose();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                });
            }
            Repaint();
        }

        /// <summary>
        /// 清除指定名稱的 String 
        /// </summary>
        /// <param name="name">name</param>
        public void RemoveHStringInfoByName(DeleteMode deleteMode, string name)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                _hStringInfoList.RemoveAll((x) =>
                {
                    if (deleteMode == DeleteMode.Match)
                    {
                        return x.Name == name;
                    }
                    else
                    {
                        return x.Name != name;
                    }
                });
            }
            Repaint();
        }

        /// <summary>
        /// 清除指定名稱的 Message 
        /// </summary>
        /// <param name="name">name</param>
        public void RemoveHMessageInfoByName(DeleteMode deleteMode, string name)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                _hMessageInfoList.RemoveAll((x) =>
                {
                    if (deleteMode == DeleteMode.Match)
                    {
                        return x.Name == name;
                    }
                    else
                    {
                        return x.Name != name;
                    }
                });
            }
            Repaint();
        }

        /// <summary>
        /// 取得所有HRegionInfo組合
        /// </summary>
        /// <returns></returns>
        public List<HRegionInfo> GetHRegionInfoCollection()
        {
            return _hRegionInfoList;
        }

        /// <summary>
        /// 取得所有HXLDInfo組合
        /// </summary>
        /// <returns></returns>
        public List<HXLDInfo> GetHXLDInfoCollection()
        {
            return _hXLDInfoList;
        }

        /// <summary>
        /// 取得所有HStringInfo組合
        /// </summary>
        /// <returns></returns>
        public List<HStringInfo> GetHStringInfoCollection()
        {
            return _hStringInfoList;
        }

        /// <summary>
        /// 取得所有HMessageInfo組合
        /// </summary>
        /// <returns></returns>
        public List<HMessageInfo> GetHMessageInfoCollection()
        {
            return _hMessageInfoList;
        }

        /// <summary>
        /// 取得所有 Region ConcatObj 組合
        /// </summary>
        public HObject GetConcatHRegion()
        {
            lock (this.ImageBuffer.KeyObj)
            {
                HObject ho_Regions;
                HOperatorSet.GenEmptyObj(out ho_Regions);
                foreach (HRegionInfo hRegionInfo in _hRegionInfoList)
                {
                    ho_Regions = HOperatorSetEx.ConcatObj(ho_Regions, hRegionInfo.HDispRegion);
                }
                return ho_Regions;
            }
        }

        /// <summary>
        /// 取得所有 Region ConcatObj 組合
        /// </summary>
        public HObject GetConcatHRegion(string name)
        {
            lock (this.ImageBuffer.KeyObj)
            {
                List<HRegionInfo> hRegionInfoLis = _hRegionInfoList.FindAll((x) => x.Name == name);
                HObject ho_Regions;
                HOperatorSet.GenEmptyObj(out ho_Regions);
                foreach (HRegionInfo hRegionInfo in hRegionInfoLis)
                {
                    ho_Regions = HOperatorSetEx.ConcatObj(ho_Regions, hRegionInfo.HDispRegion);
                }
                hRegionInfoLis.Clear();
                return ho_Regions;
            }
        }
        #endregion - Region, XLD, String Methods -

        #region - Paint HObject Methods-
        /// <summary>
        /// Draw Rectangle    //未完成
        /// </summary>
        public void PaintRectangle()
        {
            if (this.WindowHandle == null)
            {
                return;
            }

            string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
            int fontSize = (int)(18);
            HTuple font = string.Format(fontFormat, fontSize);

            HOperatorSet.SetLineStyle(this.WindowHandle, 0);
            HOperatorSet.SetColor(this.WindowHandle, "red");

            HOperatorSet.SetTposition(this.WindowHandle, 480, 640);
            HOperatorSet.SetFont(this.WindowHandle, font);
            HOperatorSet.WriteString(this.WindowHandle, "1:1");

            HOperatorSet.DispRectangle1(this.WindowHandle, 640, 480, 1024, 768);

        }
        /// <summary>
        /// Point String
        /// </summary>
        public void PaintFont(HTuple msg, int fontSize, HTuple row, HTuple col)
        {
            //string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
            string fontFormat = String.Format("Arial-{0}", fontSize);
            int h_fontZoom = (int)(fontSize * this.Zoom <= 1 ? 1 : fontSize * this.Zoom);
            HTuple font = string.Format(fontFormat, h_fontZoom);
            HOperatorSet.SetFont(this.WindowHandle, font);
            HOperatorSet.SetTposition(this.WindowHandle, row, col);
            HOperatorSet.WriteString(this.WindowHandle, msg);
        }

        private void PaintObject(HObject hObject)
        {
            if (hObject != null)
            {
                m_HRegion = hObject;

                HOperatorSet.DispObj(m_HRegion, this.WindowHandle);
            }
        }

        public void PaintLine(HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        {
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DispLine(this.WindowHandle, row1, column1, row2, column2);
        }

        public void PaintCross(double row, double col)
        {
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DispCross(this.WindowHandle, row, col, 50 / Zoom, 0);
        }

        public void PaintRectangle(Rectangle rect)
        {
            HOperatorSet.SetColor(this.WindowHandle, "blue");
            HOperatorSet.DispRectangle1(this.WindowHandle, rect.Y, rect.X, (double)(rect.Y + rect.Height - 1), (double)(rect.X + rect.Width - 1));
        }

        private void PaintPixel()
        {
            //lock (_objKey)
            //{
            if (this.Zoom > 10)
            {
                HTuple hv_DrawMode;
                HOperatorSet.GetDraw(this.WindowHandle, out hv_DrawMode);
                for (float i = this.ViewRow1; i <= this.ViewRow2; i++)
                {
                    for (float j = this.ViewColumn1; j <= this.ViewColumn2; j++)
                    {
                        HObject ho_Rectangle = HOperatorSetEx.GenRectangle1(i, j, i, j);
                        HOperatorSet.SetDraw(this.WindowHandle, HDrawMode.margin.ToString());
                        HOperatorSet.SetColor(this.WindowHandle, HColorMode.gray.ToString());
                        HOperatorSet.DispObj(ho_Rectangle, this.WindowHandle);
                        ho_Rectangle.Dispose();
                    }
                }
                HOperatorSet.SetDraw(this.WindowHandle, hv_DrawMode);   
            }
            //}
        }
        #endregion - Paint HObject Methods-

        #region - Zoom Event Methods-
        /// <summary>
        /// 縮到到適當螢幕大小
        /// </summary>
        public void ZoomToFit()
        {
            ZoomToFitMode(FitMode.Auto);
        }
        /// <summary>
        /// 根據模式縮到到適當螢幕大小
        /// </summary>
        /// <param name="fitMode">Fit模式</param>
        public void ZoomToFitMode(FitMode fitMode)
        {
            //ResetViewPort();
            //float widthshrinkpercent = (float)base.Width / ImageBuffer.Widths;
            //float heightshrinkpercent = (float)base.Height / ImageBuffer.Heights;
            //this.Zoom = (widthshrinkpercent < heightshrinkpercent) ? widthshrinkpercent : heightshrinkpercent;
            //if (this.Zoom < this.MinZoom)
            //{
            //    this.Zoom = this.MinZoom;
            //}
            //SetSrcollBarMaximum();
            //Repaint();
            
            float widthshrinkpercent = (float)base.Width / ImageBuffer.Widths;
            float heightshrinkpercent = (float)base.Height / ImageBuffer.Heights;
            float zoomValue = 1f;
            if (fitMode == FitMode.Auto)
            {
                ResetViewPort();
                zoomValue = (widthshrinkpercent < heightshrinkpercent) ? widthshrinkpercent : heightshrinkpercent;
            }
            else
            {
                zoomValue = fitMode == FitMode.Width ? widthshrinkpercent : heightshrinkpercent;
            }
            ZoomValue(zoomValue);
        }
        /// <summary>
        /// 輸入指定倍率縮放
        /// </summary>
        /// <param name="percentage"></param>
        public void ZoomValue(float percentage)
        {
            if (percentage > this.MaxZoom)
            {
                percentage = this.MaxZoom;
            }
            if (percentage < this.MinZoom)
            {
                percentage = this.MinZoom;
            }
            this.Zoom = percentage;
            SetSrcollBarMaximum();
            _context.Send((o) =>
            {
                FixViewPort();
            }, null);
            Repaint();
        }
        /// <summary>
        /// 遞增1.1倍放大
        /// </summary>
        public void ZoomIn()
        {
            ZoomValue(this.Zoom * 1.1F);
        }
        /// <summary>
        /// 以0.9倍遞減縮小
        /// </summary>
        public void ZoomOut()
        {
            ZoomValue(this.Zoom * 0.9F);
        }
        #endregion - Zoom Event Methods-

        #region - Callback Event Methods -
        private void HControl_Resize(object sender, EventArgs e)
        {
            if (this.ScrollBarEnable)
            {
                SetSrcollBarMaximum();
            }
            RebuildHWinSize();
        }

        private void HControl_MouseDown(object sender, MouseEventArgs e)
        {
            if (IsLockMouseOperation) return;
            if (IsLockGetMposition) return;
            lock (this.ImageBuffer.KeyObj)
            {
                try
                {
                    if (CheckHWindowState() || !HOperatorSetEx.TestObjDef(ImageBuffer.RawImage))
                        return;
                    if ((e.X < 0) || (e.X > HWinWidth() - 1) || (e.Y < 0) || (e.Y > HWinHeight() - 1))
                    {
                        return;
                    }
                    m_MousePressed = true;

                    HTuple r, c, b;
                    lock (_keyObj)
                    {
                        HOperatorSet.GetMposition(this.WindowHandle, out r, out c, out b);
                    }
                    _mouseDown = new Point(c, r);
                    DetectMouseClickAction(sender, e, r, c, b);

                    if (e.Button == MouseButtons.Right)
                    {
                        bool flag;
                        activeROIIndexR = ROIController.mouseRightDownCheck(c, r, out flag);
                        if (ROIController.ActiveROIIndex == -1 && activeROIIndexR != -1 && IsUseMenuByMouseRightButton)
                        {
                            if (flag)
                            {
                                this.SaveImagetoolStripMenuItem.Visible = true;
                                this.RemovetoolStripMenuItem.Visible = true;
                                this.ModeltoolStripMenuItem.Visible = true;
                            }
                            else
                            {
                                this.SaveImagetoolStripMenuItem.Visible = false;
                                this.RemovetoolStripMenuItem.Visible = true;
                                this.ModeltoolStripMenuItem.Visible = false;
                            }
                            htextMenuStrip.Show(this, e.X, e.Y);
                        }
                        else
                        {
                            htextMenuStrip.Visible = false;
                        }
                        CancelROIActive();
                        return;
                    }
                    if (ROIController != null && (KeyCtrlPressStatus == true))
                    {
                        ROIController.mouseDownAction(c, r);
                    }
                    if (ROIController.ActiveROIIndex != -1)
                    {
                        ROIInfo roiInfo = GetActiveROIInfo();
                        OnActiveROIInfoChanged(this, roiInfo);
                        if (_propertyForm != null && !_propertyForm.IsDisposed)
                        {
                            _propertyForm.SelectedObject = roiInfo;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (HalconExceptionHandler(ex))
                    {
                        return;
                    }
                    m_MousePressed = false;
                    if (ROIController != null)
                    {
                        ROIController.Roiactive = -1;
                        ROIController.ActiveROIIndex = -1;
                    }
                    //Repaint();
                    throw;
                }
            }
        }

        private void HControl_MouseMove(object sender, MouseEventArgs e)
        {
            //Console.WriteLine(string.Format("{0} 2158", TT));
            //if (IsLockMouseOperation) return;
            if (IsLockGetMposition) return;
            lock (this.ImageBuffer.KeyObj)
            {
                try
                {
                    if (CheckHWindowState() || !HOperatorSetEx.TestObjDef(ImageBuffer.RawImage))
                        return;
                    if (!IsExistImage())
                    {
                        return;
                    }
                    MouseEventArgs mouse = e as MouseEventArgs;
                    if ((e.X < 0) || (e.X > HWinWidth() - 1) || (e.Y < 0) || (e.Y > HWinHeight() - 1))
                    {
                        return;
                    }
                    HTuple row1 = 0, col1 = 0, button1;
                    lock (_keyObj)
                    {
                        HOperatorSet.GetMposition(this.WindowHandle, out row1, out col1, out button1);
                    }
                    _mousePosNow = new Point(col1, row1);

                    HTuple grayvalue = 0;
                    if ((ImageBuffer.RawImage != null) && (col1 >= 0) && (row1 >= 0) && (col1 < ImageBuffer.Widths) && (row1 < ImageBuffer.Heights))
                    {
                        lock (_keyObj)
                        {
                            HOperatorSet.GetGrayval(ImageBuffer.RawImage, row1, col1, out grayvalue);
                        }
                    }
                    PerformPaintEvent((int)_mousePosNow.X, (int)_mousePosNow.Y, grayvalue.I, this.Zoom);
                    //Console.WriteLine("Size {0} {1}", HWinWidth(), HWinHeight());
                    //Console.WriteLine("Halcon {0} {1} {2}", (int)_mousePosNow.X, (int)_mousePosNow.Y, this.Zoom);
                    //Console.WriteLine("ViewPort {0} {1}", _viewPort.X, _viewPort.Y);
                    //Console.WriteLine("Graphic {0} {1} {2}", e.X, e.Y, this.Zoom);

                    if (mouse.Button == MouseButtons.Left)
                    {
                        if (!m_MousePressed)
                        {
                            return;
                        }

                        if (ROIController != null && (ROIController.ActiveROIIndex != -1) && KeyCtrlPressStatus == true)
                        {
                            ROIController.mouseMoveAction(col1, row1);
                            ROIInfo roiInfo = GetActiveROIInfo();
                            OnActiveROIInfoChanged(this, roiInfo);
                        }
                        else
                        {
                            // the distance the mouse has been moved since mouse was pressed
                            float deltaX = _mousePosNow.X - _mouseDown.X;
                            float deltaY = _mousePosNow.Y - _mouseDown.Y;
                            // calculate new offset of image based on the current zoom factor
                            float x = _viewPort.X + (-deltaX);
                            float y = _viewPort.Y + (-deltaY);

                            _viewPort = new PointF(x, y);
                            FixViewPort();
                            //repaint image
                            //Console.WriteLine(string.Format("{0} 2215", TT));
                            Repaint();
                        }
                    }
                }
                catch (Exception ex)
                {
                    //Console.WriteLine(string.Format("{0} 2222", TT));
                    Console.WriteLine(ex.StackTrace);
                    if (HalconExceptionHandler(ex))
                    {
                        return;
                    }
                    throw;
                }
            }
        }

        private void HControl_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsLockMouseOperation) return;
            lock (this.ImageBuffer.KeyObj)
            {
                m_MousePressed = false;

                if ((ROIController != null) && (ROIController.ActiveROIIndex != -1))
                {
                    ROIController.defineModelROI();
                }
                if (_propertyForm != null)
                {
                    _propertyForm.RefreshData();
                }
            }
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if (IsLockMouseOperation) return;
            if (IsLockGetMposition) return;
            lock (this.ImageBuffer.KeyObj)
            {
                try
                {
                    float oldzoom = this.Zoom;
                    this.Zoom += this.Zoom * (e.Delta / 1200.0f);

                    MouseEventArgs mouse = e as MouseEventArgs;
                    float deltaX, deltaY;
                    if ((e.X >= 0) && (e.X <= HWinWidth() - 1) && (e.Y >= 0) && (e.Y <= HWinHeight() - 1))
                    {
                        PointF mousePosNow;
                        HTuple row1 = 0, col1 = 0, button1;
                        lock (_keyObj)
                        {
                            HOperatorSet.GetMposition(this.WindowHandle, out row1, out col1, out button1);
                        }
                        mousePosNow = new Point(col1, row1);
                        deltaX = mousePosNow.X - _viewPort.X;
                        deltaY = mousePosNow.Y - _viewPort.Y;
                    }
                    else
                    {
                        deltaX = HWinWidth() / 2 / this.Zoom;
                        deltaY = HWinHeight() / 2 / this.Zoom;
                    }
                    float x = _viewPort.X + deltaX * (this.Zoom - oldzoom) / this.Zoom;
                    float y = _viewPort.Y + deltaY * (this.Zoom - oldzoom) / this.Zoom;
                    _viewPort = new PointF(x, y);

                    ZoomValue(this.Zoom);
                }
                catch (Exception ex)
                {
                    if (HalconExceptionHandler(ex))
                    {
                        return;
                    }
                    throw;
                }
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            const int WM_KEYDOWN = 0x100;
            const int WM_SYSKEYDOWN = 0x104;
            bool isUDLRKeyDown = false;
            if ((msg.Msg == WM_KEYDOWN) || (msg.Msg == WM_SYSKEYDOWN))
            {
                switch (keyData)
                {
                    case Keys.Right:
                        _viewPort.X += (int)(HWinWidth() * 0.1F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Right | Keys.Control:
                        _viewPort.X += (int)(HWinWidth() * 0.9F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Left:
                        _viewPort.X -= (int)(HWinWidth() * 0.1F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Left | Keys.Control:
                        _viewPort.X -= (int)(HWinWidth() * 0.9F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Down:
                        _viewPort.Y += (int)(HWinHeight() * 0.1F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Down | Keys.Control:
                        _viewPort.Y += (int)(HWinHeight() * 0.9F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Up:
                        _viewPort.Y -= (int)(HWinHeight() * 0.1F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                    case Keys.Up | Keys.Control:
                        _viewPort.Y -= (int)(HWinHeight() * 0.9F / this.Zoom);
                        isUDLRKeyDown = true;
                        break;
                }
            }
            if (isUDLRKeyDown)
            {
                FixViewPort();
                Repaint();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (IsLockMouseOperation) return;
            if (e.KeyData == (Keys.ControlKey | Keys.Control))
            {
                KeyCtrlPressStatus = true;
            }
            base.OnKeyDown(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (IsLockMouseOperation) return;
            if (e.KeyData == Keys.ControlKey)
            {
                KeyCtrlPressStatus = false;
                //CancelROIActive();
            }
            base.OnKeyUp(e);
        }

        private void vScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            if (IsLockMouseOperation) return;
            _viewPort.Y = this.vScrollBar.Value;
            Repaint();
        }

        private void hScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            if (IsLockMouseOperation) return;
            _viewPort.X = this.hScrollBar.Value; ;
            Repaint();
        }

        private void MenuItemClick(object sender, EventArgs e)
        {
            string itemTag = ((ToolStripMenuItem)sender).Name.ToString().Trim();

            switch (itemTag)
            {
                case "SaveImagetoolStripMenuItem":
                    ROIController.SaveSelectedROIImage(activeROIIndexR);
                    break;
                case "RemovetoolStripMenuItem":
                    ROIController.ActiveROIIndex = activeROIIndexR;
                    ROIController.RemoveActive();
                    activeROIIndexR = -1;
                    break;
                case "TestModeltoolStripMenuItem":
                    HObject Contours;
                    HOperatorSet.GenEmptyObj(out Contours);
                    Contours = ROIController.TestCutModel(activeROIIndexR, ImageBuffer.RawImage);
                    AddHXLD(Contours);
                    Repaint();
                    //HOperatorSet.DispXld(Contours, this.WindowHandle);
                    break;
                case "ModeltoolStripMenuItem":
                    ROIController.SaveCutModel(activeROIIndexR, ImageBuffer.RawImage);
                    break;
                case "ROIInfotoolStripMenuItem":
                    if (activeROIIndexR == -1)
                    {
                        return;
                    }
                    if (_propertyForm == null || _propertyForm.IsDisposed == true)
                    {
                        _propertyForm = new PropertyForm();
                        _propertyForm.Show();
                    }
                    _propertyForm.SelectedObject = ROIController.ROIList[activeROIIndexR].ROIInfo;
                    break;
            }
        }

        private void PerformPaintEvent(int x, int y, int value, float zoom)
        {
            if (HPaintChanged != null)
            {
                //if (value != 0)
                //{
                //    Repaint();
                //    PaintFont(string.Format("({0}, {1})", x, y), 15, y, x);
                //}
                HPaintEventArgs args = new HPaintEventArgs(x, y, value, zoom);
                AsyncInvoke(HPaintChanged, args);
            }
        }

        /// Async Invoke to target form
        private void AsyncInvoke(HPaintEventHandler handler, HPaintEventArgs args)
        {
            Delegate[] tpcs = handler.GetInvocationList();
            foreach (HPaintEventHandler tpc in tpcs)
            {
                if (tpc.Target is System.Windows.Forms.Control)
                {
                    Control targetForm = tpc.Target as System.Windows.Forms.Control;
                    targetForm.BeginInvoke(tpc, new object[] { this, args });
                }
                else
                {
                    tpc.BeginInvoke(this, args, null, null);
                }
            }
        }

        private void setText()
        {
            if (IsLockMouseOperation) return;
            PerformPaintEvent((int)_mousePosNow.X, (int)_mousePosNow.Y, 0, this.Zoom);
        }

        private void OnHMouseDoubleDoubleClick(object sender, MouseEventArgs e)
        {
            if (HMouseDoubleClickChanged != null)
            {
                HMouseDoubleClickChanged(sender, e);
            }
        }

        private void OnActiveROIInfoChanged(object sender, ROIInfo e)
        {
            if (ActiveROIInfoChanged != null)
            {
                ActiveROIInfoChanged(sender, e);
            }
        }
        #endregion - Callback Event Methods -

        #region - ROI Operation Methods -
        private void CancelROIActive()
        {
            if (ROIController.ActiveROIIndex != -1)
            {
                m_MousePressed = false;
                ROIController.Roiactive = -1;
                ROIController.ActiveROIIndex = -1;
                Repaint();
                return;
            }
        }

        private bool CreateROICheckHImage()
        {
            if (ImageBuffer.RawImage == null)
            {
                MessageBox.Show("目前未載入圖片, 無法進行ROI圈選");
                return false;
            }

            this.Focus();
            return true;
        }

        public ROIInfoCollection GetROIInfoCollection()
        {
            ROIInfoCollection rOIInfoCollection = new ROIInfoCollection();
            foreach (ROIBase roi in ROIController.ROIList)
            {
                rOIInfoCollection.Add(roi.ROIInfo);
            }
            return rOIInfoCollection;
        }

        public int GetROIInfoCollectionCount()
        {
            return ROIController.ROIList.Count;
        }

        public void AddROIs(ROIInfoCollection rOIInfoCollection)
        {
            RemoveAllROIs();
            AddRangeROIs(rOIInfoCollection);
        }

        public void AddRangeROIs(ROIInfoCollection rOIInfoCollection)
        {
            foreach (ROIInfo rOIInfo in rOIInfoCollection)
            {
                switch (rOIInfo.RegionType)
                {
                    case 0:
                        ROIController.SetROIMode(new ROICross(rOIInfo));
                        break;
                    case 1:
                        ROIController.SetROIMode(new ROIRectangle(rOIInfo));
                        break;
                    case 2:
                        ROIController.SetROIMode(new ROIRotatableRectangle(rOIInfo));
                        break;
                    case 3:
                        ROIController.SetROIMode(new ROICircle(rOIInfo));
                        break;
                    default:
                        throw new IndexOutOfRangeException(string.Format("存在例外RegionType = {0}", rOIInfo.RegionType));
                }
            }
        }

        public void SetROIMode(ROIBase rOIBase)
        {
            ROIController.SetROIMode(rOIBase);
        }

        public void AddROIRectangle()
        {
            if (CreateROICheckHImage() == true)
            {
                ROIController.SetROIShape(new ROIRectangle(new ROIInfo()));
            }
        }

        public void AddROICross()
        {
            if (CreateROICheckHImage() == true)
            {
                ROIController.SetROIShape(new ROICross(new ROIInfo()));
            }
        }

        public void AddROIRotatableRectangle()
        {
            if (CreateROICheckHImage() == true)
            {
                ROIController.SetROIShape(new ROIRotatableRectangle(new ROIInfo()));
            }
        }

        public void AddROICircle()
        {
            if (CreateROICheckHImage() == true)
            {
                ROIController.SetROIShape(new ROICircle(new ROIInfo()));
            }
        }

        public void RemoveActiveROI()
        {
            ROIController.RemoveActive();
        }

        public void RemoveAllROIs()
        {
            ROIController.RemoveAll();
        }

        public void CopyActiveROI()
        {
            if (ROIController.ActiveROIIndex != -1)
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new MemoryStream())
                {
                    formatter.Serialize(stream, ROIController.ROIList[ROIController.ActiveROIIndex].ROIInfo);
                    stream.Seek(0, SeekOrigin.Begin);
                    ROIInfo rOIInfo = (ROIInfo)formatter.Deserialize(stream);
                    rOIInfo.Index = ROIController.ProduceROIIndex();
                    SetROIMode(new ROIRectangle(rOIInfo));
                    Repaint();
                };
                return;
            }
        }

        public ROIInfo GetActiveROIInfo()
        {
            if (ROIController.ActiveROIIndex != -1)
            {
                return ROIController.ROIList[ROIController.ActiveROIIndex].ROIInfo;
            }
            else
            {
                return null;
            }
        }

        public void ShowROIInfoPropertyForm()
        {
            if (_propertyForm == null || _propertyForm.IsDisposed == true)
            {
                _propertyForm = new PropertyForm();
                _propertyForm.Show();
            }
            _propertyForm.SelectedObject = GetActiveROIInfo();
        }

        public void ShowROIInfoCollectionForm()
        {
            bool isExitFormConfig = false;//判断配置窗口是否已经打开，防止重复打开多个配置窗口FormConfig
            foreach (Form openForm in Application.OpenForms)
            {
                if (openForm.Name == "ROIInfoCollectionForm")
                {
                    openForm.Visible = true;//如果配置窗口已打开则将其显示
                    openForm.Activate();//并激活该窗体
                    isExitFormConfig = true;
                    break;
                }
            }
            if (!isExitFormConfig)
            {
                ROIInfoCollectionForm rOIInfoCollectionForm = new ROIInfoCollectionForm();
                rOIInfoCollectionForm.ROIController = this.ROIController;
                rOIInfoCollectionForm.Show();
                rOIInfoCollectionForm.RefreshData();
            }
        }
        #endregion - ROI Operation Methods -

        #region - Draw ROI Operation Methods(Halcon) -
        public void DrawCircle(out HTuple row, out HTuple column, out HTuple radius)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawCircle(this.WindowHandle, out row, out column, out radius);
            IsLockMouseOperation = false;
        }

        public void DrawCircleMod(HTuple rowIn, HTuple columnIn, HTuple radiusIn, out HTuple row, out HTuple column, out HTuple radius)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawCircleMod(this.WindowHandle, rowIn, columnIn, radiusIn, out row, out column, out radius);
            IsLockMouseOperation = false;
        }

        public void DrawEllipse(out HTuple row, out HTuple column, out HTuple phi, out HTuple radius1, out HTuple radius2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawEllipse(this.WindowHandle, out row, out column, out phi, out radius1, out radius2);
            IsLockMouseOperation = false;
        }

        public void DrawEllipseMod(HTuple rowIn, HTuple columnIn, HTuple phiIn, HTuple radius1In, HTuple radius2In, out HTuple row, out HTuple column, out HTuple phi, out HTuple radius1, out HTuple radius2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawEllipseMod(this.WindowHandle, rowIn, columnIn, phiIn, radius1In, radius2In, out row, out column, out phi, out radius1, out radius2);
            IsLockMouseOperation = false;
        }

        public void DrawLine(out HTuple row1, out HTuple column1, out HTuple row2, out HTuple column2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawLine(this.WindowHandle, out row1, out column1, out row2, out column2);
            IsLockMouseOperation = false;
        }

        public void DrawLineMod(HTuple row1In, HTuple column1In, HTuple row2In, HTuple column2In, out HTuple row1, out HTuple column1, out HTuple row2, out HTuple column2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawLineMod(this.WindowHandle, row1In, column1In, row2In, column2In, out row1, out column1, out row2, out column2);
            IsLockMouseOperation = false;
        }

        public void DrawPoint(out HTuple row, out HTuple column)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawPoint(this.WindowHandle, out row, out column);
            IsLockMouseOperation = false;
        }

        public void DrawPointMod(HTuple rowIn, HTuple columnIn, out HTuple row, out HTuple column)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawPointMod(this.WindowHandle, rowIn, columnIn, out row, out column);
            IsLockMouseOperation = false;
        }

        public void DrawPolygon(out HObject polygonRegion, HTuple windowHandle)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawPolygon(out polygonRegion, this.WindowHandle);
            IsLockMouseOperation = false;
        }

        public HObject DrawRectangle1()
        {
            HTuple hv_Row1, hv_Column1, hv_Row2, hv_Column2;
            DrawRectangle1(out hv_Row1, out hv_Column1, out hv_Row2, out hv_Column2);
            return HOperatorSetEx.GenRectangle1(hv_Row1, hv_Column1, hv_Row2, hv_Column2);
        }

        public void DrawRectangle1(out HTuple row1, out HTuple column1, out HTuple row2, out HTuple column2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawRectangle1(this.WindowHandle, out row1, out column1, out row2, out column2);
            IsLockMouseOperation = false;
        }

        public void DrawRectangle1Mod(HTuple row1In, HTuple column1In, HTuple row2In, HTuple column2In, out HTuple row1, out HTuple column1, out HTuple row2, out HTuple column2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawRectangle1Mod(this.WindowHandle, row1In, column1In, row2In, column2In, out row1, out column1, out row2, out column2);
            IsLockMouseOperation = false;
        }

        public void DrawRectangle2(out HTuple row, out HTuple column, out HTuple phi, out HTuple length1, out HTuple length2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawRectangle2(this.WindowHandle, out row, out column, out phi, out length1, out length2);
            IsLockMouseOperation = false;
        }

        public void DrawRectangle2Mod(HTuple rowIn, HTuple columnIn, HTuple phiIn, HTuple length1In, HTuple length2In, out HTuple row, out HTuple column, out HTuple phi, out HTuple length1, out HTuple length2)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawRectangle2Mod(this.WindowHandle, rowIn, columnIn, phiIn, length1In, length2In, out row, out column, out phi, out length1, out length2);
            IsLockMouseOperation = false;
        }

        public void DrawRegion(out HObject region)
        {
            IsLockMouseOperation = true;
            this.Focus();
            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DrawRegion(out region, this.WindowHandle);
            IsLockMouseOperation = false;
        }
        #endregion - Draw ROI Operation Methods(Halcon) -

        public void PaintRectangle(HTuple row1, HTuple column1, HTuple row2, HTuple column2)
        {
            //if (this.WindowHandle == null)
            //{
            //    return;
            //}

            //string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
            //int fontSize = (int)(18);
            //HTuple font = string.Format(fontFormat, fontSize);

            //HOperatorSet.SetLineStyle(this.WindowHandle, 0);
            //HOperatorSet.SetColor(this.WindowHandle, "red");

            //HOperatorSet.SetTposition(this.WindowHandle, 480, 640);
            //HOperatorSet.SetFont(this.WindowHandle, font);
            //HOperatorSet.WriteString(this.WindowHandle, "1:1");

            //HOperatorSet.DispRectangle1(this.WindowHandle, 640, 480, 1024, 768);

            HOperatorSet.SetColor(this.WindowHandle, "red");
            HOperatorSet.DispLine(this.WindowHandle, row1, column1, row1, column2);
            HOperatorSet.DispLine(this.WindowHandle, row1, column1, row2, column1);
            HOperatorSet.DispLine(this.WindowHandle, row1, column2, row2, column2);
            HOperatorSet.DispLine(this.WindowHandle, row2, column1, row2, column2);

        }
    }
}
