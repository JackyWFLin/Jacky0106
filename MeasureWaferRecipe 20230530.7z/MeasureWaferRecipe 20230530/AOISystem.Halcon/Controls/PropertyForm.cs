﻿using System.Windows.Forms;

namespace AOISystem.Halcon.Controls
{
    public partial class PropertyForm : Form
    {
        public PropertyForm()
        {
            InitializeComponent();
        }

        private object _selectedObject;
        public object SelectedObject
        {
            get
            {
                return _selectedObject;
            }
            set
            {
                _selectedObject = value;
                this.propertyGrid.SelectedObject = _selectedObject;
                if(_selectedObject != null )
                {
                    this.Text = _selectedObject.ToString();
                }
                this.propertyGrid.Refresh();
            }
        }

        public void RefreshData()
        {
            this.propertyGrid.Refresh();
        }
    }
}
