﻿
namespace AOISystem.Halcon.Controls
{
    public enum FitMode
    {
        Auto,
        Width,
        Height
    }
}
