﻿using HalconDotNet;

namespace AOISystem.Halcon.Controls
{
    public class HMessageInfo
    {
        public HMessageInfo()
        {
            Name = string.Empty;
            Msg = new HTuple();
            Row = new HTuple();
            Column = new HTuple();
            DispColor = HColorMode.black;
            Box = "true";
        }

        public string Name { get; set; }

        public HTuple Msg { get; set; }

        public HTuple Row { get; set; }

        public HTuple Column { get; set; }

        public HColorMode DispColor { get; set; }

        public string Box { get; set; }
    }
}
