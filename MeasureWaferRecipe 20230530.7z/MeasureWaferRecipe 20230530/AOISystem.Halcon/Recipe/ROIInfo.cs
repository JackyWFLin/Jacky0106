﻿using System;
using System.Collections;
using System.ComponentModel;
using AOISystem.Halcon.Controls;

namespace AOISystem.Halcon.Recipe
{
    /// <summary>
    /// ROIInfo
    /// </summary>
    [Serializable]
    public class ROIInfo
    {
        private int m_Index;
        private int m_InspectId;

        public ROIInfo()
        {
            m_Index = 0;
            m_InspectId = 0;
            ActiveColor = HColorMode.green;
            InActiveColor = HColorMode.red;
            ActiveHColor = HColorMode.yellow;
            testScore = 0.5;
            testOverlap = 0.5;
            testNum = 0;
        }

        /// <summary>
        /// ROI Detail ID
        /// </summary>
        [Browsable(true), Category("Property"), Description("ROI RecipeNo")]
        public int Index
        {
            get
            {
                return this.m_Index;
            }
            set
            {
                if (m_Index != value)
                {
                    this.m_Index = value;
                    InspectName = string.Format("{0}-{1}", m_Index, m_InspectId);
                }
            }
        }

        [Browsable(true), Category("Property"), Description("Inspect Id")]
        public int InspectId
        {
            get
            {
                return m_InspectId;
            }
            set
            {
                if (m_InspectId != value)
                {
                    m_InspectId = value;
                    InspectName = string.Format("{0}-{1}", Index, InspectId);
                }
            }
        }

        [Browsable(true), Category("Property"), Description("Inspect RecipeID")]
        public string InspectName { get; set; }

        /// <summary>
        /// 0:Cross 1:Rectangle1 2:Rectangle2 3:Circle
        /// </summary>
        [Browsable(true), Category("Property"), Description("Inspect RecipeID")]
        public int RegionType { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle X")]
        public double X { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle Y")]
        public double Y { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle Width")]
        public double Width { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle Height")]
        public double Height { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle Angle")]
        public double Angle { get; set; }

        [Browsable(true), Category("Property"), Description("Rectangle Radius")]
        public double Radius { get; set; }

        [Browsable(true), Category("Property"), Description("Active Color")]
        public HColorMode ActiveColor { get; set; }

        [Browsable(true), Category("Property"), Description("Active Handle Color")]
        public HColorMode ActiveHColor { get; set; }

        [Browsable(true), Category("Property"), Description("Inactive Color")]
        public HColorMode InActiveColor { get; set; }

        [Browsable(true), Category("Property"), Description("Process Index")]
        public int ProcessIndex { get; set; }

        [Browsable(true), Category("Property"), Description("Process Done")]
        public bool ProcessDone { get; set; }

        /// <summary>
        /// Model測試參數
        /// </summary>
        [Browsable(true), Category("testModelParam"), Description("Score")]
        public double testScore { get; set; }
        [Browsable(true), Category("testModelParam"), Description("Overlap")]
        public double testOverlap { get; set; }
        [Browsable(true), Category("testModelParam"), Description("Num")]
        public double testNum { get; set; }
    }

    [Serializable]
    public class ROIInfoCollection : CollectionBase
    {
        public ROIInfo this[int index]
        {
            get { return (ROIInfo)base.List[index]; }
            set { base.List[index] = value; }
        }

        public int Add(ROIInfo value)
        {
            return base.InnerList.Add(value);
        }

        public void AddRange(ROIInfoCollection value)
        {
            base.InnerList.AddRange(value);
        }

        public void Insert(int index, ROIInfo value)
        {
            base.InnerList.Insert(index, value);
        }

        public void Remove(ROIInfo value)
        {
            base.InnerList.Remove(value);
        }

        public int IndexOf(ROIInfo value)
        {
            return base.InnerList.IndexOf(value);
        }

        public bool Contains(ROIInfo value)
        {
            return base.InnerList.Contains(value);
        }
    }
}
