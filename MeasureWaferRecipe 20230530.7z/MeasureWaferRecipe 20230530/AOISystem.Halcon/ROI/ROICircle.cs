﻿using System;
using AOISystem.Halcon.Controls;
using AOISystem.Halcon.Recipe;
using HalconDotNet;

namespace AOISystem.Halcon.ROI
{
    public class ROICircle : ROIBase
    {
        //fields

        private double row1, col1;         // upper left
        private double row2, col2;         // lower right 
        private double centerR, centerC;   // midpoint 
        private double radius;         // row and column mid point

        public double mouseRow, mouseCol;

        //[Browsable(true), Category("Property"), Description("Row")]
        //public double Row
        //{
        //    get { return row1; }
        //}

        //[Browsable(true), Category("Property"), Description("Column")]
        //public double Column
        //{
        //    get { return col1; }
        //}

        //[Browsable(true), Category("Property"), Description("設定檔路徑")]
        //public double MidRow
        //{
        //    get { return midR; }
        //}

        /// <summary>
        /// Constructor
        /// </summary>
        public ROICircle()
        {
            NumHandles = 9; // 8 corner points + midpoint
            activeHandleIdx = 4;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_recipe"></param>
        public ROICircle(ROIInfo recipe)
            : this()
        {
            base.ROIInfo = recipe;
            ROIInfo.RegionType = 3;

            centerC = recipe.X;
            centerR = recipe.Y;
            radius = recipe.Radius;
        }

        /// <summary>
        /// create ROI 設定初始框大小位置
        /// </summary>
        public override void createROI(double midX, double midY)
        {
            centerC = (int)midX;
            centerR = (int)midY;

            radius = (int)(20 / this.Scale);
        }

        /// <summary>
        /// draw 圓
        /// </summary>
        public override void draw(HalconDotNet.HWindow window)
        {
            double phi = 0;
            double length1 = 5 / this.Scale;
            double length2 = 5 / this.Scale;

            window.DispCircle(centerR, centerC, radius);
        }

        public override void drawFont(HalconDotNet.HWindow window)
        {
            int h_fontZoom = 0;
            if (this.ROIFontZoomMode == FontZoomMode.Positive)
            {
                h_fontZoom = (int)(this.FontSize * this.Scale);
            }
            else if (this.ROIFontZoomMode == FontZoomMode.Reverse)
            {
                h_fontZoom = (int)System.Math.Sqrt(this.FontSize / this.Scale);
                if (h_fontZoom < this.FontSizeThreshold)
                {
                    h_fontZoom = this.FontSizeThreshold;
                }
            }
            else
            {
                h_fontZoom = this.FontSize;
            }
            if (h_fontZoom >= this.FontSizeThreshold)
            {
                string fontFormat = "-Arial-{0}-*-1-*-*-1-ANSI_CHARSET-";
                HTuple font = string.Format(fontFormat, h_fontZoom);
                window.SetFont(font);
                window.SetTposition((int)centerR, (int)centerC);
                window.WriteString(base.ROIInfo.InspectName);
            }
        }

        public void drawFont(HalconDotNet.HWindow window, HTuple row, HTuple col)
        {
            window.SetFont("-Arial-18-*-1-*-*-1-ANSI_CHARSET-");
            window.SetTposition(row, col);
            window.WriteString(base.ROIInfo.InspectName);
        }

        /// <summary>
        /// 計算最接近的小框
        /// </summary>
        public override int ROIdistance(double x, double y)
        {
            if ((centerR - radius) < y && (centerR + radius) > y && (centerC - radius) < x && (centerC + radius) > x)
            {
                return (int)(Math.Pow(radius, 2) * 3.14159);
            }
            return -1;
        }

        /// <summary>
        /// 計算最接近的小框
        /// </summary>
        public override bool distToClosestHandle2(double x, double y)
        {
            mouseRow = y;
            mouseCol = x;
            double max = 10000;
            double temp, Distance;
            double[] val = new double[NumHandles];
            double epsilon = 7.0 / this.Scale;

            row1 = centerR - radius;
            row2 = centerR + radius;
            col1 = centerC - radius;
            col2 = centerC + radius;

            val[0] = double.MaxValue;                          // upper left 
            val[1] = double.MaxValue;                          // upper right 
            val[2] = double.MaxValue;                          // lower right 
            val[3] = double.MaxValue;                          // lower left 
            val[4] = HMisc.DistancePp(y, x, centerR, centerC); // midpoint 
            val[5] = HMisc.DistancePp(y, x, row1, centerC);       // upper left  midpoint 
            val[6] = HMisc.DistancePp(y, x, row2, centerC);       // upper right  midpoint 
            val[7] = HMisc.DistancePp(y, x, centerR, col1);       // lower right midpoint 
            val[8] = HMisc.DistancePp(y, x, centerR, col2);       // lower left midpoint 
            //val[5] = HMisc.DistancePp(y, x, row1, midC);       // upper left  midpoint 
            //val[6] = HMisc.DistancePp(y, x, row2, midC);       // upper right  midpoint 
            //val[7] = HMisc.DistancePp(y, x, midR, col1);       // lower right midpoint 
            //val[8] = HMisc.DistancePp(y, x, midR, col2);       // lower left midpoint 

            if (radius < 20)
            { temp = 0; }
            else
            { temp = 20; }
            if (radius < 200)
            { Distance = 2; }
            else { Distance = 7 / 3; }
            for (int i = 5; i < 9; i++)
            {
                if (val[4] < radius)
                {
                    if (val[i] < (radius + temp) / Distance)
                    {
                        max = val[i];
                        activeHandleIdx = i;
                        return true;
                    }
                }
                else
                {
                    if (val[i] < temp)
                    {
                        max = val[i];
                        activeHandleIdx = i;
                        return true;
                    }
                }
            }

            if (val[4] < radius / 2)
            {
                activeHandleIdx = 4;
                return true;
            }
            if (radius == 0)
            {
                activeHandleIdx = 4;
                radius = 3;
                return true;
            }
            activeHandleIdx = 0;
            return false;
        }

        /// <summary> 
        /// Paints the active handle of the ROI object into the supplied window
        /// </summary>
        /// <param name="window">HALCON window</param>
        public override void displayActive(HalconDotNet.HWindow window)
        {
            double phi = 0;
            double length1 = 5 / this.Scale;
            double length2 = 5 / this.Scale;

            window.DispLine(centerR, col1, centerR, col2);
            window.DispLine(row1, centerC, row2, centerC);

            switch (activeHandleIdx)
            {
                //case 0:
                //    window.DispRectangle2(row1, col1, phi, length1, length2);
                //    break;
                //case 1:
                //    window.DispRectangle2(row1, col2, phi, length1, length2);
                //    break;
                //case 2:
                //    window.DispRectangle2(row2, col2, phi, length1, length2);
                //    break;
                //case 3:
                //    window.DispRectangle2(row2, col1, phi, length1, length2);
                //    break;
                case 4:
                    window.DispRectangle2(centerR, centerC, phi, length1, length2);
                    break;
                case 5:
                    window.DispRectangle2(row1, centerC, phi, length1, length2);
                    break;
                case 6:
                    window.DispRectangle2(row2, centerC, phi, length1, length2);
                    break;
                case 7:
                    window.DispRectangle2(centerR, col1, phi, length1, length2);
                    break;
                case 8:
                    window.DispRectangle2(centerR, col2, phi, length1, length2);
                    break;
            }
        }

        public override HRegion getRegion()
        {
            HRegion region = new HRegion();
            region.GenCircle(centerR, centerC, radius);
            return region;
        }

        //public override System.Drawing.RectangleF getRectangleF()
        //{
        //    return new System.Drawing.RectangleF((float)col1, (float)row1, (float)(col2 - col1), (float)(row2 - row1));
        //}


        public override System.Drawing.RectangleF getRectangleF()
        {
            ROIInfo.X = centerC;
            ROIInfo.Y = centerR;
            ROIInfo.Radius = radius;
            return new System.Drawing.RectangleF((float)col1, (float)row1, (float)(col2 - col1), (float)(row2 - row1));
        }

        /// <summary> 
        /// Recalculates the shape of the ROI instance. Translation is 
        /// performed at the active handle of the ROI object 
        /// for the image coordinate (x,y)
        /// </summary>
        /// <param name="newX">x mouse coordinate</param>
        /// <param name="newY">y mouse coordinate</param>
        public override void moveByHandle(double newX, double newY)
        {
            double len1, len2, lenC, lenR;
            double tmp;
            double len;
            row1 = centerR - radius;
            row2 = centerR + radius;
            col1 = centerC - radius;
            col2 = centerC + radius;

            switch (activeHandleIdx)
            {
                //case 0: // upper left 
                //    radius = HMisc.DistancePp(newX, newY, centerC, centerR); 
                //    break;
                //case 1: // upper right 
                //    radius = HMisc.DistancePp(newX, newY, centerC, centerR); 
                //    break;
                //case 2: // lower right 
                //    radius = HMisc.DistancePp(newX, newY, centerC, centerR); 
                //    break;
                //case 3: // lower left
                //    radius = HMisc.DistancePp(newX, newY, centerC, centerR); 
                //    break;
                case 4: // midpoint 
                    centerR = newY;
                    centerC = newX;

                    break;
                case 5:
                    radius = HMisc.DistancePp(newX, newY, centerC, centerR);
                    break;
                case 6:
                    radius = HMisc.DistancePp(newX, newY, centerC, centerR);
                    break;
                case 7:
                    radius = HMisc.DistancePp(newX, newY, centerC, centerR);
                    break;
                case 8:
                    radius = HMisc.DistancePp(newX, newY, centerC, centerR);
                    break;
            }


        }
    }
}
