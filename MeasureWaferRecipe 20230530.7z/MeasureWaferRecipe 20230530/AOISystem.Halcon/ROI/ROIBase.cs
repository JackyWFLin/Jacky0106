﻿using AOISystem.Halcon.Controls;
using AOISystem.Halcon.Recipe;
using HalconDotNet;

namespace AOISystem.Halcon.ROI
{
    /// <summary>
    /// This class is a base class containing virtual methods for handling
    /// ROIs. Therefore, an inheriting class needs to define/override these
    /// methods to provide the ROIController with the necessary information on
    /// its (= the ROIs) shape and position. In the example project two ROI
    /// shapes are implemented: ROIRectangle1 and ROIRectangle2. To use other
    /// shapes you must derive a new class from the base class ROI and
    /// implement its methods.
    /// </summary>    
    public class ROIBase
    {
        // class members of inheriting ROI classes
        protected int NumHandles;
        protected int activeHandleIdx;

        /// <summary>
        /// Flag to define the ROI to be 'positive' or 'negative'
        /// </summary>
        protected int OperatorFlag;

        protected float Scale = 1.0f;

        protected FontZoomMode ROIFontZoomMode = FontZoomMode.Constant;

        protected int FontSize = 1;

        protected int FontSizeThreshold = 1;

        protected float ViewRow1 = 0.0f;

        protected float ViewColumn1 = 0.0f;

        protected float ViewRow2 = 1.0f;

        protected float ViewColumn2 = 1.0f;

        /// <summary>Parameter to define the line style of the ROI</summary>
        public HTuple flagLineStyle;

        /// <summary>Constant for a positive ROI flag</summary>
        public const int POSITIVE_FLAG = ROIController.MODE_ROI_POS;

        /// <summary>Constant for a negative ROI flag</summary>
        public const int NEGATIVE_FLAG = ROIController.MODE_ROI_NEG;

        protected HTuple posOperation = new HTuple();
        protected HTuple negOperation = new HTuple(new int[] { 2, 2 });

        public ROIInfo ROIInfo;

        /// <summary>Constructor of abstract ROI class</summary>
        public ROIBase() { }

        /// <summary>Creates a new ROI instance at the mouse position</summary>
        /// <param name="midX">
        /// x (=column) coordinate for interactive ROI
        /// </param>
        /// <param name="midY">
        /// y (=row) coordinate for interactive ROI
        /// </param>
        public virtual void createROI(double midX, double midY) { }

        /// <summary>Paints the ROI into the supplied window</summary>
        /// <param name="window">HALCON window</param>
        public virtual void draw(HalconDotNet.HWindow window) { }

        public virtual void drawFont(HalconDotNet.HWindow window) { }

        /// <summary> 
        /// Returns the distance of the ROI handle being
        /// closest to the image point(x,y)
        /// </summary>
        /// <param name="x">x (=column) coordinate</param>
        /// <param name="y">y (=row) coordinate</param>
        /// <returns> 
        /// Distance of the closest ROI handle.
        /// </returns>
        public virtual bool distToClosestHandle2(double x, double y)
        {            
            return true;
        }

        public virtual int ROIdistance(double x, double y)
        {            
            return -1;
        }
        
        /// <summary> 
        /// Paints the active handle of the ROI object into the supplied window 
        /// </summary>
        /// <param name="window">HALCON window</param>
        public virtual void displayActive(HalconDotNet.HWindow window) { }

        /// <summary> 
        /// Recalculates the shape of the ROI. Translation is 
        /// performed at the active handle of the ROI object 
        /// for the image coordinate (x,y)
        /// </summary>
        /// <param name="x">x (=column) coordinate</param>
        /// <param name="y">y (=row) coordinate</param>
        public virtual void moveByHandle(double x, double y) { }

        /// <summary>Gets the HALCON region described by the ROI</summary>
        public virtual HRegion getRegion()
        {
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual System.Drawing.RectangleF getRectangleF()
        {
            return new System.Drawing.RectangleF();
        }
        
        /// <summary>Number of handles defined for the ROI</summary>
        /// <returns>Number of handles</returns>
        public int getNumHandles()
        {
            return NumHandles;
        }

        /// <summary>Gets the active handle of the ROI</summary>
        /// <returns>RecipeNo of the active handle (from the handle list)</returns>
        public int getActHandleIdx()
        {
            return activeHandleIdx;
        }

        /// <summary>
        /// Gets the sign of the ROI object, being either 
        /// 'positive' or 'negative'. This sign is used when creating a model
        /// region for matching applications from a list of ROIs.
        /// </summary>
        public int getOperatorFlag()
        {
            return OperatorFlag;
        }

        /// <summary>
        /// Sets the sign of a ROI object to be positive or negative. 
        /// The sign is used when creating a model region for matching
        /// applications by summing up all positive and negative ROI models
        /// created so far.
        /// </summary>
        /// <param name="flag">Sign of ROI object</param>
        public void setOperatorFlag(int flag)
        {
            OperatorFlag = flag;

            switch (OperatorFlag)
            {
                case ROIBase.POSITIVE_FLAG:
                    flagLineStyle = posOperation;
                    break;
                case ROIBase.NEGATIVE_FLAG:
                    flagLineStyle = negOperation;
                    break;
                default:
                    flagLineStyle = posOperation;
                    break;
            }
        }

        public void setROIParameter(HControl view)
        {
            Scale = view.Zoom;
            ROIFontZoomMode = view.ROIFontZoomMode;
            FontSize = view.ROIFontSize;
            FontSizeThreshold = view.ROIFontSizeThreshold;
            ViewRow1 = view.ViewRow1;
            ViewColumn1 = view.ViewColumn1;
            ViewRow2 = view.ViewRow2;
            ViewColumn2 = view.ViewColumn2;
        }
    }
}
